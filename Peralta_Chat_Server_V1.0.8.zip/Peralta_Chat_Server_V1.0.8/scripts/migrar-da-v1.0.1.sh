#!/usr/bin/env bash
set -Eeuo pipefail

cd "$(dirname "$0")/.."
peralta_old_dir="${1:-/opt/Peralta_Chat_Server_V1.0.1}"

if [[ ! -f "${peralta_old_dir}/.env" ]]; then
  echo "Nao encontrei ${peralta_old_dir}/.env."
  echo "Informe a pasta correta: ./scripts/migrar-da-v1.0.1.sh /caminho/da/V1.0.1"
  exit 1
fi

if [[ ! -f .env ]]; then
  install -m 600 "${peralta_old_dir}/.env" .env
  echo "Configuracao da V1.0.1 copiada sem exibir senhas."
else
  echo "Usando o .env que ja existe nesta pasta."
fi

docker compose config --quiet
docker compose up -d --build --remove-orphans
docker compose ps

echo
echo "Migracao para a V1.0.8 concluida."
echo "PostgreSQL, contas e perfis do Chrome foram mantidos nos mesmos volumes."
echo "Nao apague a pasta V1.0.1 antes de conferir o painel e fazer um backup."

