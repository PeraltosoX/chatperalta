import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';

const root = new URL('../', import.meta.url);
const read = (relativePath) => fs.readFile(new URL(relativePath, root), 'utf8');

test('correcao da tela administrativa e permanente no CSS', async () => {
  const [css, adminScript] = await Promise.all([
    read('public/styles.css'),
    read('public/js/admin.js'),
  ]);
  assert.match(css, /\[hidden\]\s*\{\s*display:\s*none\s*!important;/i);
  assert.match(adminScript, /loginSection\.hidden\s*=\s*true/);
  assert.match(adminScript, /dashboard\.hidden\s*=\s*false/);
});

test('pacote inclui dependencias e politica do Chrome manual', async () => {
  const [dockerfile, policy] = await Promise.all([
    read('Dockerfile'),
    read('config/chrome-policy.json'),
  ]);
  for (const dependency of ['imagemagick', 'openbox', 'xdotool', 'xvfb']) {
    assert.match(dockerfile, new RegExp(`\\b${dependency}\\b`));
  }
  assert.equal(JSON.parse(policy).PasswordManagerEnabled, false);
});

test('versao 1.0.8 e cache renovado ficam consistentes', async () => {
  const [version, packageJson, config, serviceWorker, environmentExample] = await Promise.all([
    read('VERSION'),
    read('package.json'),
    read('src/config.js'),
    read('public/sw.js'),
    read('.env.example'),
  ]);
  assert.equal(version.trim(), '1.0.8');
  assert.equal(JSON.parse(packageJson).version, '1.0.8');
  assert.match(config, /VERSION\s*=\s*'1\.0\.8'/);
  assert.match(serviceWorker, /peralta-chat-server-v1\.0\.8/);
  assert.match(environmentExample, /Peralta Chat Server V1\.0\.8/);
});

test('V1.0.8 preserva login, recupera o compositor e mantem dados na migracao', async () => {
  const [manualLogin, browserController, persistentContext, sessionDetection, sessionImport, chatTools, liveWorker, appHtml, appScript, server, migration, swap, exporter] = await Promise.all([
    read('src/services/manual-login-session.js'),
    read('src/services/browser-controller.js'),
    read('src/services/persistent-context.js'),
    read('src/services/youtube-session.js'),
    read('src/services/session-import.js'),
    read('src/services/youtube-chat-tools.js'),
    read('src/services/live-chat-worker.js'),
    read('public/app.html'),
    read('public/js/app.js'),
    read('src/http/server.js'),
    read('scripts/migrar-da-v1.0.7.sh'),
    read('scripts/preparar-vps-1gb.sh'),
    fs.stat(new URL('../public/downloads/Peralta_Session_Exporter_V1.0.1.zip', import.meta.url)),
  ]);
  assert.match(manualLogin, /'--no-sandbox'/);
  assert.match(manualLogin, /'--disable-crash-reporter'/);
  assert.match(manualLogin, /\['windowclose', this\.windowId\]/);
  assert.match(manualLogin, /--classname', 'google-chrome'/);
  assert.match(manualLogin, /pathExists\(`\/tmp\/\.X11-unix\/X\$\{number\}`\)/);
  assert.match(manualLogin, /return null;\s*\}/);
  assert.match(browserController, /preparePersistentContext\(context\)/);
  assert.match(browserController, /async newPage\(\)/);
  assert.match(persistentContext, /const probePage = await context\.newPage\(\)/);
  assert.match(persistentContext, /return keepAlivePage/);
  assert.match(sessionDetection, /loggedByCookie \|\| loggedByPage \|\| avatarVisible/);
  assert.match(sessionImport, /cookies fora do Google ou YouTube/);
  assert.match(browserController, /async importSession\(cookies\)/);
  assert.match(browserController, /await context\.addCookies\(cookies\)/);
  assert.match(chatTools, /tryActivateComposer/);
  assert.match(chatTools, /tryRestoreExistingComposer/);
  assert.match(chatTools, /document\.execCommand\('insertText'/);
  assert.match(chatTools, /getComposerDiagnostics/);
  assert.match(liveWorker, /Campo do chat nao apareceu\. Diagnostico:/);
  assert.match(appHtml, /Importar sess[aã]o da V4\.83/i);
  assert.match(appHtml, /Peralta_Session_Exporter_V1\.0\.1\.zip/);
  assert.match(appScript, /youtube\/session\/import/);
  assert.match(server, /readJson\(request, 2_000_000\)/);
  assert.match(server, /SET monitor_enabled = true, paused = false/);
  assert.match(appScript, /Retomar envios/);
  assert.match(browserController, /removeStaleProfileLocks/);
  assert.match(appScript, /clearInterval\(browserTimer\)[\s\S]*youtube\/login\/finish/);
  assert.match(appScript, /browserBusy \|\| browserFinishing/);
  assert.doesNotMatch(migration, /down\s+-v/);
  assert.match(migration, /install -m 600/);
  assert.match(swap, /swapon \/swapfile/);
  assert.ok(exporter.size > 1000);
});
