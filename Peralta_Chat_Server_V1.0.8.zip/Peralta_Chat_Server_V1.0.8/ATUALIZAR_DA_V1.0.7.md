# Atualizar da V1.0.7 para a V1.0.8 sem perder dados

Esta atualizacao corrige o ciclo em que o chat era localizado, mas o campo de mensagem nao aparecia e o processo ficava registrando **Chat reconectado**. Ela porta a rotina completa e estavel do compositor da V4.83 sem modificar o programa original.

Nunca execute `docker compose down -v`: a opcao `-v` apaga os volumes.

## 1. Fazer backup da V1.0.7

```bash
cd /opt/Peralta_Chat_Server_V1.0.7
./scripts/backup.sh
```

## 2. Aplicar a V1.0.8

Depois de enviar e descompactar `Peralta_Chat_Server_V1.0.8.zip` em `/opt`:

```bash
cd /opt/Peralta_Chat_Server_V1.0.8
chmod +x scripts/*.sh
./scripts/migrar-da-v1.0.7.sh
```

O script copia o `.env`, recompila o container e conecta aos mesmos volumes do PostgreSQL e dos perfis.

## 3. Conferir

```bash
sleep 15
curl -sS https://peraltaultrachat.shop/healthz
docker compose ps
```

A saude deve informar `"version":"1.0.8"`. No painel, o historico deve registrar **Campo do chat localizado** ou **Mensagem enviada**. Se o YouTube impedir o compositor, o registro agora mostrara o diagnostico exato em vez de apenas reconectar.
