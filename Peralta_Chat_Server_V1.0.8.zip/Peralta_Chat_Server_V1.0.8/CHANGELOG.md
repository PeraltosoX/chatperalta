# Historico de versoes

## Peralta Chat Server V1.0.8 — recuperacao do campo do chat

- Portada integralmente da V4.83 a sequencia de localizacao e ativacao do compositor do YouTube.
- O Chrome agora clica no campo/placeholder, restaura renderizadores existentes que ficaram ocultos e procura novamente em todos os frames.
- Adicionado preenchimento alternativo com eventos reais quando o `fill` normal deixa de atualizar o compositor do YouTube.
- O historico passa a registrar diagnostico de URL, login, quantidade de campos e frames quando o campo nao aparece, facilitando identificar bloqueios da conta ou mudancas do YouTube.
- Mantidas as correcoes da V1.0.7 para retomada dos envios e travas antigas do perfil.
- Adicionada migracao direta da V1.0.7 preservando PostgreSQL, contas, configuracoes, mensagens e perfis do Chrome.
- Aplicativo Android e cache web atualizados para a versao 1.0.8.

## Peralta Chat Server V1.0.7 — retomada dos envios

- Corrigido o botao **Iniciar**: ele agora ativa o monitor e tambem remove o estado **Pausado**.
- Um chat que ja foi localizado volta a enviar imediatamente ao iniciar, sem apagar contadores, canais, mensagens ou a sessao importada.
- O Chrome automatico remove somente travas antigas do perfil quando confirma que nenhum Chrome esta usando aquela conta, evitando falhas depois de reinicios abruptos.
- Adicionada migracao direta da V1.0.6 preservando PostgreSQL, contas, configuracoes, mensagens e perfis do Chrome.
- Aplicativo Android e cache web atualizados para a versao 1.0.7.

## Peralta Chat Server V1.0.6 — importacao da sessao da V4.83

- Confirmado pelos cookies da VPS que o Google bloqueou a autenticacao antes de criar uma sessao valida.
- Adicionado **Importar sessao da V4.83** no painel de cada usuario.
- Incluido **Peralta Session Exporter V1.0.1** separado: ele encontra `BrowserData\ChromeProfile` ao lado do EXE, le uma copia temporaria com o Chrome do Windows e nao altera a V4.83.
- Corrigida a resposta `VoidTaskResult` do Windows PowerShell que fazia a exportacao terminar com o erro de propriedade `cookies` ausente.
- O servidor aceita somente o formato oficial do exportador, ate 2 MB e apenas cookies dos dominios Google/YouTube.
- A transferencia exige conta autenticada e protecao CSRF; os valores dos cookies nunca sao gravados em logs ou auditoria.
- Durante a importacao, o monitor individual pausa, grava os cookies no perfil Linux, confirma a persistencia e volta automaticamente.
- O exportador esta disponivel para download dentro do painel e tambem como ZIP separado.
- Adicionada migracao direta da V1.0.5 preservando PostgreSQL, contas, configuracoes e perfis.
- Aplicativo Android e cache web atualizados para a versao 1.0.6.

## Peralta Chat Server V1.0.5 — abas automaticas e conclusao do login

- Confirmado no servidor que o arquivo de cookies foi salvo e atualizado corretamente pela V1.0.4.
- Corrigido `Target.createTarget: Failed to open a new tab`: o Chrome automatico agora conserva uma aba interna vazia enquanto valida e utiliza novas abas.
- A deteccao consulta os cookies antes de criar uma pagina; uma sessao ja salva pode ser reconhecida mesmo em uma VPS lenta.
- Ao clicar em **Concluir login**, a atualizacao periodica da imagem e interrompida antes do fechamento do Chrome.
- Respostas atrasadas de captura deixam de sobrescrever a tela com `Falha interna do servidor` durante a conclusao.
- Se a verificacao principal falhar, a janela manual e encerrada corretamente em vez de continuar repetindo requisicoes invalidas.
- Adicionada migracao direta da V1.0.4 que preserva o cookie existente, o banco, as contas e todas as configuracoes.
- Aplicativo Android e cache web atualizados para a versao 1.0.5.

## Peralta Chat Server V1.0.4 — persistencia e deteccao da conta

- O Chrome manual agora recebe um fechamento normal ao concluir, permitindo gravar cookies e estado do perfil antes do encerramento forcado de seguranca.
- A verificacao da conta volta a seguir a regra estavel da V4.83: cookie, estado `LOGGED_IN` ou avatar podem confirmar a sessao individualmente.
- Removida a exigencia incorreta de cookie **e** interface carregada ao mesmo tempo, que causava falso aviso de sessao desconectada em VPS lenta.
- A verificacao da pagina aguarda ate seis segundos pelos sinais visuais quando ainda nao encontrou cookie.
- Chrome manual e automatico usam explicitamente o mesmo backend do perfil no Linux (`--password-store=basic`); o gerenciador de senhas continua desativado pela politica do projeto.
- Adicionada migracao direta da V1.0.3, preservando banco, contas, configuracoes e perfis.
- Aplicativo Android e cache web atualizados para a versao 1.0.4.

## Peralta Chat Server V1.0.3 — compatibilidade do sandbox do Chrome

- Corrigido o `SIGTRAP` que encerrava o Chrome ao usar **Abrir login do YouTube** em determinados hosts Docker/VPS.
- O Chrome manual agora inicia sem o sandbox interno incompatível; o processo permanece sem root e isolado no container do servidor.
- Desativados o relatorio de falhas e o Breakpad no Chrome manual para reduzir processos e mensagens desnecessarias na VPS.
- O diagnostico passa a priorizar a falha relevante e ignora ruido comum de DBus e `scaling_cur_freq`.
- Adicionada migracao direta da V1.0.2 que preserva `.env`, PostgreSQL, contas, configuracoes e perfis do Chrome.
- Aplicativo Android e cache web atualizados para a versao 1.0.3.

## Peralta Chat Server V1.0.2 — correcao do login no Chrome da VPS

- Corrigida a abertura do login manual quando o Chrome nao informa a janela pelo PID no Linux.
- Deteccao da janela agora tenta PID, classe, nome da classe, titulo e janela ativa; se o identificador nao estiver disponivel, a tela isolada continua funcionando.
- Telas virtuais antigas ou ja ocupadas sao ignoradas e a autenticacao X da tela principal nao e herdada.
- Chrome manual usa configuracao mais leve para VPS pequenas e agora informa quando foi encerrado por sinal, inclusive em caso provavel de falta de memoria.
- Adicionado preparo opcional de 2 GB de swap para VPS com apenas 1 GB de RAM e sem swap.
- O Chrome automatico valida a abertura de uma aba ao iniciar e recria o contexto sozinho se ele ficar inutilizavel.
- Adicionada migracao direta da V1.0.1 que preserva `.env`, PostgreSQL, contas, configuracoes e perfis do Chrome.
- Aplicativo Android e cache web atualizados para a versao 1.0.2.

## Peralta Chat Server V1.0.1 — instalacao limpa

- Pacote completo para instalar do zero em um servidor novo; nao exige nem reaproveita a V1.0.0.
- Login do Google transferido para um Chrome normal em tela isolada, sem Playwright conectado durante a autenticacao.
- Automacao da conta suspensa somente enquanto a tela manual esta aberta e retomada automaticamente ao concluir, cancelar ou expirar.
- Controle remoto manual por imagem, clique, teclado e rolagem, sem expor porta VNC e sem gravar o texto digitado.
- Senha do Google impedida de entrar no gerenciador de senhas do Chrome por politica administrada.
- Correcao definitiva da tela administrativa que permanecia visivel sobre o painel depois do login.
- Arquivos web versionados e cache do aplicativo renovado para evitar interface antiga no navegador ou celular.
- Instalador valida dominio e usuario e exige a confirmacao da senha administrativa.
- Aplicativo Android atualizado para a versao 1.0.1.

## Peralta Chat Server V1.0.0 — projeto novo

- Projeto de servidor separado; nao atualiza nem modifica o Peralta Chat V4.83.
- Painel responsivo de usuario pelo navegador.
- Painel administrativo exclusivo em `/dbmadmin`.
- Aplicativo Android controlador, sem area administrativa.
- Contas criadas somente pelo administrador e troca obrigatoria da senha temporaria.
- Processo e perfil persistente do Chrome separados por usuario.
- PostgreSQL interno com separacao de dados por usuario.
- Descoberta de lives pelo HTML publico de `/streams` e da pagina de video, sem YouTube Data API.
- Busca global padrao de 180 segundos, editavel apenas pelo administrador.
- Canais, listas, intervalos, pausa, repeticao e embaralhamento atualizados em tempo real ao salvar.
- Docker Compose em segundo plano com reinicio automatico.
- HTTPS automatico para `peraltaultrachat.shop` pelo Caddy.
