import { api, escapeHtml, formatDate, setBusy, toast } from './common.js?v=1.0.6';

const loginSection = document.querySelector('#admin-login');
const dashboard = document.querySelector('#admin-dashboard');
const credentialDialog = document.querySelector('#credential-dialog');
let snapshot = null;
let refreshTimer = null;
let lastCredential = null;

await initialize();

async function initialize() {
  try {
    const me = await api('/api/auth/me');
    if (me.user.role === 'admin') return openDashboard(me.user);
  } catch { /* show admin login */ }
  loginSection.hidden = false;
}

document.querySelector('#admin-login-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const button = form.querySelector('button');
  const errorBox = form.querySelector('[data-error]');
  const data = new FormData(form);
  errorBox.textContent = '';
  setBusy(button, true, 'Entrando…');
  try {
    await api('/api/auth/login', { method: 'POST', body: { username: data.get('username'), password: data.get('password'), audience: 'admin' } });
    const me = await api('/api/auth/me');
    await openDashboard(me.user);
  } catch (error) { errorBox.textContent = error.message; }
  finally { setBusy(button, false); }
});

async function openDashboard(user) {
  loginSection.hidden = true;
  dashboard.hidden = false;
  document.querySelector('#admin-user').textContent = user.displayName;
  await refresh();
  clearInterval(refreshTimer);
  refreshTimer = setInterval(() => void refresh(), 5000);
}

async function refresh() {
  try {
    snapshot = await api('/api/dbmadmin/snapshot');
    render();
  } catch (error) {
    if (error.status === 401 || error.status === 403) location.reload();
    else toast(error.message, true);
  }
}

function render() {
  const users = snapshot.users;
  document.querySelector('#total-users').textContent = users.length;
  document.querySelector('#active-users').textContent = users.filter((user) => user.status === 'active' && (!user.expires_at || new Date(user.expires_at) > new Date())).length;
  document.querySelector('#online-processes').textContent = Object.values(snapshot.runtimes).filter((runtime) => runtime.state === 'online').length;
  document.querySelector('#users-badge').textContent = `${users.length} conta(s)`;
  if (document.activeElement !== document.querySelector('#global-scan')) document.querySelector('#global-scan').value = snapshot.scanIntervalSeconds;
  const tbody = document.querySelector('#users-table');
  if (!users.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty-cell">Nenhuma conta de usuário criada.</td></tr>';
  } else {
    tbody.innerHTML = users.map((user) => {
      const runtime = snapshot.runtimes[user.id] || { state: 'offline' };
      const expired = user.expires_at && new Date(user.expires_at) <= new Date();
      const access = user.status === 'suspended' ? 'Suspensa' : expired ? 'Expirada' : 'Ativa';
      const accessClass = access === 'Ativa' ? 'good' : 'bad';
      return `<tr>
        <td><strong>${escapeHtml(user.display_name)}</strong><br><small>${escapeHtml(user.username)}</small></td>
        <td><span class="badge ${accessClass}">${access}</span>${user.must_change_password ? '<br><small>Senha temporária</small>' : ''}</td>
        <td><span class="badge ${user.youtube_status === 'connected' ? 'good' : 'neutral'}">${user.youtube_status === 'connected' ? 'Conectado' : 'Pendente'}</span><br><small>${escapeHtml(user.channel_handle || '')}</small></td>
        <td>${user.channel_count}/${user.max_channels}</td>
        <td><span class="badge ${runtime.state === 'online' ? 'good' : 'neutral'}">${runtime.state === 'online' ? (runtime.running ? 'Rodando' : 'Online') : 'Offline'}</span><br><small>${runtime.activeLives || 0} chat(s)</small></td>
        <td>${formatDate(user.expires_at, false)}</td>
        <td><div class="table-actions">
          <button class="mini-action" data-action="${user.status === 'active' ? 'suspend' : 'activate'}" data-user="${user.id}">${user.status === 'active' ? 'Suspender' : 'Ativar'}</button>
          <button class="mini-action" data-action="edit" data-user="${user.id}">Editar</button>
          <button class="mini-action" data-action="reset" data-user="${user.id}">Nova senha</button>
          <button class="mini-action" data-action="restart" data-user="${user.id}">Reiniciar processo</button>
          <button class="mini-action delete" data-action="delete" data-user="${user.id}">Excluir</button>
        </div></td>
      </tr>`;
    }).join('');
  }
  const auditList = document.querySelector('#audit-list');
  auditList.innerHTML = snapshot.audit.length ? snapshot.audit.map((item) => `<div class="log-row"><time>${formatDate(item.created_at)}</time><span><b>${escapeHtml(item.actor_username || 'sistema')}</b> · ${escapeHtml(auditLabel(item.action))}${item.target_username ? ` · ${escapeHtml(item.target_username)}` : ''}</span></div>`).join('') : '<p class="empty-state">Nenhuma alteração registrada.</p>';
}

document.querySelector('#create-user-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const button = form.querySelector('button[type="submit"]');
  const data = new FormData(form);
  const expires = data.get('expiresAt');
  const body = {
    displayName: data.get('displayName'), username: data.get('username'),
    password: data.get('password') || undefined,
    expiresAt: expires ? new Date(`${expires}T23:59:59`).toISOString() : null,
    maxChannels: Number(data.get('maxChannels')),
  };
  setBusy(button, true, 'Criando…');
  try {
    const result = await api('/api/dbmadmin/users', { method: 'POST', body });
    lastCredential = { username: String(data.get('username')).toLowerCase(), password: result.temporaryPassword };
    document.querySelector('#credential-user').textContent = lastCredential.username;
    document.querySelector('#credential-password').textContent = lastCredential.password;
    credentialDialog.showModal();
    form.reset();
    form.querySelector('[name="maxChannels"]').value = 20;
    await refresh();
  } catch (error) { toast(error.message, true); }
  finally { setBusy(button, false); }
});

document.querySelector('#global-settings-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button');
  const seconds = Number(document.querySelector('#global-scan').value);
  setBusy(button, true, 'Aplicando…');
  try { await api('/api/dbmadmin/settings', { method: 'PATCH', body: { scanIntervalSeconds: seconds } }); await refresh(); toast(`Busca global alterada para ${seconds} segundos em todas as contas.`); }
  catch (error) { toast(error.message, true); }
  finally { setBusy(button, false); }
});

document.querySelector('#users-table').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  const user = snapshot.users.find((item) => item.id === button.dataset.user);
  if (!user) return;
  const action = button.dataset.action;
  setBusy(button, true);
  try {
    if (action === 'suspend' || action === 'activate') {
      await api(`/api/dbmadmin/users/${user.id}`, { method: 'PATCH', body: { status: action === 'suspend' ? 'suspended' : 'active' } });
      toast(action === 'suspend' ? 'Conta suspensa e sessões encerradas.' : 'Conta reativada.');
    } else if (action === 'restart') {
      await api(`/api/dbmadmin/users/${user.id}/restart`, { method: 'POST' });
      toast('Processo isolado reiniciado.');
    } else if (action === 'reset') {
      if (!confirm(`Gerar uma nova senha temporária para ${user.username}?`)) return;
      const result = await api(`/api/dbmadmin/users/${user.id}/reset-password`, { method: 'POST' });
      lastCredential = { username: user.username, password: result.temporaryPassword };
      document.querySelector('#credential-user').textContent = lastCredential.username;
      document.querySelector('#credential-password').textContent = lastCredential.password;
      credentialDialog.showModal();
    } else if (action === 'delete') {
      if (!confirm(`EXCLUIR definitivamente a conta ${user.username}, os dados e o perfil do Chrome?`)) return;
      await api(`/api/dbmadmin/users/${user.id}`, { method: 'DELETE' });
      toast('Conta e perfil removidos.');
    } else if (action === 'edit') {
      const maxChannelsText = prompt('Novo limite de canais:', String(user.max_channels));
      if (maxChannelsText === null) return;
      const expiresText = prompt('Expiração no formato AAAA-MM-DD (vazio = sem prazo):', user.expires_at ? new Date(user.expires_at).toISOString().slice(0, 10) : '');
      if (expiresText === null) return;
      await api(`/api/dbmadmin/users/${user.id}`, { method: 'PATCH', body: {
        maxChannels: Number(maxChannelsText),
        expiresAt: expiresText ? new Date(`${expiresText}T23:59:59`).toISOString() : null,
      } });
      toast('Limites da conta atualizados.');
    }
    await refresh();
  } catch (error) { toast(error.message, true); }
  finally { setBusy(button, false); }
});

document.querySelector('#copy-credential').addEventListener('click', async () => {
  if (!lastCredential) return;
  const text = `Peralta Chat Server\nEndereco: ${location.origin}\nUsuario: ${lastCredential.username}\nSenha temporaria: ${lastCredential.password}`;
  try { await navigator.clipboard.writeText(text); toast('Dados copiados.'); }
  catch { toast('Não foi possível copiar automaticamente.', true); }
});
document.querySelector('[data-close-credential]').addEventListener('click', () => credentialDialog.close());
document.querySelector('#admin-refresh').addEventListener('click', () => void refresh());
document.querySelector('#admin-logout').addEventListener('click', async () => { try { await api('/api/auth/logout', { method: 'POST' }); } finally { location.reload(); } });

function auditLabel(action) {
  return ({
    'auth.login': 'entrou no painel', 'user.created': 'criou uma conta', 'user.updated': 'alterou uma conta',
    'user.deleted': 'excluiu uma conta', 'user.password_reset': 'gerou nova senha',
    'runtime.restarted': 'reiniciou um processo', 'settings.scan_interval_changed': 'alterou a busca global',
    'password.changed': 'trocou a própria senha',
  })[action] || action;
}
