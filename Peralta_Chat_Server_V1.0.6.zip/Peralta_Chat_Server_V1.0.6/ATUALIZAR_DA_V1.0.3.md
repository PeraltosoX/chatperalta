# Atualizar da V1.0.3 para a V1.0.6 sem perder dados

Esta atualizacao corrige a gravacao e a identificacao da sessao depois do login manual. PostgreSQL, contas, configuracoes e perfis do Chrome sao preservados.

Nunca execute `docker compose down -v`: a opcao `-v` apaga os volumes.

## 1. Fazer backup da V1.0.3

```bash
cd /opt/Peralta_Chat_Server_V1.0.3
./scripts/backup.sh
```

## 2. Aplicar a V1.0.6

Depois de enviar e descompactar `Peralta_Chat_Server_V1.0.6.zip` em `/opt`:

```bash
cd /opt/Peralta_Chat_Server_V1.0.6
chmod +x scripts/*.sh
./scripts/migrar-da-v1.0.3.sh
```

O script copia o `.env` sem mostrar senhas, recompila o container e usa os mesmos volumes da instalacao anterior.

## 3. Importar a sessao da V4.83

No painel, baixe o **Peralta Session Exporter para Windows**. Com a V4.83 e o Chrome aberto por ela fechados, execute o exportador, selecione `BrowserData\ChromeProfile` e importe o JSON em **Importar sessao da V4.83**. Apague o JSON depois da confirmacao.

Confira:

```bash
curl -sS https://peraltaultrachat.shop/healthz
docker compose logs --since=5m --tail=100 server
```

A saude deve informar `"version":"1.0.6"`.
