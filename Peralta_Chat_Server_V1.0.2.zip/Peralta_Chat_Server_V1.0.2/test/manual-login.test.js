import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildManualChromeArguments,
  buildManualDisplayEnvironment,
  MANUAL_LOGIN_HEIGHT,
  MANUAL_LOGIN_WIDTH,
  normalizeManualAction,
  parseWindowIds,
} from '../src/services/manual-login-session.js';

test('Chrome manual nao recebe sinalizadores de automacao ou depuracao remota', () => {
  const args = buildManualChromeArguments('/tmp/perfil-teste');
  assert.ok(args.includes('--user-data-dir=/tmp/perfil-teste'));
  assert.ok(args.some((value) => value.includes('accounts.google.com/ServiceLogin')));
  assert.equal(args.some((value) => /automation|remote-debugging|headless/i.test(value)), false);
  assert.ok(args.includes('--disable-gpu'));
  assert.ok(args.includes('--renderer-process-limit=2'));
});

test('tela isolada nao herda autenticacao X e interpreta janelas com seguranca', () => {
  const environment = buildManualDisplayEnvironment({
    LANG: 'pt_BR.UTF-8',
    XAUTHORITY: '/tmp/arquivo-da-tela-principal',
    TESTE: 'preservado',
  }, ':147');
  assert.equal(environment.DISPLAY, ':147');
  assert.equal(environment.XAUTHORITY, undefined);
  assert.equal(environment.TESTE, 'preservado');
  assert.deepEqual(parseWindowIds('0\n4194307\nlixo\n4194308\n'), ['4194307', '4194308']);
});

test('acoes da tela manual sao limitadas e texto segue pela entrada padrao', () => {
  assert.deepEqual(normalizeManualAction({ action: 'click', x: -50, y: 99_999 }).args,
    ['mousemove', '--sync', '0', String(MANUAL_LOGIN_HEIGHT - 1), 'click', '1']);
  assert.deepEqual(normalizeManualAction({ action: 'click', x: MANUAL_LOGIN_WIDTH - 1, y: 0 }).args,
    ['mousemove', '--sync', String(MANUAL_LOGIN_WIDTH - 1), '0', 'click', '1']);
  const typed = normalizeManualAction({ action: 'type', text: 'segredo-de-teste' });
  assert.equal(typed.input, 'segredo-de-teste');
  assert.deepEqual(typed.args.slice(-2), ['--file', '-']);
  assert.throws(() => normalizeManualAction({ action: 'key', key: 'F12' }), /nao permitida/i);
  assert.throws(() => normalizeManualAction({ action: 'wheel', deltaY: 0 }), /rolagem invalido/i);
});
