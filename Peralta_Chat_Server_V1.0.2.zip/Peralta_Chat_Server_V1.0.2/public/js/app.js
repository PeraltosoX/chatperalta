import { api, escapeHtml, formatDate, setBusy, toast } from './common.js?v=1.0.2';

const dashboard = document.querySelector('#dashboard');
const passwordDialog = document.querySelector('#password-dialog');
const youtubeDialog = document.querySelector('#youtube-dialog');
let snapshot = null;
let messageTarget = 'global';
let messagesDirty = false;
let settingsDirty = false;
let refreshTimer = null;
let browserTimer = null;
let browserBusy = false;

await bootstrap();

async function bootstrap() {
  try {
    const me = await api('/api/auth/me');
    if (me.user.role !== 'user') return location.replace('/');
    document.querySelector('#user-label').textContent = me.user.displayName;
    if (me.user.mustChangePassword) {
      passwordDialog.showModal();
      passwordDialog.addEventListener('cancel', (event) => event.preventDefault());
      return;
    }
    dashboard.hidden = false;
    await refresh(true);
    clearInterval(refreshTimer);
    refreshTimer = setInterval(() => void refresh(false), 3500);
  } catch (error) {
    if (error.status === 401) location.replace('/');
    else toast(error.message, true);
  }
}

async function refresh(full = false) {
  try {
    const next = await api('/api/app/snapshot');
    snapshot = next;
    render(full);
    document.querySelector('#sync-label').textContent = `Atualizado ${new Date().toLocaleTimeString('pt-BR')}`;
  } catch (error) {
    document.querySelector('#sync-label').textContent = 'Falha ao sincronizar';
    if (error.status === 401) location.replace('/');
  }
}

function render(full) {
  const runtime = snapshot.runtime || {};
  const running = Boolean(runtime.running);
  const manualLogin = Boolean(runtime.manualLogin);
  document.querySelector('#runtime-status').textContent = runtime.state === 'offline' ? 'Reiniciando' : manualLogin ? 'Login manual' : running ? (snapshot.settings.paused ? 'Pausado' : 'Rodando') : 'Parado';
  document.querySelector('#runtime-detail').textContent = manualLogin ? 'Automação suspensa com segurança' : runtime.pid ? `Processo #${runtime.pid}` : 'Processo individual';
  document.querySelector('#active-lives').textContent = String(runtime.activeLives || 0);
  document.querySelector('#scan-interval').textContent = formatInterval(snapshot.scanIntervalSeconds * 1000);

  const profile = snapshot.youtubeProfile || { status: 'disconnected' };
  const connected = profile.status === 'connected';
  document.querySelector('#youtube-status').textContent = connected ? 'Conectado' : profile.status === 'checking' ? 'Verificando' : 'Desconectado';
  document.querySelector('#youtube-handle').textContent = profile.channel_handle || profile.channel_name || 'Conta não verificada';
  const badge = document.querySelector('#youtube-badge');
  badge.textContent = connected ? 'Conectado' : 'Desconectado';
  badge.className = `badge ${connected ? 'good' : 'neutral'}`;

  renderChannels();
  renderMessageTargets(full);
  renderLives();
  renderLogs();
  if ((full || !settingsDirty) && !document.querySelector('#settings-form').contains(document.activeElement)) renderSettings();
}

function renderSettings() {
  const value = Number(snapshot.settings.message_interval_ms || 30_000);
  document.querySelector('#minutes').value = Math.floor(value / 60_000);
  document.querySelector('#seconds').value = Math.floor((value % 60_000) / 1000);
  document.querySelector('#milliseconds').value = value % 1000;
  document.querySelector('#repeat-messages').checked = snapshot.settings.repeat_messages;
  document.querySelector('#shuffle-messages').checked = snapshot.settings.shuffle_messages;
  document.querySelector('#per-channel').checked = snapshot.settings.use_per_channel_messages;
  settingsDirty = false;
}

function renderChannels() {
  const list = document.querySelector('#channel-list');
  document.querySelector('#channel-count').textContent = `${snapshot.channels.length}/${snapshot.user.maxChannels}`;
  if (!snapshot.channels.length) {
    list.className = 'channel-list empty-state';
    list.textContent = 'Nenhum canal adicionado.';
    return;
  }
  list.className = 'channel-list';
  list.innerHTML = snapshot.channels.map((channel) => `
    <div class="channel-row ${channel.enabled ? '' : 'disabled'}">
      <label class="toggle-row" title="Ativar ou desativar canal"><input type="checkbox" data-channel-toggle="${channel.id}" ${channel.enabled ? 'checked' : ''}><i></i></label>
      <div class="channel-info"><b>${escapeHtml(channel.label)}</b><small title="${escapeHtml(channel.normalized_url)}">${escapeHtml(channel.normalized_url)}</small></div>
      <div class="channel-actions"><button class="mini-action" data-message-channel="${channel.id}">Mensagens</button><button class="mini-action delete" data-channel-delete="${channel.id}">Excluir</button></div>
    </div>`).join('');
}

function renderMessageTargets(force) {
  const select = document.querySelector('#message-target');
  const perChannel = Boolean(snapshot.settings.use_per_channel_messages);
  const validIds = new Set(snapshot.channels.map((channel) => channel.id));
  if (!perChannel) messageTarget = 'global';
  else if (messageTarget !== 'global' && !validIds.has(messageTarget)) messageTarget = snapshot.channels[0]?.id || 'global';
  if (perChannel && messageTarget === 'global' && snapshot.channels.length) messageTarget = snapshot.channels[0].id;
  const wanted = perChannel
    ? snapshot.channels.map((channel) => `<option value="${channel.id}">${escapeHtml(channel.label)}</option>`).join('')
    : '<option value="global">Lista global para todos os canais</option>';
  if (select.innerHTML !== wanted) select.innerHTML = wanted;
  select.disabled = !perChannel;
  select.value = messageTarget;
  if (force || !messagesDirty) fillMessageEditor();
}

function fillMessageEditor() {
  const channelId = messageTarget === 'global' ? null : messageTarget;
  const messages = snapshot.messages
    .filter((message) => channelId ? message.channel_id === channelId : message.channel_id === null)
    .sort((a, b) => a.position - b.position)
    .map((message) => message.content);
  document.querySelector('#message-list').value = messages.join('\n');
  document.querySelector('#message-count').textContent = `${messages.length} mensagem(ns)`;
  messagesDirty = false;
}

function renderLives() {
  const tbody = document.querySelector('#live-table');
  if (!snapshot.lives.length) {
    tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">Nenhuma live encontrada ainda.</td></tr>';
    return;
  }
  tbody.innerHTML = snapshot.lives.map((live) => `<tr><td>${escapeHtml(live.channel_name || 'Canal')}</td><td><strong>${escapeHtml(live.title)}</strong><br><small>${escapeHtml(live.video_id)}</small></td><td><span class="badge ${statusClass(live.status)}">${escapeHtml(live.status)}</span></td><td>${live.sent}</td><td>${live.failures}</td><td>${formatDate(live.last_activity_at)}</td></tr>`).join('');
}

function renderLogs() {
  const element = document.querySelector('#logs');
  if (!snapshot.logs.length) { element.innerHTML = '<p class="empty-state">Sem registros.</p>'; return; }
  element.innerHTML = snapshot.logs.map((log) => `<div class="log-row ${log.level === 'error' ? 'error' : ''}"><time>${formatDate(log.created_at)}</time><span>${escapeHtml(log.message)}</span></div>`).join('');
}

document.querySelector('#password-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = new FormData(form);
  const errorBox = form.querySelector('[data-error]');
  if (data.get('newPassword') !== data.get('confirmation')) { errorBox.textContent = 'A confirmação não é igual à nova senha.'; return; }
  const button = form.querySelector('button');
  setBusy(button, true, 'Salvando…');
  try {
    await api('/api/auth/change-password', { method: 'POST', body: { currentPassword: data.get('currentPassword'), newPassword: data.get('newPassword') } });
    passwordDialog.close();
    dashboard.hidden = false;
    await refresh(true);
    refreshTimer = setInterval(() => void refresh(false), 3500);
    toast('Senha pessoal criada.');
  } catch (error) { errorBox.textContent = error.message; }
  finally { setBusy(button, false); }
});

document.querySelector('#settings-form').addEventListener('input', () => { settingsDirty = true; });
document.querySelector('#settings-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button[type="submit"]');
  const interval = Number(document.querySelector('#minutes').value) * 60_000 + Number(document.querySelector('#seconds').value) * 1000 + Number(document.querySelector('#milliseconds').value);
  setBusy(button, true, 'Salvando…');
  try {
    await api('/api/app/settings', { method: 'PATCH', body: {
      messageIntervalMs: interval,
      repeatMessages: document.querySelector('#repeat-messages').checked,
      shuffleMessages: document.querySelector('#shuffle-messages').checked,
      usePerChannelMessages: document.querySelector('#per-channel').checked,
    } });
    settingsDirty = false;
    await refresh(true);
    toast('Configuração aplicada sem reiniciar.');
  } catch (error) { toast(error.message, true); }
  finally { setBusy(button, false); }
});

document.querySelector('#channel-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const button = form.querySelector('button');
  const data = new FormData(form);
  setBusy(button, true, 'Adicionando…');
  try {
    await api('/api/app/channels', { method: 'POST', body: { url: data.get('url') } });
    form.reset();
    await refresh(true);
    toast('Canal adicionado e verificação imediata solicitada.');
  } catch (error) { toast(error.message, true); }
  finally { setBusy(button, false); }
});

document.querySelector('#channel-list').addEventListener('change', async (event) => {
  const id = event.target.dataset.channelToggle;
  if (!id) return;
  try {
    await api(`/api/app/channels/${id}`, { method: 'PATCH', body: { enabled: event.target.checked } });
    await refresh(true);
    toast(event.target.checked ? 'Canal ativado.' : 'Canal desativado; mensagens preservadas.');
  } catch (error) { event.target.checked = !event.target.checked; toast(error.message, true); }
});

document.querySelector('#channel-list').addEventListener('click', async (event) => {
  const messageId = event.target.dataset.messageChannel;
  if (messageId) {
    if (!snapshot.settings.use_per_channel_messages) return toast('Ative “Mensagens por canal” e salve primeiro.', true);
    messageTarget = messageId;
    document.querySelector('#message-target').value = messageTarget;
    fillMessageEditor();
    document.querySelector('#message-list').focus();
    return;
  }
  const deleteId = event.target.dataset.channelDelete;
  if (!deleteId) return;
  const channel = snapshot.channels.find((item) => item.id === deleteId);
  if (!confirm(`Excluir ${channel?.label || 'este canal'} e suas mensagens? Para apenas pausar, use o botão de ativação.`)) return;
  try { await api(`/api/app/channels/${deleteId}`, { method: 'DELETE' }); await refresh(true); toast('Canal excluído.'); }
  catch (error) { toast(error.message, true); }
});

document.querySelector('#message-target').addEventListener('change', (event) => { messageTarget = event.target.value; fillMessageEditor(); });
document.querySelector('#message-list').addEventListener('input', () => {
  messagesDirty = true;
  const count = document.querySelector('#message-list').value.split('\n').filter((line) => line.trim()).length;
  document.querySelector('#message-count').textContent = `${count} mensagem(ns) não salva(s)`;
});
document.querySelector('#save-messages').addEventListener('click', async (event) => {
  const button = event.currentTarget;
  const messages = document.querySelector('#message-list').value.split('\n').map((line) => line.trim()).filter(Boolean);
  const path = messageTarget === 'global' ? '/api/app/messages/global' : `/api/app/channels/${messageTarget}/messages`;
  setBusy(button, true, 'Salvando…');
  try { await api(path, { method: 'PUT', body: { messages } }); messagesDirty = false; await refresh(true); toast('Mensagens aplicadas aos chats em execução.'); }
  catch (error) { toast(error.message, true); }
  finally { setBusy(button, false); }
});

document.querySelectorAll('[data-runtime]').forEach((button) => button.addEventListener('click', async () => {
  const action = button.dataset.runtime;
  try { await api(`/api/app/runtime/${action}`, { method: 'POST' }); await refresh(true); toast('Comando aplicado ao seu processo.'); }
  catch (error) { toast(error.message, true); }
}));

document.querySelector('#refresh').addEventListener('click', () => void refresh(true));
document.querySelector('#logout').addEventListener('click', async () => { try { await api('/api/auth/logout', { method: 'POST' }); } finally { location.replace('/'); } });

document.querySelector('#check-youtube').addEventListener('click', async (event) => {
  setBusy(event.currentTarget, true, 'Verificando…');
  try { const result = await api('/api/app/youtube/check', { method: 'POST' }); toast(result.status === 'connected' ? 'Conta do YouTube conectada.' : 'Sessão desconectada.'); await refresh(true); }
  catch (error) { toast(error.message, true); }
  finally { setBusy(event.currentTarget, false); }
});
document.querySelector('#open-youtube-login').addEventListener('click', async (event) => {
  setBusy(event.currentTarget, true, 'Abrindo Chrome…');
  try {
    const result = await api('/api/app/youtube/login/start', { method: 'POST' });
    updateBrowser(result);
    youtubeDialog.showModal();
    browserTimer = setInterval(() => void updateBrowserFromServer(), 2500);
  } catch (error) { toast(error.message, true); }
  finally { setBusy(event.currentTarget, false); }
});

document.querySelector('#browser-screen-button').addEventListener('click', async (event) => {
  if (browserBusy) return;
  const image = document.querySelector('#browser-screen');
  const rect = image.getBoundingClientRect();
  await browserAction({ action: 'click', x: (event.clientX - rect.left) * 1100 / rect.width, y: (event.clientY - rect.top) * 760 / rect.height });
  document.querySelector('#browser-text').focus();
});
document.querySelector('#browser-screen-button').addEventListener('wheel', (event) => {
  event.preventDefault();
  if (!browserBusy) void browserAction({ action: 'wheel', deltaY: event.deltaY });
}, { passive: false });
document.querySelector('#browser-type-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const input = document.querySelector('#browser-text');
  const text = input.value;
  input.value = '';
  if (text) await browserAction({ action: 'type', text });
});
document.querySelectorAll('[data-key]').forEach((button) => button.addEventListener('click', () => void browserAction({ action: 'key', key: button.dataset.key })));
document.querySelectorAll('[data-wheel]').forEach((button) => button.addEventListener('click', () => void browserAction({ action: 'wheel', deltaY: Number(button.dataset.wheel) })));
document.querySelector('#finish-youtube').addEventListener('click', async (event) => {
  setBusy(event.currentTarget, true, 'Verificando…');
  try {
    const result = await api('/api/app/youtube/login/finish', { method: 'POST' });
    if (result.status === 'connected') { closeBrowserDialog(false); await refresh(true); toast('Conta do YouTube conectada e salva no perfil do servidor.'); }
    else { await closeBrowserDialog(false); await refresh(true); toast('O YouTube ainda não confirmou a sessão. Abra o Chrome manual e conclua todas as etapas do Google.', true); }
  } catch (error) { toast(error.message, true); }
  finally { setBusy(event.currentTarget, false); }
});
document.querySelector('[data-close-dialog]').addEventListener('click', () => void closeBrowserDialog(true));
youtubeDialog.addEventListener('cancel', (event) => { event.preventDefault(); void closeBrowserDialog(true); });

async function browserAction(body) {
  browserBusy = true;
  try { updateBrowser(await api('/api/app/youtube/login/interact', { method: 'POST', body })); }
  catch (error) { document.querySelector('#browser-message').textContent = error.message; toast(error.message, true); }
  finally { browserBusy = false; }
}

async function updateBrowserFromServer() {
  if (!youtubeDialog.open || browserBusy) return;
  browserBusy = true;
  try { updateBrowser(await api('/api/app/youtube/login/snapshot')); }
  catch (error) { document.querySelector('#browser-message').textContent = error.message; }
  finally { browserBusy = false; }
}

function updateBrowser(result) {
  document.querySelector('#browser-screen').src = result.image;
  document.querySelector('#browser-host').textContent = result.urlHost || 'Google';
  document.querySelector('#browser-title').textContent = result.title || 'Login do Google';
  if (Number.isFinite(result.expiresInSeconds)) {
    const minutes = Math.max(1, Math.ceil(result.expiresInSeconds / 60));
    document.querySelector('#browser-message').textContent = `Tela manual isolada · encerra após ${minutes} min sem interação.`;
  }
}

async function closeBrowserDialog(cancelRemote) {
  clearInterval(browserTimer);
  browserTimer = null;
  if (youtubeDialog.open) youtubeDialog.close();
  if (cancelRemote) await api('/api/app/youtube/login/cancel', { method: 'POST' }).catch(() => {});
}

function statusClass(status) {
  const value = String(status || '').toUpperCase();
  if (/ENVIANDO|CONECTADO|ATIVO/.test(value)) return 'good';
  if (/FALHA|ERRO|ENCERRADO|PARADO/.test(value)) return 'bad';
  if (/AGUARDANDO|PAUSADO|CONECTANDO|PROGRAMADA/.test(value)) return 'warn';
  return 'neutral';
}

function formatInterval(milliseconds) {
  const minutes = Math.floor(milliseconds / 60_000);
  const seconds = Math.floor((milliseconds % 60_000) / 1000);
  if (minutes && !seconds) return `${minutes} min`;
  if (minutes) return `${minutes} min ${seconds} s`;
  return `${seconds || milliseconds} ${seconds ? 's' : 'ms'}`;
}
