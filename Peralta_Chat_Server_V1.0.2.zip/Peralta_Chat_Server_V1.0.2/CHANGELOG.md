# Historico de versoes

## Peralta Chat Server V1.0.2 — correcao do login no Chrome da VPS

- Corrigida a abertura do login manual quando o Chrome nao informa a janela pelo PID no Linux.
- Deteccao da janela agora tenta PID, classe, nome da classe, titulo e janela ativa; se o identificador nao estiver disponivel, a tela isolada continua funcionando.
- Telas virtuais antigas ou ja ocupadas sao ignoradas e a autenticacao X da tela principal nao e herdada.
- Chrome manual usa configuracao mais leve para VPS pequenas e agora informa quando foi encerrado por sinal, inclusive em caso provavel de falta de memoria.
- Adicionado preparo opcional de 2 GB de swap para VPS com apenas 1 GB de RAM e sem swap.
- O Chrome automatico valida a abertura de uma aba ao iniciar e recria o contexto sozinho se ele ficar inutilizavel.
- Adicionada migracao direta da V1.0.1 que preserva `.env`, PostgreSQL, contas, configuracoes e perfis do Chrome.
- Aplicativo Android e cache web atualizados para a versao 1.0.2.

## Peralta Chat Server V1.0.1 — instalacao limpa

- Pacote completo para instalar do zero em um servidor novo; nao exige nem reaproveita a V1.0.0.
- Login do Google transferido para um Chrome normal em tela isolada, sem Playwright conectado durante a autenticacao.
- Automacao da conta suspensa somente enquanto a tela manual esta aberta e retomada automaticamente ao concluir, cancelar ou expirar.
- Controle remoto manual por imagem, clique, teclado e rolagem, sem expor porta VNC e sem gravar o texto digitado.
- Senha do Google impedida de entrar no gerenciador de senhas do Chrome por politica administrada.
- Correcao definitiva da tela administrativa que permanecia visivel sobre o painel depois do login.
- Arquivos web versionados e cache do aplicativo renovado para evitar interface antiga no navegador ou celular.
- Instalador valida dominio e usuario e exige a confirmacao da senha administrativa.
- Aplicativo Android atualizado para a versao 1.0.1.

## Peralta Chat Server V1.0.0 — projeto novo

- Projeto de servidor separado; nao atualiza nem modifica o Peralta Chat V4.83.
- Painel responsivo de usuario pelo navegador.
- Painel administrativo exclusivo em `/dbmadmin`.
- Aplicativo Android controlador, sem area administrativa.
- Contas criadas somente pelo administrador e troca obrigatoria da senha temporaria.
- Processo e perfil persistente do Chrome separados por usuario.
- PostgreSQL interno com separacao de dados por usuario.
- Descoberta de lives pelo HTML publico de `/streams` e da pagina de video, sem YouTube Data API.
- Busca global padrao de 180 segundos, editavel apenas pelo administrador.
- Canais, listas, intervalos, pausa, repeticao e embaralhamento atualizados em tempo real ao salvar.
- Docker Compose em segundo plano com reinicio automatico.
- HTTPS automatico para `peraltaultrachat.shop` pelo Caddy.
