# Atualizar da V1.0.2 para a V1.0.7 sem perder dados

Esta atualizacao corrige a abertura do Chrome usado pelo botao **Abrir login do YouTube** em VPS cujo sandbox do Chrome e incompatível com o ambiente Docker. PostgreSQL, contas, configuracoes e perfis do Chrome sao preservados.

Nunca execute `docker compose down -v`: a opcao `-v` apaga os volumes.

## 1. Fazer backup da V1.0.2

```bash
cd /opt/Peralta_Chat_Server_V1.0.2
./scripts/backup.sh
```

Copie a pasta `backups` para o seu computador quando puder. Ela contem dados sigilosos das contas do YouTube.

## 2. Aplicar a V1.0.7

Depois de enviar e descompactar `Peralta_Chat_Server_V1.0.7.zip` em `/opt`:

```bash
cd /opt/Peralta_Chat_Server_V1.0.7
chmod +x scripts/*.sh
./scripts/migrar-da-v1.0.2.sh
```

O script copia o `.env` sem mostrar senhas, recompila o container e usa os mesmos volumes da instalacao anterior. A recriacao do container tambem encerra qualquer processo que tenha sobrado do teste manual.

## 3. Conferir

```bash
curl -sS https://peraltaultrachat.shop/healthz
docker compose ps
docker compose logs --since=5m --tail=100 server
```

A saude deve informar `"version":"1.0.7"`. Atualize a pagina sem cache e use **Importar sessao da V4.83** com o arquivo criado pelo exportador para Windows.

O login pela VPS continua disponivel apenas como alternativa e ainda pode ser bloqueado pelo Google.
