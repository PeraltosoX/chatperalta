plugins {
    id("com.android.application")
}

val peraltaServerUrl = providers.gradleProperty("PERALTA_SERVER_URL")
    .orElse("https://peraltaultrachat.shop")
    .get()

android {
    namespace = "com.peralta.chatserver"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.peralta.chatserver"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "1.0.7"
        buildConfigField("String", "SERVER_URL", "\"$peraltaServerUrl\"")
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}
