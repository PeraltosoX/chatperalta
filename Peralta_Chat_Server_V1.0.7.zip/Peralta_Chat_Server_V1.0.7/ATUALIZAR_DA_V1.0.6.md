# Atualizar da V1.0.6 para a V1.0.7 sem perder dados

Esta atualizacao corrige o estado em que **Iniciar** mantinha os chats em **Pausado**, impedindo o envio mesmo com a live e a conta conectada. Ela mantem a sessao importada, as contas, os canais, as mensagens e os contadores existentes.

Nunca execute `docker compose down -v`: a opcao `-v` apaga os volumes.

## 1. Fazer backup da V1.0.6

```bash
cd /opt/Peralta_Chat_Server_V1.0.6
./scripts/backup.sh
```

## 2. Aplicar a V1.0.7

Depois de enviar e descompactar `Peralta_Chat_Server_V1.0.7.zip` em `/opt`:

```bash
cd /opt/Peralta_Chat_Server_V1.0.7
chmod +x scripts/*.sh
./scripts/migrar-da-v1.0.6.sh
```

O script copia o `.env`, recompila o container e conecta aos mesmos volumes do PostgreSQL e dos perfis.

## 3. Conferir

```bash
sleep 15
curl -sS https://peraltaultrachat.shop/healthz
docker compose ps
docker compose logs --since=5m --tail=100 server
```

A saude deve informar `"version":"1.0.7"`. Atualize o painel e clique em **Iniciar**; o estado deve mudar de **Pausado** para **Rodando**, e a live localizada deve voltar a enviar.
