# Peralta Chat Server V1.0.7

Projeto novo e independente para controlar pelo navegador ou Android um monitor que fica executando no servidor. A V4.83 foi utilizada apenas como referencia do funcionamento estavel; nenhum arquivo dela e alterado ou substituido.

## Enderecos

- Usuarios e aplicativo: `https://peraltaultrachat.shop/`
- Administrador: `https://peraltaultrachat.shop/dbmadmin`
- Saude do servidor: `https://peraltaultrachat.shop/healthz`

Nao existe rota `/admin`. O painel `/dbmadmin` nao aparece no aplicativo e todas as operacoes administrativas tambem sao bloqueadas no servidor para contas comuns.

## Funcionamento

1. O administrador cria o usuario em `/dbmadmin`.
2. A pessoa entra com a senha temporaria e cria uma senha pessoal.
3. Dentro da propria conta, importa a sessao que ja funciona na V4.83 usando o exportador separado para Windows. O login manual da VPS continua apenas como alternativa, pois o Google pode bloquea-lo.
4. O processo isolado consulta o HTML publico da pagina `/streams` de cada canal a cada 180 segundos por padrao.
5. Candidatos sao conferidos pela pagina publica `watch`, sem YouTube Data API.
6. Ao encontrar live ou programacao com chat, o Chrome daquele usuario abre o chat e envia pela caixa real.
7. Canais, mensagens e intervalos mudam assim que o usuario salva. O intervalo de busca de lives e global e somente o administrador pode altera-lo.

## Componentes

- Node.js 24: painel, autenticacao e gerenciamento dos processos.
- PostgreSQL 17: contas, configuracoes, canais, mensagens, historico e auditoria.
- Peralta Session Exporter: le uma copia temporaria do perfil da V4.83 no Windows e gera o arquivo de transferencia.
- Google Chrome normal em tela isolada: alternativa de autenticacao manual, sujeita ao bloqueio de seguranca do Google.
- Google Chrome + Playwright 1.62: monitoramento e envio pelo chat real depois da autenticacao.
- Caddy 2: HTTPS automatico.
- Docker Compose: instalacao isolada e execucao em segundo plano.

O PostgreSQL nao publica a porta 5432. Apenas as portas 80 e 443 ficam expostas pelo Caddy. Os volumes `postgres-data` e `chrome-profiles` sobrevivem a atualizacoes e reinicios.

## Como os logins ficam guardados

- senhas do Peralta Chat Server recebem hash `scrypt` com salt; o texto da senha nao fica no banco;
- tokens de sessao tambem sao gravados somente como hash e os cookies usam `HttpOnly`, `Secure` e `SameSite=Strict`;
- o exportador nao recebe a senha do Google e trabalha somente sobre uma copia temporaria do perfil ja conectado da V4.83;
- o arquivo JSON de transferencia contem cookies sensiveis, passa pelo HTTPS somente para a propria conta, nao e salvo como upload e deve ser apagado depois da importacao;
- cookies do YouTube ficam no perfil persistente de cada usuario, dentro do volume protegido `chrome-profiles`;
- o arquivo `.env` recebe permissao `600` durante a instalacao.

### Sobre copiar o `BrowserData` da V4.83

Nao copie `BrowserData\ChromeProfile` do Windows diretamente para o volume do Ubuntu. Os cookies e outros segredos do perfil sao criptografados com protecao ligada ao sistema operacional; o Chrome Linux nao consegue reutilizar de forma confiavel a sessao criada pelo Chrome Windows. A copia tambem pode levar travas e estado de uma versao diferente do navegador.

Os arquivos `Dados\configuracoes.json`, `Dados\mensagens.txt` e `Dados\mensagens_por_canal.json` da V4.83 contem configuracoes comuns que podem ser convertidas separadamente. Eles nao transferem a conta Google.

Use o **Peralta Session Exporter para Windows** disponibilizado no painel. Ele abre uma copia temporaria do perfil com o proprio Chrome instalado, exporta somente cookies dos dominios Google/YouTube e nao altera a pasta original. Depois, importe o JSON em **Importar sessao da V4.83** e apague o arquivo. Nunca envie esse JSON ao GitHub, WhatsApp, e-mail ou outra pessoa.

O Chrome manual fecha sozinho depois de 20 minutos sem interacao. Ao concluir ou cancelar, o processo automatico da conta e retomado com a configuracao que ja estava salva. O Google ainda pode solicitar confirmacao em duas etapas ou outra verificacao de seguranca da propria conta.

Na V1.0.7, a importacao valida formato, quantidade, validade e dominios antes de entregar os cookies ao Chrome individual. Valores nunca entram nos logs. O processo da conta pausa durante a troca, grava a sessao no perfil Linux e volta automaticamente. O Google ainda pode invalidar uma sessao ao detectar a mudanca do computador ou do IP; isso nao pode ser garantido por um programa sem a autorizacao oficial do Google.

O Chrome automatico conserva uma aba interna vazia para impedir a falha `Target.createTarget` ao abrir os chats. A verificacao segue a logica tolerante da V4.83: cookie valido, estado da pagina ou avatar podem confirmar a sessao separadamente.

## Recursos do usuario

- adicionar, ativar, desativar ou excluir canais;
- cinco mensagens iniciais em canais novos: `Salve!`, `Olá!`, `Tudo bem?`, `Live top!`, `Boa live!`;
- lista global ou uma lista para cada canal;
- intervalo exato de 1 ms ate 24 horas, repeticao e embaralhamento;
- iniciar, parar ou pausar somente os envios;
- acompanhar lives, contadores, falhas e registros;
- conectar o perfil proprio do YouTube;
- importar a sessao conectada da V4.83 sem modificar o programa original.

Intervalos muito curtos podem ser interpretados pelo YouTube como spam. O sistema respeita o valor configurado, mas quem administra as contas deve usar uma frequencia responsavel.

## Recursos administrativos

- criar, suspender, reativar e excluir contas;
- gerar nova senha temporaria;
- prazo de expiracao e limite de canais;
- consultar estado dos processos e reiniciar somente uma conta;
- alterar a busca global de lives para todas as contas em tempo real;
- auditoria de logins e mudancas administrativas.

## Instalacao

Leia [INSTALAR_NO_SERVIDOR.md](INSTALAR_NO_SERVIDOR.md). O caminho recomendado e Ubuntu Server 24.04 LTS amd64.

Se a V1.0.6 ja estiver instalada, use [ATUALIZAR_DA_V1.0.6.md](ATUALIZAR_DA_V1.0.6.md). Tambem existem caminhos diretos para [V1.0.5](ATUALIZAR_DA_V1.0.5.md), [V1.0.4](ATUALIZAR_DA_V1.0.4.md), [V1.0.3](ATUALIZAR_DA_V1.0.3.md), [V1.0.2](ATUALIZAR_DA_V1.0.2.md) e [V1.0.1](ATUALIZAR_DA_V1.0.1.md). Todos mantem os dados existentes.

## Aplicativo Android

O codigo do controlador esta na pasta `android`. Consulte [android/GERAR_APK.md](android/GERAR_APK.md). O endereco fica em `android/gradle.properties`, portanto pode ser trocado sem alterar o servidor.

O painel de usuario tambem e instalavel diretamente pelo Chrome do celular em **Adicionar a tela inicial**. Essa versao instalada nao mostra acesso administrativo; o servidor continua sendo executado no VPS quando o aplicativo e fechado.

## Comandos diarios

```bash
cd /opt/Peralta_Chat_Server_V1.0.7
docker compose ps
docker compose logs -f --tail=100
./scripts/status.sh
./scripts/backup.sh
```

Fechar o SSH ou o terminal nao encerra nada: o Compose inicia em modo destacado (`-d`) e os tres servicos usam `restart: unless-stopped`.
