# Atualizar da V1.0.4 para a V1.0.7 sem perder dados

Esta atualizacao mantem a correcao das abas automaticas e adiciona a importacao da sessao conectada da V4.83 quando o Google bloquear o login remoto da VPS.

Nunca execute `docker compose down -v`: a opcao `-v` apaga os volumes.

## 1. Fazer backup da V1.0.4

```bash
cd /opt/Peralta_Chat_Server_V1.0.4
./scripts/backup.sh
```

## 2. Aplicar a V1.0.7

Depois de enviar e descompactar `Peralta_Chat_Server_V1.0.7.zip` em `/opt`:

```bash
cd /opt/Peralta_Chat_Server_V1.0.7
chmod +x scripts/*.sh
./scripts/migrar-da-v1.0.4.sh
```

O script copia o `.env`, recompila o container e conecta aos mesmos volumes do PostgreSQL e dos perfis.

## 3. Conectar a conta

Entre no painel e clique primeiro em **Verificar sessao**. Se continuar desconectada, baixe o **Peralta Session Exporter**, gere o JSON usando `BrowserData\ChromeProfile` da V4.83 no Windows e use **Importar sessao da V4.83**. Apague o JSON depois.

Confira tambem:

```bash
curl -sS https://peraltaultrachat.shop/healthz
docker compose logs --since=5m --tail=100 server
```

A saude deve informar `"version":"1.0.7"`.
