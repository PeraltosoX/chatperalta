# Instalar do zero o Peralta Chat Server V1.0.7

Este pacote e uma **instalacao limpa**. Use uma pasta nova e nao copie `.env`, banco, volumes ou perfis de uma versao anterior.

Para atualizar e manter os dados, nao siga esta limpeza. Use o guia correspondente: [V1.0.6](ATUALIZAR_DA_V1.0.6.md), [V1.0.5](ATUALIZAR_DA_V1.0.5.md), [V1.0.4](ATUALIZAR_DA_V1.0.4.md), [V1.0.3](ATUALIZAR_DA_V1.0.3.md), [V1.0.2](ATUALIZAR_DA_V1.0.2.md) ou [V1.0.1](ATUALIZAR_DA_V1.0.1.md).

## 1. Servidor recomendado

- Ubuntu Server **24.04 LTS**, 64 bits `amd64`, sem interface grafica;
- minimo pratico inicial: 2 vCPU, 4 GB de RAM e 20 GB SSD;
- aumente a RAM quando houver varias contas com chats simultaneos, pois cada conta possui um Chrome separado;
- IPv4 publico fixo e acesso SSH com usuario que possa usar `sudo`.

## 2. Antes de instalar: DNS na Hostinger

Na zona DNS de `peraltaultrachat.shop`, edite o registro:

| Tipo | Nome | Conteudo |
|---|---|---|
| A | `@` | IPv4 publico do novo servidor |
| CNAME | `www` | `peraltaultrachat.shop` |

Remova outros registros A ou AAAA conflitantes. O Cloudflare nao e obrigatorio. Aguarde o dominio responder com o IP certo antes da primeira emissao do HTTPS.

Para conferir no computador:

```bash
nslookup peraltaultrachat.shop
```

## 3. Enviar o ZIP

Opcao facil no Windows: instale o WinSCP, conecte com o mesmo IP/usuario/senha do SSH e envie `Peralta_Chat_Server_V1.0.7.zip` para `/root/` ou para a pasta inicial do seu usuario.

Tambem pode enviar pelo terminal do computador:

```bash
scp Peralta_Chat_Server_V1.0.7.zip USUARIO@IP_DO_SERVIDOR:/tmp/
```

## 4. Instalar o Docker Engine no Ubuntu 24.04

Entre no servidor por SSH e execute os comandos oficiais do repositorio Docker:

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl unzip openssl
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo \"${UBUNTU_CODENAME:-$VERSION_CODENAME}\") stable" | sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo docker run --rm hello-world
```

Documentacao oficial: <https://docs.docker.com/engine/install/ubuntu/>

Se a VPS tiver menos de 2 GB de RAM e nenhuma swap, depois de descompactar o pacote execute uma vez `sudo ./scripts/preparar-vps-1gb.sh`. Isso cria 2 GB de swap para impedir que o Linux encerre o Chrome durante o login. Uma VPS de 1 GB ainda e apropriada somente para teste ou pouquissimo uso; varias contas simultaneas exigem mais RAM e CPU.

## 5. Descompactar e instalar

Se o ZIP foi enviado para `/tmp`:

```bash
cd /opt
sudo unzip /tmp/Peralta_Chat_Server_V1.0.7.zip
sudo chown -R "$USER":"$USER" /opt/Peralta_Chat_Server_V1.0.7
cd /opt/Peralta_Chat_Server_V1.0.7
chmod +x scripts/*.sh
sudo ./scripts/instalar.sh
```

Se voce ja estiver conectado como `root`, o `sudo` pode continuar nos comandos sem problema. O instalador perguntara:

1. dominio — aperte Enter para usar `peraltaultrachat.shop`;
2. usuario administrativo — aperte Enter para usar `peraltaadmin`;
3. senha administrativa — escolha pelo menos 12 caracteres usando letras, numeros ou `._@%+=:-`;
4. confirmacao — digite exatamente a mesma senha mais uma vez.

A senha nao aparece enquanto voce digita no terminal; isso e normal. O instalador avisa se as duas digitacoes forem diferentes.

Ele gera sozinho a senha interna do PostgreSQL e o segredo das sessoes. A primeira compilacao baixa o Chrome e pode demorar alguns minutos.

## 6. Liberar as portas

Se o UFW estiver ativo, preserve primeiro o SSH e libere web:

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw status
```

Nao libere a porta 5432. O PostgreSQL foi projetado para ficar somente na rede interna do Docker.

## 7. Abrir os paineis

- Usuario: <https://peraltaultrachat.shop/>
- Administrador: <https://peraltaultrachat.shop/dbmadmin>

No `/dbmadmin`, crie a conta da pessoa. Ela recebera usuario e senha temporaria e trocara a senha no primeiro acesso. Para conectar o YouTube sem depender do login bloqueado da VPS, ela baixa no proprio painel o **Peralta Session Exporter**, executa no Windows com a V4.83 fechada e importa o JSON gerado. O processo daquela conta pausa somente durante a importacao e volta sozinho.

## 8. Confirmar que continua ao fechar o terminal

O instalador executa:

```bash
docker compose up -d --build
```

O `-d` deixa tudo em segundo plano. Alem disso, `postgres`, `server` e `caddy` usam `restart: unless-stopped`, portanto voltam sozinhos depois de uma reinicializacao do Ubuntu. Pode fechar o SSH.

Confira quando quiser:

```bash
cd /opt/Peralta_Chat_Server_V1.0.7
sudo docker compose ps
sudo docker compose logs --tail=100 server caddy
```

Todos devem aparecer como `Up` ou `running`. O endereco `/healthz` deve responder com `"ok":true`.

## 9. Backup

```bash
cd /opt/Peralta_Chat_Server_V1.0.7
sudo ./scripts/backup.sh
```

O backup inclui o PostgreSQL e os perfis persistentes do Chrome. Copie a pasta `backups` para outro local seguro. Ela contem sessoes do YouTube e deve ser tratada como dado sigiloso.

## Solucao rapida de problemas

DNS ainda nao atualizado:

```bash
nslookup peraltaultrachat.shop
```

Estado dos containers:

```bash
sudo docker compose ps
sudo docker compose logs --tail=200
```

Reiniciar sem apagar dados:

```bash
sudo docker compose restart
```

Ver os registros do login manual ou do monitor:

```bash
cd /opt/Peralta_Chat_Server_V1.0.7
sudo docker compose logs --tail=200 server
```

Nesta instalacao limpa, nao execute `scripts/atualizar.sh` sobre uma pasta antiga. Nunca execute `docker compose down -v` em um servidor com dados que queira preservar: a opcao `-v` apaga os volumes do banco e dos perfis.
