# Atualizar da V1.0.5 para a V1.0.7 sem perder dados

Esta atualizacao adiciona a importacao da sessao conectada da V4.83 porque o Google bloqueou o login realizado pela tela remota da VPS. A V1.0.7 mantem as correcoes de abas e conclusao do login da V1.0.5.

Nunca execute `docker compose down -v`: a opcao `-v` apaga os volumes.

## 1. Fazer backup da V1.0.5

```bash
cd /opt/Peralta_Chat_Server_V1.0.5
./scripts/backup.sh
```

## 2. Aplicar a V1.0.7

Depois de enviar e descompactar `Peralta_Chat_Server_V1.0.7.zip` em `/opt`:

```bash
cd /opt/Peralta_Chat_Server_V1.0.7
chmod +x scripts/*.sh
./scripts/migrar-da-v1.0.5.sh
```

O script copia o `.env`, recompila o container e conecta aos mesmos volumes do PostgreSQL e dos perfis.

## 3. Exportar a sessao da V4.83 no Windows

1. Abra a V4.83 e confirme que ela reconhece a conta do YouTube.
2. Feche a V4.83 e todas as janelas do Chrome abertas por ela.
3. No painel V1.0.7, baixe o **Peralta Session Exporter para Windows**.
4. Copie os tres arquivos extraidos para a pasta do EXE da V4.83 e execute `EXPORTAR_SESSAO_V4.83.bat`; ele encontra `BrowserData\ChromeProfile` automaticamente.
5. O exportador le somente uma copia temporaria e cria um JSON na Area de Trabalho.

## 4. Importar na conta do servidor

Abra o painel pelo navegador do PC, clique em **Importar sessao da V4.83** e selecione o JSON. Quando aparecer **Conectado**, apague o JSON do computador. Nunca envie esse arquivo ao GitHub ou a outra pessoa: ele equivale a uma sessao conectada.

Confira:

```bash
curl -sS https://peraltaultrachat.shop/healthz
docker compose logs --since=5m --tail=100 server
```

A saude deve informar `"version":"1.0.7"`.
