# Historico de versoes

## Peralta Chat Server V1.0.1 — instalacao limpa

- Pacote completo para instalar do zero em um servidor novo; nao exige nem reaproveita a V1.0.0.
- Login do Google transferido para um Chrome normal em tela isolada, sem Playwright conectado durante a autenticacao.
- Automacao da conta suspensa somente enquanto a tela manual esta aberta e retomada automaticamente ao concluir, cancelar ou expirar.
- Controle remoto manual por imagem, clique, teclado e rolagem, sem expor porta VNC e sem gravar o texto digitado.
- Senha do Google impedida de entrar no gerenciador de senhas do Chrome por politica administrada.
- Correcao definitiva da tela administrativa que permanecia visivel sobre o painel depois do login.
- Arquivos web versionados e cache do aplicativo renovado para evitar interface antiga no navegador ou celular.
- Instalador valida dominio e usuario e exige a confirmacao da senha administrativa.
- Aplicativo Android atualizado para a versao 1.0.1.

## Peralta Chat Server V1.0.0 — projeto novo

- Projeto de servidor separado; nao atualiza nem modifica o Peralta Chat V4.83.
- Painel responsivo de usuario pelo navegador.
- Painel administrativo exclusivo em `/dbmadmin`.
- Aplicativo Android controlador, sem area administrativa.
- Contas criadas somente pelo administrador e troca obrigatoria da senha temporaria.
- Processo e perfil persistente do Chrome separados por usuario.
- PostgreSQL interno com separacao de dados por usuario.
- Descoberta de lives pelo HTML publico de `/streams` e da pagina de video, sem YouTube Data API.
- Busca global padrao de 180 segundos, editavel apenas pelo administrador.
- Canais, listas, intervalos, pausa, repeticao e embaralhamento atualizados em tempo real ao salvar.
- Docker Compose em segundo plano com reinicio automatico.
- HTTPS automatico para `peraltaultrachat.shop` pelo Caddy.
