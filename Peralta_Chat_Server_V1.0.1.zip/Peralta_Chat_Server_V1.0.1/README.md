# Peralta Chat Server V1.0.1

Projeto novo e independente para controlar pelo navegador ou Android um monitor que fica executando no servidor. A V4.83 foi utilizada apenas como referencia do funcionamento estavel; nenhum arquivo dela e alterado ou substituido.

## Enderecos

- Usuarios e aplicativo: `https://peraltaultrachat.shop/`
- Administrador: `https://peraltaultrachat.shop/dbmadmin`
- Saude do servidor: `https://peraltaultrachat.shop/healthz`

Nao existe rota `/admin`. O painel `/dbmadmin` nao aparece no aplicativo e todas as operacoes administrativas tambem sao bloqueadas no servidor para contas comuns.

## Funcionamento

1. O administrador cria o usuario em `/dbmadmin`.
2. A pessoa entra com a senha temporaria e cria uma senha pessoal.
3. Dentro da propria conta, abre uma tela manual isolada de um Chrome normal para entrar no Google/YouTube. Durante essa etapa o Playwright fica desconectado, o monitor e suspenso temporariamente e a senha do Google nao e salva pelo sistema.
4. O processo isolado consulta o HTML publico da pagina `/streams` de cada canal a cada 180 segundos por padrao.
5. Candidatos sao conferidos pela pagina publica `watch`, sem YouTube Data API.
6. Ao encontrar live ou programacao com chat, o Chrome daquele usuario abre o chat e envia pela caixa real.
7. Canais, mensagens e intervalos mudam assim que o usuario salva. O intervalo de busca de lives e global e somente o administrador pode altera-lo.

## Componentes

- Node.js 24: painel, autenticacao e gerenciamento dos processos.
- PostgreSQL 17: contas, configuracoes, canais, mensagens, historico e auditoria.
- Google Chrome normal em tela isolada: autenticacao manual do Google sem controle do Playwright.
- Google Chrome + Playwright 1.62: monitoramento e envio pelo chat real depois da autenticacao.
- Caddy 2: HTTPS automatico.
- Docker Compose: instalacao isolada e execucao em segundo plano.

O PostgreSQL nao publica a porta 5432. Apenas as portas 80 e 443 ficam expostas pelo Caddy. Os volumes `postgres-data` e `chrome-profiles` sobrevivem a atualizacoes e reinicios.

## Como os logins ficam guardados

- senhas do Peralta Chat Server recebem hash `scrypt` com salt; o texto da senha nao fica no banco;
- tokens de sessao tambem sao gravados somente como hash e os cookies usam `HttpOnly`, `Secure` e `SameSite=Strict`;
- a senha do Google passa temporariamente da tela HTTPS para a entrada do Chrome individual, sem arquivo intermediario, e nunca e registrada;
- cookies do YouTube ficam no perfil persistente de cada usuario, dentro do volume protegido `chrome-profiles`;
- o arquivo `.env` recebe permissao `600` durante a instalacao.

O Chrome manual fecha sozinho depois de 20 minutos sem interacao. Ao concluir ou cancelar, o processo automatico da conta e retomado com a configuracao que ja estava salva. O Google ainda pode solicitar confirmacao em duas etapas ou outra verificacao de seguranca da propria conta.

## Recursos do usuario

- adicionar, ativar, desativar ou excluir canais;
- cinco mensagens iniciais em canais novos: `Salve!`, `Olá!`, `Tudo bem?`, `Live top!`, `Boa live!`;
- lista global ou uma lista para cada canal;
- intervalo exato de 1 ms ate 24 horas, repeticao e embaralhamento;
- iniciar, parar ou pausar somente os envios;
- acompanhar lives, contadores, falhas e registros;
- conectar o perfil proprio do YouTube.

Intervalos muito curtos podem ser interpretados pelo YouTube como spam. O sistema respeita o valor configurado, mas quem administra as contas deve usar uma frequencia responsavel.

## Recursos administrativos

- criar, suspender, reativar e excluir contas;
- gerar nova senha temporaria;
- prazo de expiracao e limite de canais;
- consultar estado dos processos e reiniciar somente uma conta;
- alterar a busca global de lives para todas as contas em tempo real;
- auditoria de logins e mudancas administrativas.

## Instalacao

Leia [INSTALAR_NO_SERVIDOR.md](INSTALAR_NO_SERVIDOR.md). O caminho recomendado e Ubuntu Server 24.04 LTS amd64.

## Aplicativo Android

O codigo do controlador esta na pasta `android`. Consulte [android/GERAR_APK.md](android/GERAR_APK.md). O endereco fica em `android/gradle.properties`, portanto pode ser trocado sem alterar o servidor.

O painel de usuario tambem e instalavel diretamente pelo Chrome do celular em **Adicionar a tela inicial**. Essa versao instalada nao mostra acesso administrativo; o servidor continua sendo executado no VPS quando o aplicativo e fechado.

## Comandos diarios

```bash
cd /opt/Peralta_Chat_Server_V1.0.1
docker compose ps
docker compose logs -f --tail=100
./scripts/status.sh
./scripts/backup.sh
```

Fechar o SSH ou o terminal nao encerra nada: o Compose inicia em modo destacado (`-d`) e os tres servicos usam `restart: unless-stopped`.
