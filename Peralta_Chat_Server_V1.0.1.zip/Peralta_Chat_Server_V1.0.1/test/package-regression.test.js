import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';

const root = new URL('../', import.meta.url);
const read = (relativePath) => fs.readFile(new URL(relativePath, root), 'utf8');

test('correcao da tela administrativa e permanente no CSS', async () => {
  const [css, adminScript] = await Promise.all([
    read('public/styles.css'),
    read('public/js/admin.js'),
  ]);
  assert.match(css, /\[hidden\]\s*\{\s*display:\s*none\s*!important;/i);
  assert.match(adminScript, /loginSection\.hidden\s*=\s*true/);
  assert.match(adminScript, /dashboard\.hidden\s*=\s*false/);
});

test('pacote inclui dependencias e politica do Chrome manual', async () => {
  const [dockerfile, policy] = await Promise.all([
    read('Dockerfile'),
    read('config/chrome-policy.json'),
  ]);
  for (const dependency of ['imagemagick', 'openbox', 'xdotool', 'xvfb']) {
    assert.match(dockerfile, new RegExp(`\\b${dependency}\\b`));
  }
  assert.equal(JSON.parse(policy).PasswordManagerEnabled, false);
});

test('versao 1.0.1 e cache renovado ficam consistentes', async () => {
  const [version, packageJson, config, serviceWorker] = await Promise.all([
    read('VERSION'),
    read('package.json'),
    read('src/config.js'),
    read('public/sw.js'),
  ]);
  assert.equal(version.trim(), '1.0.1');
  assert.equal(JSON.parse(packageJson).version, '1.0.1');
  assert.match(config, /VERSION\s*=\s*'1\.0\.1'/);
  assert.match(serviceWorker, /peralta-chat-server-v1\.0\.1/);
});
