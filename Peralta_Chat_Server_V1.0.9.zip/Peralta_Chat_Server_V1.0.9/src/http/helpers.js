import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const publicRoot = fileURLToPath(new URL('../../public/', import.meta.url));

export async function readJson(request, limit = 1_000_000) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > limit) throw httpError(413, 'O envio ultrapassou o limite permitido.');
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw httpError(400, 'JSON invalido.'); }
}

export function json(response, statusCode, value, extraHeaders = {}) {
  const body = Buffer.from(JSON.stringify(value));
  response.writeHead(statusCode, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': body.length,
    'cache-control': 'no-store',
    ...extraHeaders,
  });
  response.end(body);
}

export function redirect(response, location) {
  response.writeHead(302, { location, 'cache-control': 'no-store' });
  response.end();
}

export async function staticFile(response, relativePath) {
  const clean = path.normalize(relativePath).replace(/^(\.\.(\/|\\|$))+/, '');
  const target = path.join(publicRoot, clean);
  if (!target.startsWith(publicRoot)) throw httpError(404, 'Arquivo nao encontrado.');
  let body;
  try { body = await fs.readFile(target); } catch { throw httpError(404, 'Arquivo nao encontrado.'); }
  const extension = path.extname(target).toLowerCase();
  const types = {
    '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
    '.zip': 'application/zip',
    '.webmanifest': 'application/manifest+json; charset=utf-8',
  };
  response.writeHead(200, {
    'content-type': types[extension] || 'application/octet-stream',
    'content-length': body.length,
    'cache-control': extension === '.html' ? 'no-store' : 'public, max-age=3600',
  });
  response.end(body);
}

export function httpError(statusCode, message, code = null) {
  const error = new Error(message);
  error.statusCode = statusCode;
  error.code = code;
  return error;
}

export function clientIp(request) {
  const forwarded = String(request.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return forwarded || request.socket.remoteAddress || '';
}

export function intValue(value, minimum, maximum, label) {
  const number = Number(value);
  if (!Number.isInteger(number) || number < minimum || number > maximum) {
    throw httpError(400, `${label} precisa ficar entre ${minimum} e ${maximum}.`);
  }
  return number;
}

export function textValue(value, minimum, maximum, label) {
  const text = String(value ?? '').trim();
  if (text.length < minimum || text.length > maximum) {
    throw httpError(400, `${label} precisa ter entre ${minimum} e ${maximum} caracteres.`);
  }
  return text;
}
