import http from 'node:http';
import { randomUUID } from 'node:crypto';
import {
  assertCsrf, authenticateRequest, clearSessionCookies, createSession, csrfFor,
  revokeSession, setSessionCookies,
} from '../auth/session.js';
import { generateTemporaryPassword, hashPassword, verifyPassword } from '../auth/password.js';
import { APP_NAME, VERSION, config } from '../config.js';
import { createUserWithDefaults, DEFAULT_MESSAGES } from '../db/migrate.js';
import { audit, replaceMessages } from '../db/repository.js';
import { query, transaction } from '../db/pool.js';
import { channelLabel, normalizeStreamsUrl } from '../utils/youtube-url.js';
import { normalizeImportedSession } from '../services/session-import.js';
import { clientIp, httpError, intValue, json, readJson, redirect, staticFile, textValue } from './helpers.js';

const loginAttempts = new Map();

export function createHttpServer(runtimeManager) {
  return http.createServer(async (request, response) => {
    applySecurityHeaders(response);
    try {
      await route(request, response, runtimeManager);
    } catch (error) {
      const status = Number(error.statusCode) || 500;
      if (status >= 500) console.error('[HTTP]', error);
      if (!response.headersSent) json(response, status, { ok: false, error: status >= 500 ? 'Falha interna do servidor.' : error.message, code: error.code || null });
      else response.end();
    }
  });
}

async function route(request, response, runtimes) {
  const url = new URL(request.url || '/', `http://${request.headers.host || 'localhost'}`);
  const pathname = url.pathname;

  if (request.method === 'GET' && pathname === '/healthz') {
    const db = await query('SELECT 1 AS ok');
    return json(response, 200, { ok: db.rows[0].ok === 1, name: APP_NAME, version: VERSION });
  }
  if (request.method === 'GET' && pathname === '/api/version') {
    return json(response, 200, { name: APP_NAME, version: VERSION, domain: config.domain });
  }

  if (request.method === 'GET' && pathname === '/') return staticFile(response, 'login.html');
  if (request.method === 'GET' && pathname === '/app/') return redirect(response, '/app');
  if (request.method === 'GET' && pathname === '/app') {
    const auth = await authenticateRequest(request);
    if (!auth || auth.user.role !== 'user') return redirect(response, '/');
    return staticFile(response, 'app.html');
  }
  if (request.method === 'GET' && pathname === '/dbmadmin/') return redirect(response, '/dbmadmin');
  if (request.method === 'GET' && pathname === '/dbmadmin') return staticFile(response, 'admin.html');
  if (request.method === 'GET' && pathname === '/downloads/Peralta_Session_Exporter_V1.0.1.zip') {
    return staticFile(response, 'downloads/Peralta_Session_Exporter_V1.0.1.zip');
  }
  if (request.method === 'GET' && /^\/(styles\.css|js\/[a-z-]+\.js|manifest\.webmanifest|icon\.svg|sw\.js)$/.test(pathname)) return staticFile(response, pathname.slice(1));
  if (request.method === 'GET' && pathname === '/favicon.ico') { response.writeHead(204); return response.end(); }
  if (pathname === '/admin' || pathname.startsWith('/admin/')) throw httpError(404, 'Pagina nao encontrada.');

  if (request.method === 'POST' && pathname === '/api/auth/login') return login(request, response);

  const auth = await authenticateRequest(request);
  if (!auth) throw httpError(401, 'Entre novamente para continuar.', 'AUTH_REQUIRED');

  if (request.method === 'GET' && pathname === '/api/auth/me') {
    return json(response, 200, {
      ok: true,
      csrf: csrfFor(auth),
      user: publicUser(auth.user),
      version: VERSION,
    });
  }
  if (request.method === 'POST' && pathname === '/api/auth/logout') {
    assertCsrf(request, auth);
    await revokeSession(auth.sessionId);
    clearSessionCookies(response);
    return json(response, 200, { ok: true });
  }
  if (request.method === 'POST' && pathname === '/api/auth/change-password') {
    assertCsrf(request, auth);
    const body = await readJson(request);
    const current = String(body.currentPassword || '');
    const next = String(body.newPassword || '');
    if (next.length < 10 || next.length > 256) throw httpError(400, 'A nova senha precisa ter pelo menos 10 caracteres.');
    const result = await query(`SELECT password_hash FROM users WHERE id = $1`, [auth.user.id]);
    if (!await verifyPassword(current, result.rows[0]?.password_hash)) throw httpError(400, 'A senha atual esta incorreta.');
    await query(`UPDATE users SET password_hash = $1, must_change_password = false, updated_at = now() WHERE id = $2`, [await hashPassword(next), auth.user.id]);
    await audit({ actorUserId: auth.user.id, targetUserId: auth.user.id, action: 'password.changed', ipAddress: clientIp(request) });
    return json(response, 200, { ok: true });
  }

  if (pathname.startsWith('/api/dbmadmin/')) {
    requireRole(auth, 'admin');
    if (auth.user.must_change_password) throw httpError(403, 'Troque a senha antes de continuar.');
    if (request.method !== 'GET') assertCsrf(request, auth);
    return adminRoute(request, response, pathname, auth, runtimes);
  }
  if (pathname.startsWith('/api/app/')) {
    requireRole(auth, 'user');
    if (auth.user.must_change_password) throw httpError(403, 'Troque a senha temporaria antes de abrir o painel.', 'PASSWORD_CHANGE_REQUIRED');
    if (request.method !== 'GET') assertCsrf(request, auth);
    return appRoute(request, response, pathname, auth, runtimes);
  }
  throw httpError(404, 'Rota nao encontrada.');
}

async function login(request, response) {
  const body = await readJson(request, 32_000);
  const username = String(body.username || '').trim().toLowerCase();
  const password = String(body.password || '');
  const audience = body.audience === 'admin' ? 'admin' : 'user';
  const ip = clientIp(request);
  enforceLoginLimit(`${ip}:${username}`);
  const result = await query(`SELECT * FROM users WHERE username = $1`, [username]);
  const user = result.rows[0];
  const valid = user && await verifyPassword(password, user.password_hash);
  if (!valid || user.role !== audience) {
    recordLoginFailure(`${ip}:${username}`);
    throw httpError(401, 'Usuario ou senha incorretos.');
  }
  if (user.status !== 'active') throw httpError(403, 'Esta conta esta suspensa. Fale com o administrador.');
  if (user.expires_at && new Date(user.expires_at) <= new Date()) throw httpError(403, 'Esta conta expirou. Fale com o administrador.');
  loginAttempts.delete(`${ip}:${username}`);
  const session = await createSession(user.id, { userAgent: request.headers['user-agent'] || '', ipAddress: ip });
  setSessionCookies(response, session);
  await query(`UPDATE users SET last_login_at = now() WHERE id = $1`, [user.id]);
  await audit({ actorUserId: user.id, targetUserId: user.id, action: 'auth.login', details: { audience }, ipAddress: ip });
  return json(response, 200, {
    ok: true,
    csrf: session.csrf,
    mustChangePassword: user.must_change_password,
    redirect: audience === 'admin' ? '/dbmadmin' : '/app',
  });
}

async function appRoute(request, response, pathname, auth, runtimes) {
  const userId = auth.user.id;
  if (request.method === 'GET' && pathname === '/api/app/snapshot') {
    const [settings, channels, messages, profile, lives, logs, global] = await Promise.all([
      query(`SELECT * FROM user_settings WHERE user_id = $1`, [userId]),
      query(`SELECT * FROM channels WHERE user_id = $1 ORDER BY created_at, id`, [userId]),
      query(`SELECT * FROM messages WHERE user_id = $1 ORDER BY channel_id NULLS FIRST, position`, [userId]),
      query(`SELECT * FROM youtube_profiles WHERE user_id = $1`, [userId]),
      query(`SELECT * FROM live_sessions WHERE user_id = $1 ORDER BY last_activity_at DESC LIMIT 40`, [userId]),
      query(`SELECT id, level, message, created_at FROM event_logs WHERE user_id = $1 ORDER BY created_at DESC LIMIT 120`, [userId]),
      query(`SELECT value FROM system_settings WHERE key = 'scan_interval_seconds'`),
    ]);
    return json(response, 200, {
      ok: true, user: publicUser(auth.user), settings: settings.rows[0],
      channels: channels.rows, messages: messages.rows, youtubeProfile: profile.rows[0],
      lives: lives.rows, logs: logs.rows, scanIntervalSeconds: Number(global.rows[0]?.value ?? 180),
      runtime: runtimes.status(userId), version: VERSION,
    });
  }

  if (request.method === 'PATCH' && pathname === '/api/app/settings') {
    const body = await readJson(request);
    const current = (await query(`SELECT * FROM user_settings WHERE user_id = $1`, [userId])).rows[0];
    const interval = body.messageIntervalMs === undefined
      ? current.message_interval_ms
      : intValue(body.messageIntervalMs, 1, 86_400_000, 'O intervalo de mensagens');
    const repeat = booleanOr(body.repeatMessages, current.repeat_messages);
    const shuffle = booleanOr(body.shuffleMessages, current.shuffle_messages);
    const perChannel = booleanOr(body.usePerChannelMessages, current.use_per_channel_messages);
    await query(
      `UPDATE user_settings SET message_interval_ms = $1, repeat_messages = $2,
       shuffle_messages = $3, use_per_channel_messages = $4, updated_at = now()
       WHERE user_id = $5`,
      [interval, repeat, shuffle, perChannel, userId],
    );
    runtimes.reloadUser(userId);
    return json(response, 200, { ok: true });
  }

  if (request.method === 'POST' && pathname === '/api/app/channels') {
    const body = await readJson(request);
    const normalized = normalizeStreamsUrl(body.url);
    const count = Number((await query(`SELECT count(*) FROM channels WHERE user_id = $1`, [userId])).rows[0].count);
    if (count >= auth.user.max_channels) throw httpError(400, `Limite de ${auth.user.max_channels} canais atingido.`);
    const channelId = randomUUID();
    try {
      await transaction(async (client) => {
        await client.query(
          `INSERT INTO channels (id, user_id, url, normalized_url, label) VALUES ($1, $2, $3, $4, $5)`,
          [channelId, userId, String(body.url).trim(), normalized, channelLabel(normalized)],
        );
        for (let index = 0; index < DEFAULT_MESSAGES.length; index += 1) {
          await client.query(
            `INSERT INTO messages (id, user_id, channel_id, position, content) VALUES ($1, $2, $3, $4, $5)`,
            [randomUUID(), userId, channelId, index, DEFAULT_MESSAGES[index]],
          );
        }
      });
    } catch (error) {
      if (error.code === '23505') throw httpError(409, 'Esse canal ja esta adicionado.');
      throw error;
    }
    runtimes.reloadUser(userId);
    return json(response, 201, { ok: true, id: channelId });
  }

  const channelMatch = pathname.match(/^\/api\/app\/channels\/([0-9a-f-]{36})$/i);
  if (channelMatch && request.method === 'PATCH') {
    const body = await readJson(request);
    const existing = (await query(`SELECT * FROM channels WHERE id = $1 AND user_id = $2`, [channelMatch[1], userId])).rows[0];
    if (!existing) throw httpError(404, 'Canal nao encontrado.');
    const normalized = body.url === undefined ? existing.normalized_url : normalizeStreamsUrl(body.url);
    const original = body.url === undefined ? existing.url : String(body.url).trim();
    const enabled = booleanOr(body.enabled, existing.enabled);
    await query(
      `UPDATE channels SET url = $1, normalized_url = $2, label = $3, enabled = $4, updated_at = now()
       WHERE id = $5 AND user_id = $6`,
      [original, normalized, channelLabel(normalized), enabled, channelMatch[1], userId],
    );
    runtimes.reloadUser(userId);
    return json(response, 200, { ok: true });
  }
  if (channelMatch && request.method === 'DELETE') {
    const deleted = await query(`DELETE FROM channels WHERE id = $1 AND user_id = $2 RETURNING id`, [channelMatch[1], userId]);
    if (!deleted.rowCount) throw httpError(404, 'Canal nao encontrado.');
    runtimes.reloadUser(userId);
    return json(response, 200, { ok: true });
  }

  if (request.method === 'PUT' && pathname === '/api/app/messages/global') {
    const body = await readJson(request);
    await replaceMessages(userId, null, validateMessages(body.messages));
    runtimes.reloadUser(userId);
    return json(response, 200, { ok: true });
  }
  const channelMessages = pathname.match(/^\/api\/app\/channels\/([0-9a-f-]{36})\/messages$/i);
  if (channelMessages && request.method === 'PUT') {
    const body = await readJson(request);
    await replaceMessages(userId, channelMessages[1], validateMessages(body.messages));
    runtimes.reloadUser(userId);
    return json(response, 200, { ok: true });
  }

  const runtimeAction = pathname.match(/^\/api\/app\/runtime\/(start|stop|pause|resume)$/);
  if (runtimeAction && request.method === 'POST') {
    const action = runtimeAction[1];
    // "Iniciar" tambem precisa sair do estado pausado. Antes, quem clicava em
    // "Pausar envios" ficava preso em PAUSADO mesmo apertando Iniciar depois.
    if (action === 'start') await query(`UPDATE user_settings SET monitor_enabled = true, paused = false, updated_at = now() WHERE user_id = $1`, [userId]);
    if (action === 'stop') await query(`UPDATE user_settings SET monitor_enabled = false, updated_at = now() WHERE user_id = $1`, [userId]);
    if (action === 'pause') await query(`UPDATE user_settings SET paused = true, updated_at = now() WHERE user_id = $1`, [userId]);
    if (action === 'resume') await query(`UPDATE user_settings SET paused = false, monitor_enabled = true, updated_at = now() WHERE user_id = $1`, [userId]);
    runtimes.reloadUser(userId);
    return json(response, 200, { ok: true });
  }

  const youtubeCommands = new Map([
    ['/api/app/youtube/login/start', ['youtube.start', 60_000]],
    ['/api/app/youtube/login/interact', ['youtube.interact', 30_000]],
    ['/api/app/youtube/login/finish', ['youtube.finish', 75_000]],
    ['/api/app/youtube/login/cancel', ['youtube.cancel', 20_000]],
    ['/api/app/youtube/check', ['youtube.check', 35_000]],
  ]);
  if (request.method === 'POST' && pathname === '/api/app/youtube/session/import') {
    const body = await readJson(request, 2_000_000);
    let imported;
    try {
      imported = normalizeImportedSession(body);
    } catch (error) {
      throw httpError(400, error.message, 'INVALID_SESSION_FILE');
    }
    let result;
    try {
      result = await runtimes.request(userId, 'youtube.import', { cookies: imported.cookies }, 75_000);
    } catch (error) {
      throw httpError(409, error.message, 'SESSION_IMPORT_FAILED');
    }
    await audit({
      actorUserId: userId,
      targetUserId: userId,
      action: 'youtube.session_imported',
      details: { cookieCount: result.importedCount, source: imported.source, exportedAt: imported.exportedAt },
      ipAddress: clientIp(request),
    });
    return json(response, 200, { ok: true, ...result });
  }
  if (request.method === 'POST' && youtubeCommands.has(pathname)) {
    const [command, timeout] = youtubeCommands.get(pathname);
    const body = await readJson(request, 50_000);
    const result = await runtimes.request(userId, command, body, timeout);
    return json(response, 200, { ok: true, ...result });
  }
  if (request.method === 'GET' && pathname === '/api/app/youtube/login/snapshot') {
    const result = await runtimes.request(userId, 'youtube.snapshot', {}, 20_000);
    return json(response, 200, { ok: true, ...result });
  }
  throw httpError(404, 'Rota do painel nao encontrada.');
}

async function adminRoute(request, response, pathname, auth, runtimes) {
  if (request.method === 'GET' && pathname === '/api/dbmadmin/snapshot') {
    const [users, global, auditLogs] = await Promise.all([
      query(
        `SELECT u.id, u.username, u.display_name, u.status, u.must_change_password, u.expires_at,
                u.max_channels, u.last_login_at, u.created_at,
                yp.status AS youtube_status, yp.channel_handle,
                us.monitor_enabled, us.paused,
                (SELECT count(*)::int FROM channels c WHERE c.user_id = u.id) AS channel_count
         FROM users u
         LEFT JOIN youtube_profiles yp ON yp.user_id = u.id
         LEFT JOIN user_settings us ON us.user_id = u.id
         WHERE u.role = 'user' ORDER BY u.created_at DESC`,
      ),
      query(`SELECT value, updated_at FROM system_settings WHERE key = 'scan_interval_seconds'`),
      query(
        `SELECT a.id, a.action, a.details, a.ip_address, a.created_at,
                actor.username AS actor_username, target.username AS target_username
         FROM audit_logs a
         LEFT JOIN users actor ON actor.id = a.actor_user_id
         LEFT JOIN users target ON target.id = a.target_user_id
         ORDER BY a.created_at DESC LIMIT 150`,
      ),
    ]);
    return json(response, 200, {
      ok: true, user: publicUser(auth.user), users: users.rows,
      scanIntervalSeconds: Number(global.rows[0]?.value ?? 180),
      scanUpdatedAt: global.rows[0]?.updated_at,
      runtimes: runtimes.allStatuses(), audit: auditLogs.rows, version: VERSION,
    });
  }

  if (request.method === 'POST' && pathname === '/api/dbmadmin/users') {
    const body = await readJson(request);
    const username = validateUsername(body.username);
    const displayName = textValue(body.displayName, 2, 80, 'O nome');
    const maxChannels = body.maxChannels === undefined ? 20 : intValue(body.maxChannels, 1, 200, 'O limite de canais');
    const expiresAt = optionalDate(body.expiresAt);
    const temporaryPassword = body.password ? String(body.password) : generateTemporaryPassword();
    if (temporaryPassword.length < 10 || temporaryPassword.length > 256) throw httpError(400, 'A senha temporaria precisa ter pelo menos 10 caracteres.');
    let userId;
    try {
      userId = await createUserWithDefaults({ username, displayName, passwordHash: await hashPassword(temporaryPassword), expiresAt, maxChannels });
    } catch (error) {
      if (error.code === '23505') throw httpError(409, 'Esse nome de usuario ja existe.');
      throw error;
    }
    await audit({ actorUserId: auth.user.id, targetUserId: userId, action: 'user.created', details: { username, maxChannels, expiresAt }, ipAddress: clientIp(request) });
    runtimes.ensureUser(userId);
    return json(response, 201, { ok: true, id: userId, temporaryPassword });
  }

  const userMatch = pathname.match(/^\/api\/dbmadmin\/users\/([0-9a-f-]{36})$/i);
  if (userMatch && request.method === 'PATCH') {
    const userId = userMatch[1];
    const current = (await query(`SELECT * FROM users WHERE id = $1 AND role = 'user'`, [userId])).rows[0];
    if (!current) throw httpError(404, 'Conta nao encontrada.');
    const body = await readJson(request);
    const displayName = body.displayName === undefined ? current.display_name : textValue(body.displayName, 2, 80, 'O nome');
    const status = body.status === undefined ? current.status : String(body.status);
    if (!['active', 'suspended'].includes(status)) throw httpError(400, 'Estado de conta invalido.');
    const expiresAt = body.expiresAt === undefined ? current.expires_at : optionalDate(body.expiresAt);
    const maxChannels = body.maxChannels === undefined ? current.max_channels : intValue(body.maxChannels, 1, 200, 'O limite de canais');
    await query(
      `UPDATE users SET display_name = $1, status = $2, expires_at = $3, max_channels = $4, updated_at = now() WHERE id = $5`,
      [displayName, status, expiresAt, maxChannels, userId],
    );
    if (status === 'suspended') {
      await query(`DELETE FROM sessions WHERE user_id = $1`, [userId]);
      await runtimes.stopUser(userId);
    } else {
      runtimes.ensureUser(userId);
      runtimes.reloadUser(userId);
    }
    await audit({ actorUserId: auth.user.id, targetUserId: userId, action: 'user.updated', details: { status, expiresAt, maxChannels }, ipAddress: clientIp(request) });
    return json(response, 200, { ok: true });
  }
  if (userMatch && request.method === 'DELETE') {
    const userId = userMatch[1];
    const target = (await query(`SELECT username FROM users WHERE id = $1 AND role = 'user'`, [userId])).rows[0];
    if (!target) throw httpError(404, 'Conta nao encontrada.');
    await runtimes.stopUser(userId);
    await audit({ actorUserId: auth.user.id, targetUserId: userId, action: 'user.deleted', details: { username: target.username }, ipAddress: clientIp(request) });
    await query(`DELETE FROM users WHERE id = $1 AND role = 'user'`, [userId]);
    await runtimes.deleteUserProfile(userId);
    return json(response, 200, { ok: true });
  }

  const resetMatch = pathname.match(/^\/api\/dbmadmin\/users\/([0-9a-f-]{36})\/reset-password$/i);
  if (resetMatch && request.method === 'POST') {
    const body = await readJson(request);
    const temporaryPassword = body.password ? String(body.password) : generateTemporaryPassword();
    if (temporaryPassword.length < 10 || temporaryPassword.length > 256) throw httpError(400, 'A senha temporaria precisa ter pelo menos 10 caracteres.');
    const updated = await query(
      `UPDATE users SET password_hash = $1, must_change_password = true, updated_at = now()
       WHERE id = $2 AND role = 'user' RETURNING id`,
      [await hashPassword(temporaryPassword), resetMatch[1]],
    );
    if (!updated.rowCount) throw httpError(404, 'Conta nao encontrada.');
    await query(`DELETE FROM sessions WHERE user_id = $1`, [resetMatch[1]]);
    await audit({ actorUserId: auth.user.id, targetUserId: resetMatch[1], action: 'user.password_reset', ipAddress: clientIp(request) });
    return json(response, 200, { ok: true, temporaryPassword });
  }

  const restartMatch = pathname.match(/^\/api\/dbmadmin\/users\/([0-9a-f-]{36})\/restart$/i);
  if (restartMatch && request.method === 'POST') {
    const exists = await query(`SELECT id FROM users WHERE id = $1 AND role = 'user' AND status = 'active'`, [restartMatch[1]]);
    if (!exists.rowCount) throw httpError(404, 'Conta ativa nao encontrada.');
    await runtimes.restartUser(restartMatch[1]);
    await audit({ actorUserId: auth.user.id, targetUserId: restartMatch[1], action: 'runtime.restarted', ipAddress: clientIp(request) });
    return json(response, 200, { ok: true });
  }

  if (request.method === 'PATCH' && pathname === '/api/dbmadmin/settings') {
    const body = await readJson(request);
    const seconds = intValue(body.scanIntervalSeconds, 3, 3600, 'O intervalo global');
    await query(
      `INSERT INTO system_settings (key, value, updated_by, updated_at)
       VALUES ('scan_interval_seconds', to_jsonb($1::int), $2, now())
       ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_by = EXCLUDED.updated_by, updated_at = now()`,
      [seconds, auth.user.id],
    );
    await audit({ actorUserId: auth.user.id, action: 'settings.scan_interval_changed', details: { seconds }, ipAddress: clientIp(request) });
    runtimes.reloadAll();
    return json(response, 200, { ok: true, scanIntervalSeconds: seconds });
  }
  throw httpError(404, 'Rota administrativa nao encontrada.');
}

function publicUser(user) {
  return {
    id: user.id, username: user.username, displayName: user.display_name, role: user.role,
    mustChangePassword: user.must_change_password, expiresAt: user.expires_at, maxChannels: user.max_channels,
  };
}

function requireRole(auth, role) {
  if (auth.user.role !== role) throw httpError(403, 'Voce nao tem permissao para esta area.');
}

function validateUsername(value) {
  const username = String(value ?? '').trim().toLowerCase();
  if (!/^[a-z0-9._-]{3,40}$/.test(username)) throw httpError(400, 'O usuario aceita 3 a 40 letras minusculas, numeros, ponto, traco ou sublinhado.');
  return username;
}

function optionalDate(value) {
  if (value === null || value === '') return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) throw httpError(400, 'Data de expiracao invalida.');
  if (date <= new Date()) throw httpError(400, 'A expiracao precisa ficar no futuro.');
  return date;
}

function validateMessages(value) {
  if (!Array.isArray(value)) throw httpError(400, 'Envie uma lista de mensagens.');
  if (value.length > 500) throw httpError(400, 'O limite e de 500 mensagens por lista.');
  return value.map((item) => textValue(item, 1, 200, 'Cada mensagem'));
}

function booleanOr(value, fallback) {
  return typeof value === 'boolean' ? value : Boolean(fallback);
}

function enforceLoginLimit(key) {
  const entry = loginAttempts.get(key);
  if (!entry || entry.resetAt <= Date.now()) return;
  if (entry.count >= 10) throw httpError(429, 'Muitas tentativas. Aguarde alguns minutos.');
}

function recordLoginFailure(key) {
  const current = loginAttempts.get(key);
  if (!current || current.resetAt <= Date.now()) loginAttempts.set(key, { count: 1, resetAt: Date.now() + 15 * 60_000 });
  else current.count += 1;
}

function applySecurityHeaders(response) {
  response.setHeader('x-content-type-options', 'nosniff');
  response.setHeader('x-frame-options', 'DENY');
  response.setHeader('referrer-policy', 'same-origin');
  response.setHeader('permissions-policy', 'camera=(), microphone=(), geolocation=()');
  response.setHeader('content-security-policy', "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
}
