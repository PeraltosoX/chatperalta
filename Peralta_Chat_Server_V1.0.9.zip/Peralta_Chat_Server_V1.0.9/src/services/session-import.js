const SESSION_FORMAT = 'peralta-chat-session';
const SESSION_FORMAT_VERSION = 1;
const MAX_COOKIES = 500;
const MAX_COOKIE_NAME = 256;
const MAX_COOKIE_VALUE = 8192;
const MAX_COOKIE_PATH = 1024;
const MAX_COOKIE_EXPIRY = 253_402_300_799;

const LOGIN_COOKIE_NAMES = new Set([
  'SAPISID', '__SECURE-1PAPISID', '__SECURE-3PAPISID', 'LOGIN_INFO',
]);

export function normalizeImportedSession(value, nowSeconds = Math.floor(Date.now() / 1000)) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('O arquivo de sessao e invalido.');
  }
  if (value.format !== SESSION_FORMAT || Number(value.formatVersion) !== SESSION_FORMAT_VERSION) {
    throw new Error('Use um arquivo criado pelo Peralta Session Exporter.');
  }
  if (!Array.isArray(value.cookies) || value.cookies.length === 0) {
    throw new Error('O arquivo nao contem cookies para importar.');
  }
  if (value.cookies.length > MAX_COOKIES) {
    throw new Error(`O arquivo ultrapassa o limite de ${MAX_COOKIES} cookies.`);
  }

  const unique = new Map();
  for (const source of value.cookies) {
    if (!source || typeof source !== 'object' || Array.isArray(source)) {
      throw new Error('O arquivo contem um cookie invalido.');
    }
    const name = requiredText(source.name, 1, MAX_COOKIE_NAME, 'nome do cookie');
    // Cookies auxiliares podem ter valor vazio. Somente o cookie usado para
    // provar a autenticacao precisa obrigatoriamente conter um valor.
    const cookieValue = requiredText(source.value, 0, MAX_COOKIE_VALUE, 'valor do cookie');
    const domain = requiredText(source.domain, 1, 253, 'dominio do cookie').toLowerCase();
    const cookiePath = source.path == null ? '/' : requiredText(source.path, 1, MAX_COOKIE_PATH, 'caminho do cookie');
    if (!isAllowedDomain(domain)) throw new Error('O arquivo contem cookies fora do Google ou YouTube.');
    if (!cookiePath.startsWith('/')) throw new Error('O arquivo contem um caminho de cookie invalido.');

    const expires = Number(source.expires);
    if (Number.isFinite(expires) && expires > 0 && expires <= nowSeconds) continue;
    if (Number.isFinite(expires) && expires > MAX_COOKIE_EXPIRY) {
      throw new Error('O arquivo contem uma validade de cookie invalida.');
    }

    const cookie = {
      name,
      value: cookieValue,
      domain,
      path: cookiePath,
      httpOnly: Boolean(source.httpOnly),
      secure: Boolean(source.secure),
    };
    if (Number.isFinite(expires) && expires > 0) cookie.expires = expires;
    if (['Strict', 'Lax', 'None'].includes(source.sameSite)) cookie.sameSite = source.sameSite;
    unique.set(`${domain}\u0000${cookiePath}\u0000${name}`, cookie);
  }

  const cookies = [...unique.values()];
  if (!cookies.length) throw new Error('Todos os cookies do arquivo ja expiraram.');
  if (!cookies.some((cookie) => LOGIN_COOKIE_NAMES.has(cookie.name.toUpperCase()) && cookie.value.length > 0)) {
    throw new Error('A sessao exportada nao contem uma conta conectada ao YouTube.');
  }

  return {
    cookies,
    source: typeof value.source === 'string' ? value.source.slice(0, 80) : null,
    exportedAt: validDate(value.exportedAt),
  };
}

export function isAllowedDomain(domain) {
  const clean = String(domain || '').trim().toLowerCase().replace(/^\.+/, '');
  return clean === 'youtube.com' || clean.endsWith('.youtube.com')
    || clean === 'google.com' || clean.endsWith('.google.com');
}

function requiredText(value, minimum, maximum, label) {
  if (typeof value !== 'string' || value.length < minimum || value.length > maximum
    || /[\u0000-\u001f\u007f]/.test(value)) {
    throw new Error(`O arquivo contem ${label} invalido.`);
  }
  return value;
}

function validDate(value) {
  if (typeof value !== 'string') return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
}
