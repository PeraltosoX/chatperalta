import fs from 'node:fs/promises';
import path from 'node:path';

export const CHROME_PROFILE_LOCKS = Object.freeze([
  'SingletonLock',
  'SingletonCookie',
  'SingletonSocket',
]);

export async function profileHasRunningChrome(profilePath) {
  let entries;
  try {
    entries = await fs.readdir('/proc', { withFileTypes: true });
  } catch {
    // Sem conseguir consultar os processos, a opcao segura e manter as travas.
    return true;
  }

  const profileArgument = `--user-data-dir=${path.resolve(profilePath)}`;
  for (const entry of entries) {
    if (!entry.isDirectory() || !/^\d+$/.test(entry.name)) continue;
    let commandLine;
    try {
      commandLine = (await fs.readFile(`/proc/${entry.name}/cmdline`)).toString('utf8').replaceAll('\0', ' ');
    } catch {
      continue;
    }
    if (/chrom(?:e|ium)/i.test(commandLine) && commandLine.includes(profileArgument)) return true;
  }
  return false;
}

export async function removeStaleProfileLocks(profilePath) {
  if (await profileHasRunningChrome(profilePath)) return [];

  const removed = [];
  for (const name of CHROME_PROFILE_LOCKS) {
    try {
      await fs.unlink(path.join(profilePath, name));
      removed.push(name);
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
  }
  return removed;
}
