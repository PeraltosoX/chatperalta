const INPUT_SELECTOR = [
  "yt-live-chat-text-input-field-renderer #input[contenteditable]",
  "yt-live-chat-message-input-renderer #input[contenteditable]",
  "yt-live-chat-text-input-field-renderer [contenteditable]:not([contenteditable='false'])",
  "yt-live-chat-message-input-renderer [contenteditable]:not([contenteditable='false'])",
  "div#input[contenteditable]:not([contenteditable='false'])",
  "[contenteditable='true'][role='textbox']",
  "[contenteditable='plaintext-only'][role='textbox']",
  "textarea[role='textbox']",
].join(', ');

const SIGN_IN_SELECTOR = [
  'yt-live-chat-message-input-renderer #signin-button',
  'yt-live-chat-text-input-field-renderer #signin-button',
  "a[href*='accounts.google.com/ServiceLogin']",
  "a[href*='accounts.google.com/signin']",
].join(', ');

export async function openPopout(page, videoId) {
  const target = `https://www.youtube.com/live_chat?v=${videoId}&is_popout=1`;
  let lastError;
  for (let attempt = 1; attempt <= 2; attempt += 1) {
    try {
      await page.goto(target, { waitUntil: 'commit', timeout: 10_000 });
      await page.waitForTimeout(1000);
      return;
    } catch (error) {
      lastError = error;
      if (attempt < 2) {
        await page.goto('about:blank', { waitUntil: 'commit', timeout: 4000 }).catch(() => {});
        await delay(350);
      }
    }
  }
  throw new Error(`O Chrome nao conseguiu reabrir o chat ${videoId}: ${lastError?.message || 'falha desconhecida'}`);
}

export async function findVisibleInput(page, timeoutMs = 10_000, allowWatchFallback = true) {
  let input = await waitForAnyVisible(page.locator(INPUT_SELECTOR), Math.min(timeoutMs, 5000));
  if (input) return input;

  await tryActivateComposer(page.mainFrame());
  if (await tryRestoreExistingComposer(page.mainFrame())) {
    input = await waitForAnyVisible(page.locator(INPUT_SELECTOR), 1800);
    if (input) return input;
  }

  input = await findAcrossFrames(page, Math.min(timeoutMs, 5000));
  if (input) return input;
  if (!allowWatchFallback) return null;

  const id = extractVideoId(page.url());
  if (!id) return null;
  try {
    await page.goto(`https://www.youtube.com/watch?v=${id}`, { waitUntil: 'commit', timeout: 10_000 });
    await page.waitForTimeout(1300);
    await tryExpandWatchChat(page);
  } catch {
    return null;
  }

  input = await waitForAnyVisible(page.locator(INPUT_SELECTOR), 1800);
  if (input) return input;
  input = await findAcrossFrames(page, Math.max(7000, timeoutMs));
  if (input) return input;

  try {
    await page.goto(`https://www.youtube.com/live_chat?v=${id}`, { waitUntil: 'commit', timeout: 10_000 });
    await page.waitForTimeout(1300);
  } catch {
    return null;
  }

  input = await waitForAnyVisible(page.locator(INPUT_SELECTOR), 5000);
  if (input) return input;
  return findAcrossFrames(page, 5000);
}

async function findAcrossFrames(page, timeoutMs) {
  const deadline = Date.now() + Math.max(300, timeoutMs);
  do {
    for (const frame of page.frames()) {
      try {
        let found = await waitForAnyVisible(frame.locator(INPUT_SELECTOR), 250);
        if (found) return found;

        await tryActivateComposer(frame);
        await tryRestoreExistingComposer(frame);

        found = await waitForAnyVisible(frame.locator(INPUT_SELECTOR), 250);
        if (found) return found;
      } catch {
        // O YouTube recria frames enquanto inicializa o chat.
      }
    }
    if (Date.now() >= deadline) break;
    await delay(150);
  } while (Date.now() < deadline);
  return null;
}

async function tryActivateComposer(frame) {
  try {
    const candidates = frame.locator([
      'yt-live-chat-text-input-field-renderer #placeholder',
      'yt-live-chat-message-input-renderer #placeholder',
      'yt-live-chat-text-input-field-renderer',
      'yt-live-chat-message-input-renderer',
    ].join(', '));
    const count = Math.min(await candidates.count(), 4);
    for (let index = 0; index < count; index += 1) {
      const candidate = candidates.nth(index);
      if (!await candidate.isVisible().catch(() => false)) continue;
      await candidate.click({ timeout: 700, force: true }).catch(() => {});
      await delay(100);
    }
  } catch {
    // A ativacao sera tentada novamente durante a proxima busca.
  }
}

async function tryRestoreExistingComposer(frame) {
  try {
    return await frame.evaluate((selector) => {
      const inputs = [...document.querySelectorAll(selector)];
      if (!inputs.length) return false;
      for (const input of inputs) {
        let node = input;
        let depth = 0;
        while (node && node !== document.documentElement && depth < 10) {
          const style = getComputedStyle(node);
          if (style.display === 'none') node.style.setProperty('display', 'block', 'important');
          if (style.visibility === 'hidden') node.style.setProperty('visibility', 'visible', 'important');
          if (Number(style.opacity || 1) === 0) node.style.setProperty('opacity', '1', 'important');
          node.style.setProperty('pointer-events', 'auto', 'important');
          node = node.parentElement;
          depth += 1;
        }
        try { input.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch { /* ignored */ }
      }
      return true;
    }, INPUT_SELECTOR);
  } catch {
    return false;
  }
}

async function tryExpandWatchChat(page) {
  try {
    const buttons = page.locator([
      'ytd-live-chat-frame #show-hide-button button',
      'ytd-live-chat-frame #show-hide-button',
      '#chat #show-hide-button button',
      "button[aria-label='Show chat']",
      "button[aria-label='Mostrar chat']",
    ].join(', '));
    const button = await waitForAnyVisible(buttons, 1200);
    if (!button) return;
    await button.click({ timeout: 1500, force: true }).catch(() => {});
    await page.waitForTimeout(600);
  } catch {
    // A busca nos frames ainda pode localizar o campo sem expandir manualmente.
  }
}

export async function sendMessage(page, preferredInput, message, requestedIntervalMs) {
  const fast = requestedIntervalMs < 1000;
  let input = await prepareComposer(page, preferredInput, message, fast);
  if (!input) throw new Error('O Chrome localizou o chat, mas nao conseguiu preencher a mensagem apos renovar o compositor.');

  try {
    await input.press('Enter', { timeout: 5000 });
    if (await waitComposerCleared(input, fast ? 120 : 400)) return input;
  } catch { /* usa o botao real de envio abaixo */ }

  input = await prepareComposer(page, input, message, fast);
  if (!input) throw new Error('O YouTube recriou o campo de mensagem e nao aceitou o texto.');
  const clicked = await input.evaluate((element) => {
    const scope = element.closest('yt-live-chat-message-input-renderer, yt-live-chat-text-input-field-renderer') || element.parentElement || document;
    const selectors = [
      '#send-button button:not([disabled])', '#send-button:not([disabled])',
      'button[aria-label="Send"]:not([disabled])', 'button[aria-label="Enviar"]:not([disabled])',
    ];
    for (const selector of selectors) {
      const button = scope.querySelector?.(selector) || document.querySelector(selector);
      if (!button) continue;
      const rect = button.getBoundingClientRect();
      const style = getComputedStyle(button);
      if (rect.width <= 0 || rect.height <= 0 || style.display === 'none' || style.visibility === 'hidden') continue;
      button.click();
      return true;
    }
    return false;
  }).catch(() => false);
  if (clicked && await waitComposerCleared(input, fast ? 160 : 450)) return input;
  throw new Error('O campo recebeu a mensagem, mas o YouTube nao confirmou o envio.');
}

async function prepareComposer(page, preferred, message, fast) {
  let candidate = preferred;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    if (attempt > 0) candidate = await findVisibleInput(page, attempt === 1 ? 1800 : 3000, false);
    if (!candidate) continue;
    if (await tryFillComposer(page, candidate, message, fast)) return candidate;
    await tryActivateComposer(page.mainFrame()).catch(() => {});
    await delay(fast ? 35 : 120);
  }
  return null;
}

async function tryFillComposer(page, input, message, fast) {
  try {
    await input.fill(message, { timeout: 3500 });
    if (fast || await composerHasText(input)) return true;
    await page.waitForTimeout(80);
    if (await composerHasText(input)) return true;
  } catch {
    // Tenta abaixo o mesmo preenchimento alternativo usado pela V4.83.
  }

  try {
    const injected = await input.evaluate((element, text) => {
      try {
        element.focus();
        if ('value' in element) {
          const prototype = Object.getPrototypeOf(element);
          const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
          if (descriptor?.set) descriptor.set.call(element, text);
          else element.value = text;
          element.dispatchEvent(new Event('input', { bubbles: true }));
          element.dispatchEvent(new Event('change', { bubbles: true }));
          return String(element.value || '').trim().length > 0;
        }

        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(element);
        selection?.removeAllRanges();
        selection?.addRange(range);
        const inserted = typeof document.execCommand === 'function' && document.execCommand('insertText', false, text);
        if (!inserted || !String(element.textContent || element.innerText || '').trim()) element.textContent = text;
        element.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
        return String(element.textContent || element.innerText || '').trim().length > 0;
      } catch {
        return false;
      }
    }, message);
    if (!injected) return false;
    if (!fast) await page.waitForTimeout(80);
    return composerHasText(input);
  } catch {
    return false;
  }
}

async function composerHasText(input) {
  return input.evaluate((element) => {
    const value = 'value' in element ? element.value : (element.textContent || element.innerText || '');
    return String(value).trim().length > 0;
  }).catch(() => false);
}

async function waitComposerCleared(input, timeoutMs) {
  const deadline = Date.now() + Math.max(1, timeoutMs);
  do {
    if (!await composerHasText(input)) return true;
    await delay(Math.min(15, Math.max(1, deadline - Date.now())));
  } while (Date.now() < deadline);
  return !await composerHasText(input);
}

export async function detectUnavailableReason(page) {
  for (const frame of page.frames()) {
    const signIn = await waitForAnyVisible(frame.locator(SIGN_IN_SELECTOR), 120).catch(() => null);
    if (signIn) return 'LOGIN NECESSARIO';
  }

  for (const frame of page.frames()) {
    const body = await frame.locator('body').innerText({ timeout: 1200 }).catch(() => '');
    const text = body.toLowerCase();
    if (containsAny(text,
      'sign in to chat', 'sign in to participate', 'sign in to join the chat',
      'faça login para conversar', 'faça login para participar', 'fazer login para conversar')) return 'LOGIN NECESSARIO';
    if (containsAny(text,
      'chat is disabled', 'live chat is disabled', 'chat has been disabled',
      'o chat está desativado', 'chat desativado')) return 'CHAT DESATIVADO';
    if (containsAny(text,
      'chat is unavailable', 'live chat is unavailable',
      'chat indisponível', 'chat não está disponível')) return 'CHAT INDISPONIVEL';
  }
  return null;
}

export async function detectTerminalReason(page) {
  for (const frame of page.frames()) {
    const reason = await frame.evaluate(() => {
      const renderer = document.querySelector('yt-live-chat-renderer');
      const initialReplay = Boolean(window.ytInitialData?.continuationContents?.liveChatContinuation?.isReplay);
      if (initialReplay || (renderer && (renderer.isReplay || renderer.hasAttribute('is-replay') || renderer.getAttribute('is-replay') === 'true'))) {
        return 'CHAT ENCERRADO';
      }

      const live = window.ytInitialPlayerResponse?.microformat?.playerMicroformatRenderer?.liveBroadcastDetails || {};
      if (live.endTimestamp) return 'TRANSMISSAO ENCERRADA';

      const text = (document.body?.innerText || '').toLowerCase();
      const endedTerms = [
        'this live stream has ended', 'this live event has ended', 'live stream has ended', 'live chat replay',
        'a transmissão ao vivo terminou', 'esta transmissão ao vivo terminou', 'transmissão encerrada',
        'chat ao vivo terminou', 'replay do chat ao vivo',
      ];
      if (endedTerms.some((term) => text.includes(term))) return 'CHAT ENCERRADO';
      const disabledTerms = [
        'chat is disabled for this live stream', 'live chat is disabled for this live stream',
        'o chat está desativado para esta transmissão ao vivo', 'chat desativado para esta transmissão',
      ];
      if (disabledTerms.some((term) => text.includes(term))) return 'CHAT DESATIVADO';
      return null;
    }).catch(() => null);
    if (reason) return reason;
  }
  return null;
}

export async function getComposerDiagnostics(page) {
  try {
    const directInputs = await page.locator(INPUT_SELECTOR).count().catch(() => 0);
    let frameInputs = 0;
    let liveFrames = 0;
    for (const frame of page.frames()) {
      if (String(frame.url()).toLowerCase().includes('live_chat')) liveFrames += 1;
      frameInputs += await frame.locator(INPUT_SELECTOR).count().catch(() => 0);
    }
    const loggedIn = await page.evaluate(() => Boolean(window.ytcfg?.get?.('LOGGED_IN'))).catch(() => false);
    let bodyHint = await page.locator('body').innerText({ timeout: 1200 }).catch(() => '');
    bodyHint = bodyHint.replace(/\s+/g, ' ').trim();
    if (bodyHint.length > 150) bodyHint = `${bodyHint.slice(0, 150)}...`;
    let userAgent = await page.evaluate(() => navigator.userAgent).catch(() => '');
    if (userAgent.length > 105) userAgent = `${userAgent.slice(0, 105)}...`;
    const currentUrl = page.url().length > 110 ? `${page.url().slice(0, 110)}...` : page.url();
    return `URL=${currentUrl} | LOGGED_IN=${loggedIn ? 'SIM' : 'NAO'} | inputs=${directInputs}/${frameInputs} | frames=${page.frames().length} (chat=${liveFrames}) | UA='${userAgent}' | pagina='${bodyHint}'`;
  } catch (error) {
    return `diagnostico indisponivel: ${error.message}`;
  }
}

export async function slimChatDom(page) {
  for (const frame of page.frames()) {
    await frame.evaluate((inputSelector) => {
      const isVisible = (element) => {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        return rect.width > 0 && rect.height > 0 && style.display !== 'none'
          && style.visibility !== 'hidden' && Number(style.opacity || 1) !== 0;
      };
      const composer = [...document.querySelectorAll(inputSelector)].find(isVisible);
      if (!composer) return;

      let node = composer;
      while (node && node !== document.documentElement) {
        node.setAttribute('data-peralta-composer', '1');
        node = node.parentElement;
      }
      if (!document.getElementById('peralta-ultra-low-ram')) {
        const style = document.createElement('style');
        style.id = 'peralta-ultra-low-ram';
        style.textContent = `
          yt-live-chat-item-list-renderer, yt-live-chat-ticker-renderer,
          yt-live-chat-header-renderer, yt-live-chat-viewer-engagement-message-renderer,
          #ticker, #item-list, #separator, tp-yt-paper-dialog,
          ytd-engagement-panel-section-list-renderer {
            display:none !important; visibility:hidden !important;
          }
          [data-peralta-composer='1'] {
            visibility:visible !important; opacity:1 !important; pointer-events:auto !important;
          }
          * { animation:none !important; transition:none !important; }
        `;
        document.documentElement.appendChild(style);
      }
      window.__peraltaRamPurge = () => {
        document.querySelectorAll([
          'yt-live-chat-text-message-renderer', 'yt-live-chat-paid-message-renderer',
          'yt-live-chat-membership-item-renderer', 'yt-live-chat-viewer-engagement-message-renderer',
          'yt-live-chat-banner-renderer',
        ].join(', ')).forEach((element) => element.remove());
        const items = document.querySelector('yt-live-chat-item-list-renderer #items');
        if (items?.childNodes.length) items.replaceChildren();
      };
      if (!window.__peraltaRamPurgeTimer) {
        window.__peraltaRamPurgeTimer = setInterval(() => {
          try { window.__peraltaRamPurge?.(); } catch { /* ignored */ }
        }, 3000);
      }
      window.__peraltaRamPurge();
    }, INPUT_SELECTOR).catch(() => {});
  }
}

async function waitForAnyVisible(locatorSet, timeoutMs) {
  const deadline = Date.now() + Math.max(100, timeoutMs);
  do {
    try {
      const count = await locatorSet.count();
      for (let index = 0; index < count; index += 1) {
        const candidate = locatorSet.nth(index);
        if (await candidate.isVisible()) return candidate;
      }
    } catch {
      // DOM e frames podem ser substituidos durante a inicializacao.
    }
    if (Date.now() >= deadline) break;
    await delay(Math.min(100, Math.max(1, deadline - Date.now())));
  } while (Date.now() < deadline);
  return null;
}

function extractVideoId(url) {
  try { return new URL(url).searchParams.get('v'); }
  catch { return null; }
}

function containsAny(value, ...terms) {
  return terms.some((term) => value.includes(term));
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}
