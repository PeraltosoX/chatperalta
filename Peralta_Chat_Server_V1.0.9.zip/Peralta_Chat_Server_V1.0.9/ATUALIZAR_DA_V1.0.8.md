# Atualizar da V1.0.8 para a V1.0.9 sem perder dados

A V1.0.9 conserva a correcao do campo de mensagem e corrige o arquivo de dependencias que impedia a compilacao da primeira V1.0.8 enviada.

Nunca execute `docker compose down -v`: a opcao `-v` apaga os volumes.

## 1. Fazer backup

Se a V1.0.8 chegou a iniciar:

```bash
cd /opt/Peralta_Chat_Server_V1.0.8
./scripts/backup.sh
```

Se a compilacao da V1.0.8 falhou, os containers anteriores continuam preservados e voce pode seguir diretamente.

## 2. Aplicar a V1.0.9

```bash
cd /opt/Peralta_Chat_Server_V1.0.9
chmod +x scripts/*.sh
./scripts/migrar-da-v1.0.8.sh
```

## 3. Conferir

```bash
sleep 15
curl -sS https://peraltaultrachat.shop/healthz
docker compose ps
```

A saude deve informar `"version":"1.0.9"`.
