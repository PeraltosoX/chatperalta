import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { CHROME_PROFILE_LOCKS, removeStaleProfileLocks } from '../src/services/profile-locks.js';

test('remove somente travas antigas conhecidas de um perfil sem Chrome ativo', async () => {
  const profilePath = await fs.mkdtemp(path.join(os.tmpdir(), 'peralta-profile-locks-'));
  try {
    await Promise.all(CHROME_PROFILE_LOCKS.map((name) => fs.writeFile(path.join(profilePath, name), 'antiga')));
    await fs.writeFile(path.join(profilePath, 'Cookies'), 'preservar');

    const removed = await removeStaleProfileLocks(profilePath);

    assert.deepEqual(removed.sort(), [...CHROME_PROFILE_LOCKS].sort());
    assert.equal(await fs.readFile(path.join(profilePath, 'Cookies'), 'utf8'), 'preservar');
    await Promise.all(CHROME_PROFILE_LOCKS.map(async (name) => {
      await assert.rejects(fs.stat(path.join(profilePath, name)), { code: 'ENOENT' });
    }));
  } finally {
    await fs.rm(profilePath, { recursive: true, force: true });
  }
});
