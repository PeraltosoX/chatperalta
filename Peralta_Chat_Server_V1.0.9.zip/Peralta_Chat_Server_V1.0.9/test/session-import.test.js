import test from 'node:test';
import assert from 'node:assert/strict';
import { isAllowedDomain, normalizeImportedSession } from '../src/services/session-import.js';

const future = 2_000_000_000;

function packageWith(cookies) {
  return {
    format: 'peralta-chat-session',
    formatVersion: 1,
    source: 'Peralta Chat V4.83',
    exportedAt: '2026-09-05T12:00:00.000Z',
    cookies,
  };
}

test('aceita somente dominios do Google e YouTube', () => {
  assert.equal(isAllowedDomain('.youtube.com'), true);
  assert.equal(isAllowedDomain('accounts.google.com'), true);
  assert.equal(isAllowedDomain('evilgoogle.com'), false);
  assert.equal(isAllowedDomain('youtube.com.example.org'), false);
});

test('normaliza uma sessao exportada sem expor metadados desnecessarios', () => {
  const result = normalizeImportedSession(packageWith([
    {
      name: 'SAPISID', value: 'valor-secreto', domain: '.youtube.com', path: '/',
      expires: future, httpOnly: true, secure: true, sameSite: 'None', priority: 'High',
    },
    { name: 'PREF', value: '', domain: '.youtube.com', path: '/', expires: -1 },
  ]), 1_900_000_000);
  assert.equal(result.cookies.length, 2);
  assert.deepEqual(Object.keys(result.cookies[0]), [
    'name', 'value', 'domain', 'path', 'httpOnly', 'secure', 'expires', 'sameSite',
  ]);
  assert.equal(result.cookies[0].priority, undefined);
  assert.equal(result.cookies[1].value, '');
  assert.equal(result.source, 'Peralta Chat V4.83');
});

test('rejeita arquivo sem cookie de autenticacao, expirado ou de outro dominio', () => {
  assert.throws(() => normalizeImportedSession(packageWith([
    { name: 'PREF', value: 'x', domain: '.youtube.com', path: '/' },
  ])), /conta conectada/i);
  assert.throws(() => normalizeImportedSession(packageWith([
    { name: 'SAPISID', value: 'x', domain: '.example.com', path: '/' },
  ])), /fora do Google/i);
  assert.throws(() => normalizeImportedSession(packageWith([
    { name: 'SAPISID', value: 'x', domain: '.youtube.com', path: '/', expires: 10 },
  ]), 20), /expiraram/i);
  assert.throws(() => normalizeImportedSession(packageWith([
    { name: 'SAPISID', value: '', domain: '.youtube.com', path: '/' },
  ])), /conta conectada/i);
});

test('rejeita formato desconhecido e caracteres de controle', () => {
  assert.throws(() => normalizeImportedSession({ format: 'outro', formatVersion: 1, cookies: [] }), /exporter/i);
  assert.throws(() => normalizeImportedSession(packageWith([
    { name: 'SAPISID', value: 'valor\nquebrado', domain: '.youtube.com', path: '/' },
  ])), /valor do cookie/i);
});
