import test from 'node:test';
import assert from 'node:assert/strict';
import { findVisibleInput, sendMessage } from '../src/services/youtube-chat-tools.js';

function locatorSet(items) {
  return {
    async count() { return items.length; },
    nth(index) { return items[index]; },
  };
}

test('ativa o placeholder e encontra o compositor como na V4.83', async () => {
  let active = false;
  const input = {
    async isVisible() { return active; },
  };
  const placeholder = {
    async isVisible() { return true; },
    async click() { active = true; },
  };
  const frame = {
    locator(selector) {
      return selector.includes('#placeholder') ? locatorSet([placeholder]) : locatorSet([input]);
    },
    async evaluate() { return false; },
  };
  const page = {
    locator: (selector) => frame.locator(selector),
    mainFrame: () => frame,
    frames: () => [frame],
    url: () => 'https://www.youtube.com/live_chat?v=abcdefghijk',
  };

  assert.equal(await findVisibleInput(page, 100, false), input);
  assert.equal(active, true);
});

test('usa preenchimento alternativo quando o fill normal nao reage', async () => {
  let text = '';
  const input = {
    async fill() { throw new Error('compositor recriado'); },
    async evaluate(_callback, value) {
      if (value !== undefined) {
        text = value;
        return true;
      }
      return text.trim().length > 0;
    },
    async press(key) {
      assert.equal(key, 'Enter');
      text = '';
    },
  };
  const page = {
    async waitForTimeout() {},
  };

  assert.equal(await sendMessage(page, input, 'Mensagem de teste', 30_000), input);
  assert.equal(text, '');
});
