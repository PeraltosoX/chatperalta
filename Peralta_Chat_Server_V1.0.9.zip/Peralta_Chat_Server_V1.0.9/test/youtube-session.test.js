import test from 'node:test';
import assert from 'node:assert/strict';
import { hasYouTubeLoginCookie, isYouTubeSessionConnected } from '../src/services/youtube-session.js';

test('cookies de autenticacao conhecidos confirmam a sessao sem expor valores', () => {
  assert.equal(hasYouTubeLoginCookie([{ name: 'SAPISID', value: 'segredo' }]), true);
  assert.equal(hasYouTubeLoginCookie([{ name: '__Secure-3PAPISID', value: 'segredo' }]), true);
  assert.equal(hasYouTubeLoginCookie([{ name: 'PREF', value: 'nao-e-login' }]), false);
});

test('cookie de autenticacao vazio nao confirma uma conta', () => {
  assert.equal(hasYouTubeLoginCookie([{ name: 'SAPISID', value: '' }]), false);
});

test('igual a V4.83, qualquer sinal valido confirma a conta', () => {
  assert.equal(isYouTubeSessionConnected({ loggedByCookie: true }), true);
  assert.equal(isYouTubeSessionConnected({ loggedByPage: true }), true);
  assert.equal(isYouTubeSessionConnected({ avatarVisible: true }), true);
  assert.equal(isYouTubeSessionConnected({
    loggedByCookie: false, loggedByPage: false, avatarVisible: false,
  }), false);
});
