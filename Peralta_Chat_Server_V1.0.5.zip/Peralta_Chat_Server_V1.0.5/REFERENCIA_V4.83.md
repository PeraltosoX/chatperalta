# Regra de referencia

Este e um projeto novo chamado **Peralta Chat Server**, iniciado na versao **1.0.0**.

O arquivo original **Peralta Chat V4.83 Chrome — Channel Toggles + Logs Layout** foi usado somente como referencia de comportamento. Ele nao faz parte deste pacote e nao foi alterado.

- SHA-256 conferido do ZIP de referencia: `62de93297aa185751740eece97a35b593ad3ba653fd83111010fd9c9cd8f75e3`
- Mudancas e erros das versoes 4.84 e 4.85 nao foram importados.
- Nao existe YouTube Data API, chave do Google Cloud, quota ou caminho alternativo por API.

Comportamentos preservados no novo formato de servidor:

- links diretos dos canais normalizados para `/streams`;
- descoberta por HTML publico e verificacao das paginas `watch`;
- classificacao de live, programada, encerrada, desconhecida ou conteudo comum;
- live programada com chat pode abrir o worker antes do inicio;
- Chrome reservado para login e chats reais;
- envio pelo compositor real do chat;
- multiplos canais e multiplas lives;
- cache terminal seguro, nova tentativa dos candidatos recentes e recuperacao isolada;
- mensagens globais ou por canal, ativacao sem perder dados, repeticao e embaralhamento;
- pausa afeta apenas o envio; o monitor continua verificando;
- alteracoes salvas entram em vigor sem parar o servidor inteiro.

