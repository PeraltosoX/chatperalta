import test from 'node:test';
import assert from 'node:assert/strict';
import { channelLabel, extractVideoId, normalizeStreamsUrl } from '../src/utils/youtube-url.js';
import { analyzeWatchHtml, BroadcastState, extractCandidateIds, extractTitle } from '../src/services/youtube-html.js';
import { MessageCycle } from '../src/services/message-cycle.js';

test('normaliza links de canal exatamente para /streams', () => {
  assert.equal(normalizeStreamsUrl('https://youtube.com/@peralta/videos'), 'https://www.youtube.com/@peralta/streams');
  assert.equal(normalizeStreamsUrl('@peralta'), 'https://www.youtube.com/@peralta/streams');
  assert.equal(channelLabel('@peralta'), '@peralta');
  assert.throws(() => normalizeStreamsUrl('https://www.youtube.com/watch?v=abcdefghijk'), /link do canal/i);
});

test('extrai e intercala candidatos sem duplicar no HTML', () => {
  const html = '"videoId":"abcdefghijk" watch?v=abcdefghijk /live/zyxwvutsrqp';
  assert.deepEqual(extractCandidateIds(html, 24), ['abcdefghijk', 'zyxwvutsrqp']);
  assert.equal(extractVideoId('https://youtu.be/abcdefghijk'), 'abcdefghijk');
});

test('sinais atuais vencem marcadores antigos', () => {
  const result = analyzeWatchHtml('live stream has ended {"isLiveNow":true,"liveChatRenderer":{}}');
  assert.deepEqual(result, { state: BroadcastState.LIVE, chatAvailable: true });
});

test('programacao com chat entra no caminho ativo', () => {
  assert.equal(analyzeWatchHtml('{"isUpcoming":true,"liveChatContinuation":{}}').state, BroadcastState.SCHEDULED);
  assert.equal(analyzeWatchHtml('{"isLiveContent":true,"startTimestamp":"2026-09-03"}').state, BroadcastState.SCHEDULED);
});

test('encerrado e conteudo comum sao separados', () => {
  assert.equal(analyzeWatchHtml('{"endTimestamp":"2026-09-03"}').state, BroadcastState.ENDED);
  assert.equal(analyzeWatchHtml('<html>video comum</html>').state, BroadcastState.NOT_LIVE);
});

test('extrai titulo e remove sufixo do YouTube', () => {
  assert.equal(extractTitle('<meta property="og:title" content="Minha Live &amp; Chat">'), 'Minha Live & Chat');
  assert.equal(extractTitle('<title>Teste - YouTube</title>'), 'Teste');
});

test('ciclo sem repeticao termina; ciclo embaralhado nao repete a fronteira', () => {
  const once = new MessageCycle(['a', 'b'], false, false);
  assert.equal(once.next(), 'a');
  assert.equal(once.next(), 'b');
  assert.equal(once.next(), null);

  const cycle = new MessageCycle(['a', 'b'], true, true, () => 0.99);
  const first = cycle.next();
  cycle.next();
  const third = cycle.next();
  assert.notEqual(third, 'b');
  assert.ok(['a', 'b'].includes(first));
});
