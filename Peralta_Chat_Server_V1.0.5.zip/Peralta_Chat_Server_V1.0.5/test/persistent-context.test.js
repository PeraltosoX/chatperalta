import test from 'node:test';
import assert from 'node:assert/strict';
import { preparePersistentContext } from '../src/services/persistent-context.js';

function mockPage(url = 'about:blank') {
  return {
    closed: false,
    url: () => url,
    isClosed() { return this.closed; },
    async close() { this.closed = true; },
  };
}

test('mantem uma aba viva enquanto valida a abertura da proxima', async () => {
  const anchor = mockPage();
  const created = [];
  const context = {
    pages: () => [anchor],
    async newPage() {
      assert.equal(anchor.closed, false, 'a aba de sustentacao nao pode ser fechada');
      const page = mockPage();
      created.push(page);
      return page;
    },
  };

  const result = await preparePersistentContext(context);
  assert.equal(result, anchor);
  assert.equal(anchor.closed, false);
  assert.equal(created.length, 1);
  assert.equal(created[0].closed, true);
});

test('cria uma sustentacao quando o contexto inicia sem paginas', async () => {
  const created = [];
  const context = {
    pages: () => [],
    async newPage() {
      const page = mockPage();
      created.push(page);
      return page;
    },
  };

  const result = await preparePersistentContext(context);
  assert.equal(result, created[0]);
  assert.equal(created[0].closed, false);
  assert.equal(created[1].closed, true);
});
