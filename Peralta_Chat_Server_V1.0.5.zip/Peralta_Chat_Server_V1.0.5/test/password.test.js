import test from 'node:test';
import assert from 'node:assert/strict';
import { generateTemporaryPassword, hashPassword, verifyPassword } from '../src/auth/password.js';

test('senha usa scrypt com salt e verificacao em tempo constante', async () => {
  const first = await hashPassword('SenhaDeTeste123!');
  const second = await hashPassword('SenhaDeTeste123!');
  assert.match(first, /^scrypt\$/);
  assert.notEqual(first, second);
  assert.equal(await verifyPassword('SenhaDeTeste123!', first), true);
  assert.equal(await verifyPassword('senha-errada', first), false);
});

test('senha temporaria atende ao tamanho minimo', () => {
  assert.ok(generateTemporaryPassword().length >= 10);
});
