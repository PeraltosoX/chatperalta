# Atualizar da V1.0.3 para a V1.0.5 sem perder dados

Esta atualizacao corrige a gravacao e a identificacao da sessao depois do login manual. PostgreSQL, contas, configuracoes e perfis do Chrome sao preservados.

Nunca execute `docker compose down -v`: a opcao `-v` apaga os volumes.

## 1. Fazer backup da V1.0.3

```bash
cd /opt/Peralta_Chat_Server_V1.0.3
./scripts/backup.sh
```

## 2. Aplicar a V1.0.5

Depois de enviar e descompactar `Peralta_Chat_Server_V1.0.5.zip` em `/opt`:

```bash
cd /opt/Peralta_Chat_Server_V1.0.5
chmod +x scripts/*.sh
./scripts/migrar-da-v1.0.3.sh
```

O script copia o `.env` sem mostrar senhas, recompila o container e usa os mesmos volumes da instalacao anterior.

## 3. Fazer o login novamente

Abra **Conectar ou trocar conta**, conclua todas as etapas ate aparecer o YouTube com sua conta e somente entao clique em **Concluir login**. A V1.0.5 fecha o Chrome normalmente para salvar os cookies antes de verificar o perfil.

Confira:

```bash
curl -sS https://peraltaultrachat.shop/healthz
docker compose logs --since=5m --tail=100 server
```

A saude deve informar `"version":"1.0.5"`.
