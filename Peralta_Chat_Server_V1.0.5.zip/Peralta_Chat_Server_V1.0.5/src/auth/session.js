import { createHmac, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { config } from '../config.js';
import { query } from '../db/pool.js';

const SESSION_COOKIE = 'pcs_session';
const CSRF_COOKIE = 'pcs_csrf';

function digest(value) {
  return createHmac('sha256', config.sessionSecret || 'development-only')
    .update(String(value))
    .digest('hex');
}

export async function createSession(userId, { userAgent = '', ipAddress = '' } = {}) {
  const token = randomBytes(32).toString('base64url');
  const csrf = randomBytes(24).toString('base64url');
  const expiresAt = new Date(Date.now() + config.sessionDays * 86_400_000);
  await query(
    `INSERT INTO sessions (id, user_id, token_hash, csrf_hash, user_agent, ip_address, expires_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [randomUUID(), userId, digest(token), digest(csrf), userAgent.slice(0, 500), ipAddress.slice(0, 100), expiresAt],
  );
  return { token, csrf, expiresAt };
}

export async function authenticateRequest(request) {
  const cookies = parseCookies(request.headers.cookie || '');
  const authorization = String(request.headers.authorization || '');
  const bearer = authorization.startsWith('Bearer ') ? authorization.slice(7).trim() : '';
  const token = bearer || cookies[SESSION_COOKIE];
  if (!token) return null;
  const result = await query(
    `SELECT s.id AS session_id, s.csrf_hash, s.expires_at AS session_expires_at,
            u.id, u.username, u.display_name, u.role, u.status,
            u.must_change_password, u.expires_at, u.max_channels
     FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = $1 AND s.expires_at > now()`,
    [digest(token)],
  );
  const user = result.rows[0];
  if (!user || user.status !== 'active' || (user.expires_at && new Date(user.expires_at) <= new Date())) return null;
  return { user, sessionId: user.session_id, source: bearer ? 'bearer' : 'cookie', cookies };
}

export async function revokeSession(sessionId) {
  if (sessionId) await query(`DELETE FROM sessions WHERE id = $1`, [sessionId]);
}

export function setSessionCookies(response, session) {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  const maxAge = Math.max(1, Math.floor((session.expiresAt.getTime() - Date.now()) / 1000));
  response.setHeader('Set-Cookie', [
    `${SESSION_COOKIE}=${session.token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${secure}`,
    `${CSRF_COOKIE}=${session.csrf}; Path=/; SameSite=Strict; Max-Age=${maxAge}${secure}`,
  ]);
}

export function clearSessionCookies(response) {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  response.setHeader('Set-Cookie', [
    `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secure}`,
    `${CSRF_COOKIE}=; Path=/; SameSite=Strict; Max-Age=0${secure}`,
  ]);
}

export function assertCsrf(request, auth) {
  if (auth?.source === 'bearer') return;
  const supplied = String(request.headers['x-csrf-token'] || '');
  const expectedCookie = auth?.cookies?.[CSRF_COOKIE] || '';
  if (!supplied || !expectedCookie || !safeEqual(supplied, expectedCookie) || !safeEqual(digest(supplied), auth.user.csrf_hash || '')) {
    const error = new Error('A pagina perdeu a validacao de seguranca. Atualize e tente novamente.');
    error.statusCode = 403;
    throw error;
  }
  const origin = request.headers.origin;
  if (origin) {
    let originHost = '';
    try { originHost = new URL(origin).hostname.toLowerCase(); } catch { /* invalid below */ }
    if (originHost !== config.domain && !['localhost', '127.0.0.1'].includes(originHost)) {
      const error = new Error('Origem da solicitacao nao permitida.');
      error.statusCode = 403;
      throw error;
    }
  }
}

export function csrfFor(auth) {
  return auth?.cookies?.[CSRF_COOKIE] || null;
}

export function parseCookies(header) {
  const result = {};
  for (const part of String(header).split(';')) {
    const index = part.indexOf('=');
    if (index <= 0) continue;
    const key = part.slice(0, index).trim();
    const value = part.slice(index + 1).trim();
    try { result[key] = decodeURIComponent(value); } catch { result[key] = value; }
  }
  return result;
}

function safeEqual(left, right) {
  const a = Buffer.from(String(left));
  const b = Buffer.from(String(right));
  return a.length === b.length && timingSafeEqual(a, b);
}

