import fs from 'node:fs/promises';
import { APP_NAME, VERSION, config, validateEnvironment } from './config.js';
import { ensureInitialAdmin, pruneExpiredData, runMigrations } from './db/migrate.js';
import { pool, query } from './db/pool.js';
import { createHttpServer } from './http/server.js';
import { RuntimeManager } from './services/runtime-manager.js';

validateEnvironment();
await fs.mkdir(config.profileRoot, { recursive: true, mode: 0o700 });
await waitForDatabase();
await runMigrations();
await ensureInitialAdmin();
await pruneExpiredData();

const runtimes = new RuntimeManager();
await runtimes.start();
const server = createHttpServer(runtimes);

await new Promise((resolve, reject) => {
  server.once('error', reject);
  server.listen(config.port, '0.0.0.0', resolve);
});

console.log(`${APP_NAME} V${VERSION} ativo na porta ${config.port}.`);
console.log(`Painel de usuarios: https://${config.domain}/`);
console.log(`Painel administrativo: https://${config.domain}/dbmadmin`);

const maintenance = setInterval(() => void pruneExpiredData().catch((error) => console.error('[Manutencao]', error.message)), 6 * 60 * 60_000);
maintenance.unref();

let closing = false;
async function shutdown(signal) {
  if (closing) return;
  closing = true;
  console.log(`Recebido ${signal}. Encerrando com seguranca...`);
  clearInterval(maintenance);
  await new Promise((resolve) => server.close(resolve));
  await runtimes.shutdown();
  await pool.end();
  process.exit(0);
}

process.on('SIGTERM', () => void shutdown('SIGTERM'));
process.on('SIGINT', () => void shutdown('SIGINT'));
process.on('unhandledRejection', (error) => console.error('[Promise]', error));
process.on('uncaughtException', (error) => {
  console.error('[Fatal]', error);
  void shutdown('erro fatal');
});

async function waitForDatabase() {
  let lastError;
  for (let attempt = 1; attempt <= 30; attempt += 1) {
    try {
      await query('SELECT 1');
      return;
    } catch (error) {
      lastError = error;
      if (attempt < 30) await new Promise((resolve) => setTimeout(resolve, 2000));
    }
  }
  throw new Error(`PostgreSQL indisponivel: ${lastError?.message || 'erro desconhecido'}`);
}
