import { fork } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { config } from '../config.js';
import { query } from '../db/pool.js';

const workerPath = fileURLToPath(new URL('../worker/user-process.js', import.meta.url));

export class RuntimeManager {
  constructor() {
    this.entries = new Map();
    this.pending = new Map();
    this.closing = false;
    this.reconcileTimer = null;
  }

  async start() {
    await this.reconcile();
    this.reconcileTimer = setInterval(() => void this.reconcile().catch((error) => console.error('[Runtime] Falha ao reconciliar contas:', error.message)), 30_000);
    this.reconcileTimer.unref();
  }

  async reconcile() {
    if (this.closing) return;
    const result = await query(
      `SELECT id FROM users
       WHERE role = 'user' AND status = 'active'
         AND (expires_at IS NULL OR expires_at > now())`,
    );
    const desired = new Set(result.rows.map((row) => row.id));
    for (const userId of desired) if (!this.entries.has(userId)) this.#spawn(userId);
    for (const userId of this.entries.keys()) if (!desired.has(userId)) await this.stopUser(userId);
  }

  ensureUser(userId) {
    if (!this.entries.has(userId)) this.#spawn(userId);
    return this.entries.get(userId);
  }

  reloadUser(userId) {
    const entry = this.ensureUser(userId);
    if (entry?.child.connected) entry.child.send({ type: 'reload' });
  }

  reloadAll() {
    for (const entry of this.entries.values()) if (entry.child.connected) entry.child.send({ type: 'reload' });
  }

  async restartUser(userId) {
    await this.stopUser(userId);
    this.#spawn(userId);
  }

  async stopUser(userId) {
    const entry = this.entries.get(userId);
    if (!entry) return;
    entry.desired = false;
    entry.child.kill('SIGTERM');
    await waitForExit(entry.child, 5000);
    if (entry.child.exitCode === null) {
      entry.child.kill('SIGKILL');
      await waitForExit(entry.child, 2000);
    }
    if (this.entries.get(userId) === entry) this.entries.delete(userId);
  }

  async deleteUserProfile(userId) {
    const target = path.resolve(config.profileRoot, userId);
    const expectedParent = `${path.resolve(config.profileRoot)}${path.sep}`;
    if (!target.startsWith(expectedParent) || path.basename(target) !== userId) throw new Error('Caminho de perfil invalido.');
    await fs.rm(target, { recursive: true, force: true });
  }

  request(userId, command, payload = {}, timeoutMs = 30_000) {
    const entry = this.ensureUser(userId);
    if (!entry?.child.connected) return Promise.reject(new Error('O processo desta conta ainda nao esta disponivel.'));
    const requestId = randomUUID();
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(requestId);
        reject(new Error('O processo da conta demorou demais para responder.'));
      }, timeoutMs);
      this.pending.set(requestId, { userId, resolve, reject, timer });
      entry.child.send({ type: 'request', requestId, command, payload });
    });
  }

  status(userId) {
    const entry = this.entries.get(userId);
    return entry ? { state: 'online', ...entry.status } : { state: 'offline', running: false, activeLives: 0 };
  }

  allStatuses() {
    return Object.fromEntries([...this.entries].map(([id]) => [id, this.status(id)]));
  }

  async shutdown() {
    this.closing = true;
    clearInterval(this.reconcileTimer);
    await Promise.all([...this.entries.keys()].map((userId) => this.stopUser(userId)));
    for (const request of this.pending.values()) {
      clearTimeout(request.timer);
      request.reject(new Error('Servidor sendo encerrado.'));
    }
    this.pending.clear();
  }

  #spawn(userId) {
    if (this.closing || this.entries.has(userId)) return;
    const child = fork(workerPath, [], {
      env: { ...process.env, PERALTA_WORKER: 'true', PERALTA_USER_ID: userId },
      stdio: ['ignore', 'inherit', 'inherit', 'ipc'],
    });
    const entry = { child, desired: true, status: { state: 'starting', pid: child.pid }, crashes: 0 };
    this.entries.set(userId, entry);
    child.on('error', (error) => {
      entry.status = { state: 'error', running: false, activeLives: 0, message: error.message };
      console.error(`[Runtime] Falha no processo ${userId}:`, error.message);
    });
    child.on('message', (message) => this.#handleMessage(userId, entry, message));
    child.on('exit', (code, signal) => {
      if (this.entries.get(userId) !== entry) return;
      this.entries.delete(userId);
      for (const [requestId, pending] of this.pending) {
        if (pending.userId !== userId) continue;
        clearTimeout(pending.timer);
        pending.reject(new Error('O processo isolado da conta foi reiniciado.'));
        this.pending.delete(requestId);
      }
      if (entry.desired && !this.closing) {
        const delay = Math.min(15_000, 1000 * 2 ** Math.min(entry.crashes, 4));
        console.error(`[Runtime] Processo ${userId} terminou (${code ?? signal}); reinicio em ${delay} ms.`);
        setTimeout(() => this.#spawn(userId), delay).unref();
      }
    });
  }

  #handleMessage(userId, entry, message) {
    if (message?.type === 'status') {
      entry.status = { state: 'online', ...message.status };
    } else if (message?.type === 'response') {
      const pending = this.pending.get(message.requestId);
      if (!pending) return;
      clearTimeout(pending.timer);
      this.pending.delete(message.requestId);
      if (message.ok) pending.resolve(message.result);
      else pending.reject(new Error(message.error || 'Falha no processo da conta.'));
    } else if (message?.type === 'event') {
      entry.lastEvent = { ...message, at: new Date().toISOString() };
    }
  }
}

function waitForExit(child, timeoutMs) {
  if (child.exitCode !== null) return Promise.resolve();
  return Promise.race([
    new Promise((resolve) => child.once('exit', resolve)),
    new Promise((resolve) => setTimeout(resolve, timeoutMs)),
  ]);
}
