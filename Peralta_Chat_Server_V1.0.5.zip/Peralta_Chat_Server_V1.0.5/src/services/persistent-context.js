export async function preparePersistentContext(context) {
  const pages = context.pages().filter((page) => page.isClosed?.() !== true);
  let keepAlivePage = pages.find((page) => page.url() === 'about:blank') || null;

  // O Chrome precisa conservar ao menos uma aba. Fechar a ultima aba fazia o
  // proximo context.newPage() falhar com Target.createTarget na VPS.
  if (!keepAlivePage) keepAlivePage = await context.newPage();

  for (const page of pages) {
    if (page !== keepAlivePage) await page.close().catch(() => {});
  }

  // Confirma que novas abas podem ser criadas sem remover a aba de sustentacao.
  const probePage = await context.newPage();
  await probePage.close();
  return keepAlivePage;
}
