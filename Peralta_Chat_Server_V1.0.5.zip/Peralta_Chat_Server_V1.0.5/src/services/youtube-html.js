const ENDED_SIGNALS = [
  'live stream has ended',
  'live event has ended',
  'stream has ended',
  'transmissão ao vivo terminou',
  'transmissão terminou',
  'transmissão encerrada',
];

export const BroadcastState = Object.freeze({
  NOT_LIVE: 'NotLiveContent',
  SCHEDULED: 'Scheduled',
  LIVE: 'Live',
  ENDED: 'Ended',
  UNKNOWN: 'Unknown',
});

export function decodeHtml(value) {
  return String(value ?? '')
    .replaceAll('&quot;', '"')
    .replaceAll('&#39;', "'")
    .replaceAll('&amp;', '&')
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>');
}

export function analyzeWatchHtml(html) {
  const decoded = decodeHtml(html);
  const lower = decoded.toLowerCase();
  const isLiveNow = lower.includes('"islivenow":true');
  const isLiveContent = lower.includes('"islivecontent":true');
  const isUpcoming = lower.includes('"isupcoming":true');
  const hasStart = /"starttimestamp"\s*:\s*"[^"]+"/i.test(decoded);
  const hasEnd = /"endtimestamp"\s*:\s*"[^"]+"/i.test(decoded);
  const upcoming = lower.includes('"upcomingeventdata"') || lower.includes('"scheduledstarttime"');
  const chatDisabled = lower.includes('"ischatenabled":false') || lower.includes('"isreplay":true');
  const hasChatRenderer = lower.includes('"livechatrenderer"') || lower.includes('"livechatcontinuation"');
  const chatAvailable = hasChatRenderer && !chatDisabled;

  if (isLiveNow) return { state: BroadcastState.LIVE, chatAvailable };
  if (isUpcoming || upcoming) return { state: BroadcastState.SCHEDULED, chatAvailable };
  if (chatAvailable) return { state: BroadcastState.SCHEDULED, chatAvailable: true };
  if (hasEnd || ENDED_SIGNALS.some((signal) => lower.includes(signal))) {
    return { state: BroadcastState.ENDED, chatAvailable: false };
  }
  if (isLiveContent || hasStart) return { state: BroadcastState.SCHEDULED, chatAvailable };
  return { state: BroadcastState.NOT_LIVE, chatAvailable: false };
}

export function extractTitle(html) {
  const source = String(html ?? '');
  let match = source.match(/<meta[^>]+property=["']og:title["'][^>]+content=["'](?<title>.*?)["'][^>]*>/is);
  if (!match) match = source.match(/<meta[^>]+content=["'](?<title>.*?)["'][^>]+property=["']og:title["'][^>]*>/is);
  if (!match) match = source.match(/<title>(?<title>.*?)<\/title>/is);
  const title = decodeHtml(match?.groups?.title || 'Sem titulo').trim();
  return title.replace(/\s+-\s+YouTube\s*$/i, '').trim() || 'Sem titulo';
}

export function extractCandidateIds(html, limit = 24) {
  const result = [];
  const seen = new Set();
  const patterns = [/"videoId":"(?<id>[A-Za-z0-9_-]{11})"/g, /(?:watch\?v=|\/live\/)(?<id>[A-Za-z0-9_-]{11})/g];
  for (const pattern of patterns) {
    for (const match of String(html ?? '').matchAll(pattern)) {
      const id = match.groups.id;
      if (!seen.has(id)) {
        seen.add(id);
        result.push(id);
      }
    }
  }
  return result.slice(0, Math.min(60, Math.max(6, limit)));
}

