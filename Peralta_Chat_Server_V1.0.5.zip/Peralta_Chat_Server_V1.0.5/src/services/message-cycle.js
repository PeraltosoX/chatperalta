export class MessageCycle {
  constructor(messages, repeat = true, shuffle = true, random = Math.random) {
    this.source = [...messages];
    this.repeat = repeat;
    this.shuffle = shuffle;
    this.random = random;
    this.lastMessage = null;
    this.rebuild();
  }

  next() {
    if (!this.source.length) return null;
    if (this.index >= this.cycle.length) {
      if (!this.repeat) return null;
      this.rebuild();
    }
    const message = this.cycle[this.index++];
    this.lastMessage = message;
    return message;
  }

  rebuild() {
    this.cycle = [...this.source];
    if (this.shuffle && this.cycle.length > 1) {
      for (let index = this.cycle.length - 1; index > 0; index -= 1) {
        const target = Math.floor(this.random() * (index + 1));
        [this.cycle[index], this.cycle[target]] = [this.cycle[target], this.cycle[index]];
      }
      if (this.lastMessage && this.cycle[0] === this.lastMessage) {
        const target = this.cycle.findIndex((value, index) => index > 0 && value !== this.lastMessage);
        if (target > 0) [this.cycle[0], this.cycle[target]] = [this.cycle[target], this.cycle[0]];
      }
    }
    this.index = 0;
  }
}
