import { LiveChatWorker } from './live-chat-worker.js';
import { analyzeWatchHtml, BroadcastState, extractCandidateIds, extractTitle } from './youtube-html.js';

const MAX_CHANNEL_DISCOVERIES = 3;
const MAX_CANDIDATE_PROBES = 3;
const RECENT_PER_CHANNEL = 3;
const ENDED_CACHE_MS = 24 * 60 * 60_000;
const REQUIRED_ENDED_CONFIRMATIONS = 2;
const FETCH_HEADERS = {
  'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
  'accept-language': 'pt-BR,pt;q=0.9,en;q=0.7',
};

export class YouTubeMonitor {
  constructor({ browser, logger, publish }) {
    this.browser = browser;
    this.logger = logger;
    this.publish = publish;
    this.configuration = null;
    this.workers = new Map();
    this.terminalCache = new Map();
    this.running = false;
    this.scanAbort = null;
    this.wakeResolver = null;
  }

  update(configuration) {
    const before = this.configuration;
    this.configuration = configuration;
    const enabledKeys = new Set(configuration.channels.filter((channel) => channel.enabled).map((channel) => channel.normalized_url));
    for (const [videoId, worker] of this.workers) {
      if (!enabledKeys.has(worker.candidate.channel.normalized_url)) {
        worker.stop('REMOVIDO');
        this.workers.delete(videoId);
        continue;
      }
      worker.update({ settings: configuration.settings, messages: this.#messagesFor(worker.candidate.channel.id) });
      worker.setPaused(Boolean(configuration.settings.paused));
    }
    if (configuration.settings.monitor_enabled && !this.running) this.start();
    if (!configuration.settings.monitor_enabled && this.running) this.stop('PARADO');
    if (before) this.wake('configuracao atualizada');
  }

  start() {
    if (this.running || !this.configuration) return;
    this.running = true;
    this.scanAbort = new AbortController();
    this.logger(`Monitor iniciado sem YouTube Data API. Busca global a cada ${this.configuration.scanIntervalSeconds} segundos.`);
    void this.#loop(this.scanAbort.signal);
  }

  stop(reason = 'PARADO') {
    if (!this.running && !this.workers.size) return;
    this.running = false;
    this.scanAbort?.abort();
    this.wakeResolver?.('stop');
    this.wakeResolver = null;
    for (const worker of this.workers.values()) worker.stop(reason);
    this.workers.clear();
    this.logger('Monitor parado.');
  }

  pause(paused) {
    for (const worker of this.workers.values()) worker.setPaused(paused);
  }

  wake(reason = 'alteracao') {
    if (this.wakeResolver) this.wakeResolver(reason);
  }

  snapshot() {
    return { running: this.running, activeLives: this.workers.size };
  }

  async #loop(signal) {
    while (this.running && !signal.aborted) {
      try {
        await this.#scan(signal);
      } catch (error) {
        if (!signal.aborted) this.logger(`Falha durante a verificacao dos canais: ${error.message}`, 'error');
      }
      if (!this.running || signal.aborted) break;
      const seconds = Math.max(3, Number(this.configuration.scanIntervalSeconds) || 180);
      this.logger(`Proxima verificacao de novas lives em ${formatSeconds(seconds)}.`);
      const reason = await this.#waitOrWake(seconds * 1000, signal);
      if (reason && reason !== 'timeout' && reason !== 'stop') this.logger('Alteracao em tempo real detectada. Verificando os canais agora.');
    }
  }

  async #scan(signal) {
    const channels = this.configuration.channels.filter((channel) => channel.enabled);
    if (!channels.length) {
      this.logger('Nenhum canal ativo. O monitor continua aguardando novos canais.');
      return;
    }
    const discoveries = await mapLimit(channels, MAX_CHANNEL_DISCOVERIES, async (channel, channelOrder) => {
      try {
        const html = await fetchText(channel.normalized_url, signal);
        return { channel, channelOrder, ids: extractCandidateIds(html, this.configuration.settings.candidate_limit), error: null };
      } catch (error) {
        return { channel, channelOrder, ids: [], error: error.message };
      }
    });

    const candidates = new Map();
    for (const discovery of discoveries.sort((a, b) => a.channelOrder - b.channelOrder)) {
      if (discovery.error) {
        this.logger(`[${discovery.channel.label}] Falha ao verificar canal: ${discovery.error}`);
        continue;
      }
      discovery.ids.forEach((videoId, position) => {
        if (!candidates.has(videoId)) candidates.set(videoId, {
          videoId, channel: discovery.channel, channelOrder: discovery.channelOrder, position,
        });
      });
    }
    const ordered = [...candidates.values()].sort((a, b) => a.position - b.position || a.channelOrder - b.channelOrder);
    const toProbe = ordered.filter((candidate) => !this.workers.has(candidate.videoId) && !this.#skipCached(candidate));
    this.logger(`Descoberta concluida: ${channels.length} canal(is), ${candidates.size} candidato(s).`);

    const recentRetry = [];
    const outcomes = await mapLimit(toProbe, MAX_CANDIDATE_PROBES, async (candidate) => ({
      candidate, result: await this.probe(candidate.videoId, signal),
    }));
    for (const outcome of outcomes) this.#handleProbe(outcome, recentRetry, true);
    if (recentRetry.length) {
      await abortableDelay(900, signal);
      const retries = await mapLimit(recentRetry, MAX_CANDIDATE_PROBES, async (candidate) => ({
        candidate, result: await this.probe(candidate.videoId, signal),
      }));
      for (const outcome of retries) this.#handleProbe(outcome, [], false);
    }
    for (const [videoId, worker] of this.workers) {
      if (worker.done) worker.done.finally(() => this.workers.get(videoId) === worker && this.workers.delete(videoId));
    }
    this.logger(`Verificacao concluida: ${this.workers.size} chat(s) ativo(s).`);
  }

  async probe(videoId, signal = null) {
    try {
      const html = await fetchText(`https://www.youtube.com/watch?v=${videoId}`, signal);
      const analysis = analyzeWatchHtml(html);
      return { videoId, title: extractTitle(html), ...analysis };
    } catch {
      return { videoId, title: 'Sem titulo', state: BroadcastState.UNKNOWN, chatAvailable: false };
    }
  }

  #handleProbe({ candidate, result }, retry, collectRecent) {
    if (result.state === BroadcastState.ENDED) {
      this.#markEnded(candidate.videoId);
      if (collectRecent && candidate.position < RECENT_PER_CHANNEL) retry.push(candidate);
    } else if ([BroadcastState.NOT_LIVE, BroadcastState.UNKNOWN].includes(result.state)) {
      if (collectRecent && candidate.position < RECENT_PER_CHANNEL) retry.push(candidate);
    } else if ([BroadcastState.LIVE, BroadcastState.SCHEDULED].includes(result.state)) {
      this.terminalCache.delete(candidate.videoId);
      this.#startWorker({ ...candidate, title: result.title, state: result.state, chatAvailable: result.chatAvailable });
    }
  }

  #startWorker(candidate) {
    if (this.workers.has(candidate.videoId)) return;
    if (!this.configuration.channels.some((channel) => channel.id === candidate.channel.id && channel.enabled)) return;
    const worker = new LiveChatWorker({
      candidate,
      browser: this.browser,
      settings: this.configuration.settings,
      messages: this.#messagesFor(candidate.channel.id),
      logger: this.logger,
      publish: this.publish,
      statusProbe: async (videoId) => (await this.probe(videoId)).state,
    });
    this.workers.set(candidate.videoId, worker);
    const label = candidate.state === BroadcastState.LIVE ? 'AO VIVO' : 'PROGRAMADA';
    this.logger(`[${candidate.channel.label}] ${label}: ${candidate.title} (${candidate.videoId}). Worker iniciado.`);
    worker.start().finally(() => {
      if (this.workers.get(candidate.videoId) === worker) this.workers.delete(candidate.videoId);
    });
  }

  #messagesFor(channelId) {
    const perChannel = Boolean(this.configuration.settings.use_per_channel_messages);
    return this.configuration.messages
      .filter((message) => perChannel ? message.channel_id === channelId : message.channel_id === null)
      .sort((a, b) => a.position - b.position)
      .map((message) => message.content);
  }

  #skipCached(candidate) {
    const cached = this.terminalCache.get(candidate.videoId);
    if (!cached || candidate.position < RECENT_PER_CHANNEL) return false;
    if (cached.expiresAt <= Date.now()) { this.terminalCache.delete(candidate.videoId); return false; }
    return cached.confirmations >= REQUIRED_ENDED_CONFIRMATIONS;
  }

  #markEnded(videoId) {
    const previous = this.terminalCache.get(videoId);
    this.terminalCache.set(videoId, {
      confirmations: Math.min(REQUIRED_ENDED_CONFIRMATIONS, (previous?.confirmations || 0) + 1),
      expiresAt: Date.now() + ENDED_CACHE_MS,
    });
  }

  #waitOrWake(milliseconds, signal) {
    return new Promise((resolve) => {
      const timer = setTimeout(() => finish('timeout'), milliseconds);
      const finish = (reason) => {
        clearTimeout(timer);
        signal.removeEventListener('abort', onAbort);
        if (this.wakeResolver === finish) this.wakeResolver = null;
        resolve(reason);
      };
      const onAbort = () => finish('stop');
      this.wakeResolver = finish;
      signal.addEventListener('abort', onAbort, { once: true });
    });
  }
}

async function fetchText(url, signal) {
  const timeout = AbortSignal.timeout(18_000);
  const combined = signal ? AbortSignal.any([signal, timeout]) : timeout;
  const response = await fetch(url, { headers: FETCH_HEADERS, redirect: 'follow', signal: combined });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.text();
}

async function mapLimit(values, limit, callback) {
  const result = new Array(values.length);
  let cursor = 0;
  async function runner() {
    while (cursor < values.length) {
      const index = cursor++;
      result[index] = await callback(values[index], index);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, values.length) }, runner));
  return result;
}

function abortableDelay(milliseconds, signal) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, milliseconds);
    const onAbort = () => { clearTimeout(timer); reject(new Error('cancelado')); };
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

function formatSeconds(seconds) {
  if (seconds % 60 === 0) return `${seconds / 60} minuto(s)`;
  return `${seconds} segundo(s)`;
}
