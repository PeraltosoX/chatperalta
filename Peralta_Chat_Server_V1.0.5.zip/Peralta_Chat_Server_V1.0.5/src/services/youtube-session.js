const LOGIN_COOKIE_NAMES = new Set([
  'SAPISID', '__SECURE-1PAPISID', '__SECURE-3PAPISID', 'LOGIN_INFO',
]);

export function hasYouTubeLoginCookie(cookies = []) {
  return cookies.some((cookie) => LOGIN_COOKIE_NAMES.has(String(cookie?.name || '').toUpperCase()));
}

export function isYouTubeSessionConnected({ loggedByCookie, loggedByPage, avatarVisible }) {
  return Boolean(loggedByCookie || loggedByPage || avatarVisible);
}
