const INPUT_SELECTOR = [
  "yt-live-chat-text-input-field-renderer #input[contenteditable]",
  "yt-live-chat-message-input-renderer #input[contenteditable]",
  "yt-live-chat-text-input-field-renderer [contenteditable]:not([contenteditable='false'])",
  "yt-live-chat-message-input-renderer [contenteditable]:not([contenteditable='false'])",
  "div#input[contenteditable]:not([contenteditable='false'])",
  "[contenteditable='true'][role='textbox']",
  "[contenteditable='plaintext-only'][role='textbox']",
  "textarea[role='textbox']",
].join(', ');

export async function openPopout(page, videoId) {
  const target = `https://www.youtube.com/live_chat?v=${videoId}&is_popout=1`;
  let lastError;
  for (let attempt = 1; attempt <= 2; attempt += 1) {
    try {
      await page.goto(target, { waitUntil: 'commit', timeout: 10_000 });
      await page.waitForTimeout(1000);
      return;
    } catch (error) {
      lastError = error;
      if (attempt < 2) {
        await page.goto('about:blank', { waitUntil: 'commit', timeout: 4000 }).catch(() => {});
        await delay(350);
      }
    }
  }
  throw new Error(`O Chrome nao conseguiu reabrir o chat ${videoId}: ${lastError?.message || 'falha desconhecida'}`);
}

export async function findVisibleInput(page, timeoutMs = 10_000, allowWatchFallback = true) {
  let input = await findAcrossFrames(page, Math.min(timeoutMs, 5000));
  if (input) return input;

  if (!allowWatchFallback) return null;
  const id = new URL(page.url()).searchParams.get('v');
  if (!id) return null;
  await page.goto(`https://www.youtube.com/watch?v=${id}`, { waitUntil: 'commit', timeout: 10_000 }).catch(() => {});
  await page.waitForTimeout(1300);
  await tryExpandWatchChat(page);
  input = await findAcrossFrames(page, Math.max(7000, timeoutMs));
  if (input) return input;

  await page.goto(`https://www.youtube.com/live_chat?v=${id}`, { waitUntil: 'commit', timeout: 10_000 }).catch(() => {});
  await page.waitForTimeout(1300);
  return findAcrossFrames(page, 5000);
}

async function findAcrossFrames(page, timeoutMs) {
  const deadline = Date.now() + Math.max(300, timeoutMs);
  do {
    for (const frame of page.frames()) {
      const candidates = frame.locator(INPUT_SELECTOR);
      const count = Math.min(await candidates.count().catch(() => 0), 12);
      for (let index = 0; index < count; index += 1) {
        const candidate = candidates.nth(index);
        if (await candidate.isVisible().catch(() => false)) return candidate;
      }
      await frame.evaluate(() => {
        const buttons = [...document.querySelectorAll('#input-panel button, #input-panel [role="button"]')];
        const target = buttons.find((button) => /chat|mensagem|message/i.test(button.textContent || button.getAttribute('aria-label') || ''));
        target?.click();
      }).catch(() => {});
    }
    if (Date.now() >= deadline) break;
    await delay(150);
  } while (true);
  return null;
}

async function tryExpandWatchChat(page) {
  await page.evaluate(() => {
    const selectors = ['#show-hide-button button', 'ytd-live-chat-frame #show-hide-button button', 'button[aria-label*="chat" i]'];
    for (const selector of selectors) {
      const button = document.querySelector(selector);
      if (button && button.offsetParent) { button.click(); break; }
    }
  }).catch(() => {});
}

export async function sendMessage(page, preferredInput, message, requestedIntervalMs) {
  const fast = requestedIntervalMs < 1000;
  let input = await prepareComposer(page, preferredInput, message, fast);
  if (!input) throw new Error('O Chrome localizou o chat, mas nao conseguiu preencher a mensagem.');

  try {
    await input.press('Enter', { timeout: 5000 });
    if (await waitComposerCleared(input, fast ? 120 : 400)) return input;
  } catch { /* use the real send button below */ }

  input = await prepareComposer(page, input, message, fast);
  if (!input) throw new Error('O YouTube recriou o campo de mensagem durante o envio.');
  const clicked = await input.evaluate((element) => {
    const scope = element.closest('yt-live-chat-message-input-renderer, yt-live-chat-text-input-field-renderer') || element.parentElement || document;
    const selectors = [
      '#send-button button:not([disabled])', '#send-button:not([disabled])',
      'button[aria-label="Send"]:not([disabled])', 'button[aria-label="Enviar"]:not([disabled])',
    ];
    for (const selector of selectors) {
      const button = scope.querySelector?.(selector) || document.querySelector(selector);
      if (!button) continue;
      const rect = button.getBoundingClientRect();
      const style = getComputedStyle(button);
      if (rect.width <= 0 || rect.height <= 0 || style.display === 'none' || style.visibility === 'hidden') continue;
      button.click();
      return true;
    }
    return false;
  }).catch(() => false);
  if (clicked && await waitComposerCleared(input, fast ? 160 : 450)) return input;
  throw new Error('O campo recebeu a mensagem, mas o YouTube nao confirmou o envio.');
}

async function prepareComposer(page, preferred, message, fast) {
  let candidate = preferred;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    if (attempt > 0) candidate = await findVisibleInput(page, attempt === 1 ? 1800 : 3000, false);
    if (!candidate) continue;
    try {
      await candidate.fill(message, { timeout: 3500 });
      if (fast || await composerHasText(candidate)) return candidate;
      await page.waitForTimeout(80);
      if (await composerHasText(candidate)) return candidate;
    } catch { /* reacquire */ }
    await delay(fast ? 35 : 120);
  }
  return null;
}

async function composerHasText(input) {
  return input.evaluate((element) => {
    const value = 'value' in element ? element.value : (element.innerText || element.textContent || '');
    return String(value).trim().length > 0;
  }).catch(() => false);
}

async function waitComposerCleared(input, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  do {
    if (!await composerHasText(input)) return true;
    await delay(15);
  } while (Date.now() < deadline);
  return !await composerHasText(input);
}

export async function detectTerminalReason(page) {
  const text = await collectBodyText(page);
  const patterns = [
    ['live stream has ended', 'A transmissao foi encerrada'],
    ['stream has ended', 'A transmissao foi encerrada'],
    ['transmissão encerrada', 'A transmissao foi encerrada'],
    ['transmissão terminou', 'A transmissao foi encerrada'],
    ['chat replay is on', 'O chat entrou em modo de reprise'],
    ['replay do chat', 'O chat entrou em modo de reprise'],
  ];
  return patterns.find(([needle]) => text.includes(needle))?.[1] || null;
}

export async function detectUnavailableReason(page) {
  const text = await collectBodyText(page);
  if (/sign in|fazer login|iniciar sessao/.test(text)) return 'Conta do YouTube desconectada';
  if (/chat is disabled|chat desativado/.test(text)) return 'Chat desativado nesta live';
  if (/subscribers-only|somente inscritos|apenas inscritos/.test(text)) return 'Chat restrito a inscritos';
  if (/members-only|somente membros|apenas membros/.test(text)) return 'Chat restrito a membros';
  return null;
}

async function collectBodyText(page) {
  const values = [];
  for (const frame of page.frames()) {
    const value = await frame.locator('body').innerText({ timeout: 500 }).catch(() => '');
    values.push(value);
  }
  return values.join('\n').toLowerCase();
}

export async function slimChatDom(page) {
  for (const frame of page.frames()) {
    await frame.evaluate(() => {
      const selectors = [
        'yt-live-chat-text-message-renderer', 'yt-live-chat-paid-message-renderer',
        'yt-live-chat-membership-item-renderer', 'yt-live-chat-viewer-engagement-message-renderer',
      ];
      for (const selector of selectors) {
        const nodes = [...document.querySelectorAll(selector)];
        for (const node of nodes.slice(0, Math.max(0, nodes.length - 8))) node.remove();
      }
      document.querySelectorAll('img, video, audio, #ticker, #reaction-control-panel').forEach((node) => node.remove());
    }).catch(() => {});
  }
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}
