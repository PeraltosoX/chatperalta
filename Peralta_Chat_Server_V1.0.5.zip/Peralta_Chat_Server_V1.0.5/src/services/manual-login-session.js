import { spawn } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';

export const MANUAL_LOGIN_WIDTH = 1100;
export const MANUAL_LOGIN_HEIGHT = 760;

const DISPLAY_FIRST = 100;
const DISPLAY_COUNT = 400;
const DISPLAY_LOCK_ROOT = '/tmp/peralta-chat-manual-displays';
const DEFAULT_TIMEOUT_MS = 20 * 60_000;
const MAX_SCREENSHOT_BYTES = 6 * 1024 * 1024;
const CHROME_WINDOW_TIMEOUT_MS = 30_000;
const GRACEFUL_CLOSE_TIMEOUT_MS = 8_000;
const CHROME_LOG_LIMIT = 8 * 1024;
const GOOGLE_LOGIN_URL = 'https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fwww.youtube.com%2F';
const KEY_NAMES = new Map([
  ['Enter', 'Return'], ['Tab', 'Tab'], ['Escape', 'Escape'], ['Backspace', 'BackSpace'],
  ['ArrowUp', 'Up'], ['ArrowDown', 'Down'], ['ArrowLeft', 'Left'], ['ArrowRight', 'Right'],
]);

export function buildManualChromeArguments(profilePath) {
  return [
    `--user-data-dir=${profilePath}`,
    '--window-position=0,0',
    `--window-size=${MANUAL_LOGIN_WIDTH},${MANUAL_LOGIN_HEIGHT}`,
    '--kiosk',
    // O Chrome normal recebe SIGTRAP no sandbox em alguns hosts Docker/VPS.
    // O processo continua sem root e isolado dentro do container do servidor.
    '--no-sandbox',
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-dev-shm-usage',
    '--disable-extensions',
    '--disable-background-mode',
    '--disable-background-networking',
    '--disable-breakpad',
    '--disable-component-update',
    '--disable-crash-reporter',
    '--disable-default-apps',
    '--disable-gpu',
    '--disable-notifications',
    '--disable-translate',
    '--disk-cache-size=1048576',
    '--media-cache-size=1',
    '--process-per-site',
    '--renderer-process-limit=2',
    '--mute-audio',
    '--disable-session-crashed-bubble',
    '--password-store=basic',
    '--lang=pt-BR',
    GOOGLE_LOGIN_URL,
  ];
}

export function buildManualDisplayEnvironment(baseEnvironment = {}, display) {
  const environment = {
    ...baseEnvironment,
    DISPLAY: display,
    LANG: baseEnvironment.LANG || 'C.UTF-8',
    LC_ALL: baseEnvironment.LC_ALL || 'C.UTF-8',
    NO_AT_BRIDGE: '1',
  };
  delete environment.XAUTHORITY;
  return environment;
}

export function parseWindowIds(output) {
  return String(output || '').trim().split(/\s+/)
    .filter((value) => /^\d+$/.test(value) && value !== '0');
}

export function normalizeManualAction(payload) {
  const action = String(payload?.action || '');
  if (action === 'click') {
    const x = Math.round(clamp(Number(payload.x), 0, MANUAL_LOGIN_WIDTH - 1));
    const y = Math.round(clamp(Number(payload.y), 0, MANUAL_LOGIN_HEIGHT - 1));
    return { action, args: ['mousemove', '--sync', String(x), String(y), 'click', '1'] };
  }
  if (action === 'type') {
    const input = String(payload.text ?? '');
    if (!input || input.length > 500) throw new Error('Texto de login invalido.');
    return { action, args: ['type', '--clearmodifiers', '--delay', '20', '--file', '-'], input };
  }
  if (action === 'key') {
    const key = KEY_NAMES.get(String(payload.key || ''));
    if (!key) throw new Error('Tecla nao permitida.');
    return { action, args: ['key', '--clearmodifiers', key] };
  }
  if (action === 'wheel') {
    const delta = clamp(Number(payload.deltaY), -900, 900);
    if (delta === 0) throw new Error('Movimento de rolagem invalido.');
    const button = delta < 0 ? '4' : '5';
    const repetitions = String(Math.max(1, Math.min(8, Math.ceil(Math.abs(delta) / 120))));
    return { action, args: ['click', '--repeat', repetitions, '--delay', '35', button] };
  }
  throw new Error('Acao de login invalida.');
}

export class ManualLoginSession {
  constructor({ profilePath, executablePath, logger, timeoutMs = DEFAULT_TIMEOUT_MS }) {
    this.profilePath = profilePath;
    this.executablePath = executablePath;
    this.logger = logger;
    this.timeoutMs = timeoutMs;
    this.displayNumber = null;
    this.displayLock = null;
    this.display = null;
    this.xvfb = null;
    this.windowManager = null;
    this.chrome = null;
    this.chromeError = null;
    this.chromeStderr = '';
    this.windowId = null;
    this.expiresAt = 0;
    this.expiryTimer = null;
    this.startPromise = null;
    this.stopPromise = null;
  }

  get active() {
    return Boolean(this.display && childRunning(this.xvfb) && childRunning(this.chrome)
      && !this.chromeError && !this.stopPromise);
  }

  async start() {
    if (this.active) return this.snapshot();
    if (this.startPromise) return this.startPromise;
    this.startPromise = this.#start();
    try {
      return await this.startPromise;
    } finally {
      this.startPromise = null;
    }
  }

  async #start() {
    await this.stop('reinicio');
    await fs.mkdir(this.profilePath, { recursive: true, mode: 0o700 });
    try {
      const allocation = await allocateDisplay();
      this.displayNumber = allocation.number;
      this.displayLock = allocation.lockPath;
      this.display = `:${allocation.number}`;
      const environment = this.#environment();

      this.xvfb = spawn('Xvfb', [
        this.display, '-screen', '0', `${MANUAL_LOGIN_WIDTH}x${MANUAL_LOGIN_HEIGHT}x24`,
        '-nolisten', 'tcp', '-ac', '-noreset', '+extension', 'RANDR',
      ], { env: environment, stdio: 'ignore' });
      this.xvfb.on('error', () => {});
      await waitForDisplay(this.displayNumber, this.xvfb, environment, 10_000);

      this.windowManager = spawn('openbox', ['--sm-disable'], { env: environment, stdio: 'ignore' });
      this.windowManager.on('error', (error) => {
        this.logger(`Gerenciador da janela manual nao iniciou: ${safeMessage(error)}.`);
      });
      await delay(250);

      this.chrome = spawn(this.executablePath, buildManualChromeArguments(this.profilePath), {
        env: environment, detached: true, stdio: ['ignore', 'ignore', 'pipe'],
      });
      this.chrome.once('error', (error) => { this.chromeError = error; });
      this.chrome.stderr.on('data', (chunk) => {
        this.chromeStderr = `${this.chromeStderr}${chunk.toString('utf8')}`.slice(-CHROME_LOG_LIMIT);
      });

      this.windowId = await waitForChromeWindow(
        environment,
        this.chrome,
        CHROME_WINDOW_TIMEOUT_MS,
        () => this.#chromeFailureDetail(),
      );
      if (this.windowId) {
        await runCommand('xdotool', ['windowmove', this.windowId, '0', '0'], { env: environment, allowFailure: true });
        await runCommand('xdotool', ['windowsize', this.windowId, String(MANUAL_LOGIN_WIDTH), String(MANUAL_LOGIN_HEIGHT)], { env: environment, allowFailure: true });
        await runCommand('xdotool', ['windowactivate', this.windowId], { env: environment, allowFailure: true });
      } else {
        this.logger('Chrome manual iniciou, mas a janela nao informou um identificador. O controle continuara pela tela isolada.');
      }
      await delay(1200);
      this.#touch();
      this.logger('Chrome manual aberto em uma tela isolada. O Playwright esta desconectado durante a autenticacao.');
      return this.snapshot();
    } catch (error) {
      await this.stop('falha');
      throw new Error(`Nao foi possivel abrir o Chrome manual: ${safeMessage(error)}`);
    }
  }

  async snapshot() {
    this.#assertActive();
    this.#assertFresh();
    const environment = this.#environment();
    const capture = await runCommand('import', [
      '-silent', '-display', this.display, '-window', 'root', '-quality', '72', 'jpeg:-',
    ], { env: environment, timeoutMs: 10_000, maxBytes: MAX_SCREENSHOT_BYTES });
    if (!capture.stdout.length) throw new Error('A tela manual nao produziu imagem.');
    const titleResult = this.windowId
      ? await runCommand('xdotool', ['getwindowname', this.windowId], {
        env: environment, timeoutMs: 2_000, allowFailure: true,
      })
      : { stdout: Buffer.alloc(0) };
    const title = titleResult.stdout.toString('utf8').trim().replace(/[\r\n]+/g, ' ').slice(0, 160);
    return {
      image: `data:image/jpeg;base64,${capture.stdout.toString('base64')}`,
      width: MANUAL_LOGIN_WIDTH,
      height: MANUAL_LOGIN_HEIGHT,
      title: title || 'Login manual do Google/YouTube',
      urlHost: 'accounts.google.com / youtube.com',
      manual: true,
      expiresInSeconds: Math.max(0, Math.ceil((this.expiresAt - Date.now()) / 1000)),
    };
  }

  async interact(payload) {
    this.#assertActive();
    this.#assertFresh();
    const normalized = normalizeManualAction(payload);
    const environment = this.#environment();
    if (this.windowId) {
      await runCommand('xdotool', ['windowactivate', this.windowId], { env: environment, allowFailure: true });
    }
    await runCommand('xdotool', normalized.args, {
      env: environment,
      input: normalized.input ?? null,
      timeoutMs: normalized.action === 'type' ? 15_000 : 8_000,
    });

    this.#touch();
    await delay(normalized.action === 'type' ? 180 : 320);
    return this.snapshot();
  }

  async stop(reason = 'cancelado') {
    if (this.stopPromise) return this.stopPromise;
    this.stopPromise = this.#stop(reason);
    try {
      await this.stopPromise;
    } finally {
      this.stopPromise = null;
    }
  }

  async #stop(reason) {
    clearTimeout(this.expiryTimer);
    this.expiryTimer = null;
    const wasActive = Boolean(this.display || this.chrome || this.xvfb);

    // Solicita ao gerenciador de janelas o fechamento normal antes dos sinais.
    // Assim o Chrome tem tempo para gravar os cookies e o estado do perfil.
    if (childRunning(this.chrome) && this.windowId && this.display) {
      const closeResult = await runCommand('xdotool', ['windowclose', this.windowId], {
        env: this.#environment(), timeoutMs: 2_000, allowFailure: true,
      }).catch(() => ({ code: 1 }));
      if (closeResult.code === 0) await waitForExit(this.chrome, GRACEFUL_CLOSE_TIMEOUT_MS);
    }

    await terminateProcessGroup(this.chrome, 8_000);
    await terminateProcess(this.windowManager, 2_000);
    await terminateProcess(this.xvfb, 2_000);
    if (this.displayLock) await fs.rm(this.displayLock, { recursive: true, force: true }).catch(() => {});
    this.displayNumber = null;
    this.displayLock = null;
    this.display = null;
    this.xvfb = null;
    this.windowManager = null;
    this.chrome = null;
    this.chromeError = null;
    this.chromeStderr = '';
    this.windowId = null;
    this.expiresAt = 0;
    if (wasActive && reason === 'tempo esgotado') this.logger('Login manual encerrado automaticamente por inatividade.');
  }

  #environment() {
    return buildManualDisplayEnvironment(process.env, this.display);
  }

  #chromeFailureDetail() {
    if (this.chromeError) return safeMessage(this.chromeError);
    const lines = sanitizeDiagnostic(this.chromeStderr).split(/\r?\n/)
      .map((line) => line.trim()).filter(Boolean);
    const fatal = [...lines].reverse().find((line) => /FATAL|Check failed|No usable sandbox|zygote/i.test(line));
    const useful = [...lines].reverse().find((line) => !/dbus|scaling_(?:cur|max)_freq/i.test(line));
    return (fatal || useful || lines.at(-1) || '').slice(0, 420) || null;
  }

  #touch() {
    this.expiresAt = Date.now() + this.timeoutMs;
    clearTimeout(this.expiryTimer);
    this.expiryTimer = setTimeout(() => void this.stop('tempo esgotado'), this.timeoutMs);
    this.expiryTimer.unref();
  }

  #assertActive() {
    if (!this.active) {
      const chromeDetail = this.#chromeFailureDetail();
      const chromeStatus = this.chrome?.signalCode
        ? ` O Chrome recebeu ${this.chrome.signalCode}; em VPS com 1 GB isso normalmente indica falta de memoria.`
        : '';
      void this.stop('processo encerrado');
      throw new Error(`A tela de login manual nao esta aberta.${chromeStatus}${chromeDetail ? ` Detalhe: ${chromeDetail}` : ''} Abra novamente.`);
    }
  }

  #assertFresh() {
    if (Date.now() <= this.expiresAt) return;
    void this.stop('tempo esgotado');
    throw new Error('A tela de login expirou depois de 20 minutos sem interacao. Abra novamente.');
  }
}

async function allocateDisplay() {
  await fs.mkdir(DISPLAY_LOCK_ROOT, { recursive: true, mode: 0o700 });
  const offset = process.pid % DISPLAY_COUNT;
  for (let index = 0; index < DISPLAY_COUNT; index += 1) {
    const number = DISPLAY_FIRST + ((offset + index) % DISPLAY_COUNT);
    const lockPath = path.join(DISPLAY_LOCK_ROOT, `display-${number}`);
    try {
      await fs.mkdir(lockPath, { mode: 0o700 });
      const [hasSocket, hasXLock] = await Promise.all([
        pathExists(`/tmp/.X11-unix/X${number}`),
        pathExists(`/tmp/.X${number}-lock`),
      ]);
      if (hasSocket || hasXLock) {
        await fs.rm(lockPath, { recursive: true, force: true });
        continue;
      }
      return { number, lockPath };
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
    }
  }
  throw new Error('Nao ha uma tela isolada disponivel para o login.');
}

async function waitForDisplay(number, processHandle, environment, timeoutMs) {
  const socket = `/tmp/.X11-unix/X${number}`;
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (!childRunning(processHandle)) {
      const reason = processHandle.signalCode ? `sinal ${processHandle.signalCode}` : `codigo ${processHandle.exitCode}`;
      throw new Error(`O servidor de tela encerrou antes de iniciar (${reason}).`);
    }
    try {
      await fs.access(socket);
      const ready = await runCommand('xdotool', ['getmouselocation', '--shell'], {
        env: environment, timeoutMs: 1_000, allowFailure: true,
      });
      if (ready.code === 0) return;
    } catch { /* ainda iniciando */ }
    await delay(100);
  }
  throw new Error('O servidor de tela demorou demais para iniciar.');
}

async function waitForChromeWindow(environment, chrome, timeoutMs, getFailureDetail) {
  const deadline = Date.now() + timeoutMs;
  const searches = [
    ['search', '--onlyvisible', '--pid', String(chrome.pid)],
    ['search', '--onlyvisible', '--class', 'Google-chrome'],
    ['search', '--onlyvisible', '--classname', 'google-chrome'],
    ['search', '--onlyvisible', '--name', '.+'],
  ];
  while (Date.now() < deadline) {
    if (!childRunning(chrome)) {
      const reason = chrome.signalCode ? `sinal ${chrome.signalCode}` : `codigo ${chrome.exitCode}`;
      const detail = getFailureDetail?.();
      throw new Error(`O Chrome encerrou antes de abrir a janela (${reason})${detail ? `: ${detail}` : '.'}`);
    }
    for (const args of searches) {
      const result = await runCommand('xdotool', args, {
        env: environment, timeoutMs: 1_500, allowFailure: true,
      });
      const ids = parseWindowIds(result.stdout.toString('utf8'));
      if (ids.length) return ids.at(-1);
    }
    const active = await runCommand('xdotool', ['getactivewindow'], {
      env: environment, timeoutMs: 1_500, allowFailure: true,
    });
    const ids = parseWindowIds(active.stdout.toString('utf8'));
    if (ids.length) return ids.at(-1);
    await delay(200);
  }
  return null;
}

async function pathExists(target) {
  try {
    await fs.access(target);
    return true;
  } catch {
    return false;
  }
}

function runCommand(command, args, { env, input = null, timeoutMs = 8_000, maxBytes = 1_000_000, allowFailure = false } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { env, stdio: ['pipe', 'pipe', 'pipe'] });
    const stdout = [];
    const stderr = [];
    let size = 0;
    let settled = false;
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      finish(new Error(`${command} excedeu o tempo permitido.`));
    }, timeoutMs);

    const finish = (error, code = null) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (error) return reject(error);
      const result = { stdout: Buffer.concat(stdout), stderr: Buffer.concat(stderr), code };
      if (code !== 0 && !allowFailure) {
        const detail = result.stderr.toString('utf8').trim().replace(/[\r\n]+/g, ' ').slice(0, 220);
        return reject(new Error(detail || `${command} terminou com codigo ${code}.`));
      }
      resolve(result);
    };

    const collect = (target) => (chunk) => {
      size += chunk.length;
      if (size > maxBytes) {
        child.kill('SIGKILL');
        finish(new Error(`${command} produziu dados demais.`));
        return;
      }
      target.push(chunk);
    };
    child.stdout.on('data', collect(stdout));
    child.stderr.on('data', collect(stderr));
    child.stdin.on('error', () => {});
    child.once('error', finish);
    child.once('exit', (code) => finish(null, code));
    if (input === null) child.stdin.end();
    else child.stdin.end(input);
  });
}

async function terminateProcessGroup(child, timeoutMs) {
  if (!child?.pid || (!childRunning(child) && !processGroupRunning(child.pid))) return;
  try { process.kill(-child.pid, 'SIGTERM'); } catch { if (childRunning(child)) child.kill('SIGTERM'); }
  await waitForProcessGroupExit(child.pid, timeoutMs);
  if (processGroupRunning(child.pid)) {
    try { process.kill(-child.pid, 'SIGKILL'); } catch { if (childRunning(child)) child.kill('SIGKILL'); }
    await waitForProcessGroupExit(child.pid, 1_500);
  }
}

async function terminateProcess(child, timeoutMs) {
  if (!childRunning(child)) return;
  child.kill('SIGTERM');
  await waitForExit(child, timeoutMs);
  if (childRunning(child)) {
    child.kill('SIGKILL');
    await waitForExit(child, 1_000);
  }
}

function waitForExit(child, timeoutMs) {
  if (!childRunning(child)) return Promise.resolve();
  return Promise.race([
    new Promise((resolve) => child.once('exit', resolve)),
    delay(timeoutMs),
  ]);
}

function childRunning(child) {
  return Boolean(child && child.exitCode === null && child.signalCode === null);
}

function processGroupRunning(pid) {
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try {
    process.kill(-pid, 0);
    return true;
  } catch {
    return false;
  }
}

async function waitForProcessGroupExit(pid, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (processGroupRunning(pid) && Date.now() < deadline) await delay(100);
}

function safeMessage(error) {
  return sanitizeDiagnostic(error?.message || 'erro desconhecido').replace(/[\r\n]+/g, ' ').slice(0, 240);
}

function sanitizeDiagnostic(value) {
  return String(value).replace(
    /([?&](?:access_token|authuser|code|credential|password|refresh_token|token)=)[^&\s]+/gi,
    '$1[oculto]',
  );
}

function clamp(value, minimum, maximum) {
  if (!Number.isFinite(value)) return minimum;
  return Math.max(minimum, Math.min(maximum, value));
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}
