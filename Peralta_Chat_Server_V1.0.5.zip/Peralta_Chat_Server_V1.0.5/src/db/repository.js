import { randomUUID } from 'node:crypto';
import { query, transaction } from './pool.js';

export async function loadUserConfiguration(userId) {
  const [userResult, settingsResult, channelsResult, messagesResult, globalResult] = await Promise.all([
    query(`SELECT id, username, display_name, status, expires_at FROM users WHERE id = $1 AND role = 'user'`, [userId]),
    query(`SELECT * FROM user_settings WHERE user_id = $1`, [userId]),
    query(`SELECT * FROM channels WHERE user_id = $1 ORDER BY created_at, id`, [userId]),
    query(`SELECT * FROM messages WHERE user_id = $1 ORDER BY channel_id NULLS FIRST, position`, [userId]),
    query(`SELECT value FROM system_settings WHERE key = 'scan_interval_seconds'`),
  ]);
  if (!userResult.rowCount) return null;

  const user = userResult.rows[0];
  const settings = settingsResult.rows[0];
  return {
    user,
    settings,
    channels: channelsResult.rows,
    messages: messagesResult.rows,
    scanIntervalSeconds: Number(globalResult.rows[0]?.value ?? 180),
  };
}

export async function appendEventLog(userId, message, level = 'info') {
  const safe = String(message ?? '').replace(/[\r\n]+/g, ' ').slice(0, 2000);
  await query(
    `INSERT INTO event_logs (user_id, level, message) VALUES ($1, $2, $3)`,
    [userId, level, safe],
  );
}

export async function upsertLiveSnapshot(userId, snapshot) {
  const terminal = ['ENCERRADO', 'REMOVIDO', 'PARADO', 'LISTA CONCLUIDA'].includes(snapshot.status);
  await query(
    `INSERT INTO live_sessions
      (id, user_id, channel_id, video_id, title, channel_name, status, sent, failures, ended_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, CASE WHEN $10 THEN now() ELSE NULL END)
     ON CONFLICT (user_id, video_id) DO UPDATE SET
       channel_id = EXCLUDED.channel_id,
       title = EXCLUDED.title,
       channel_name = EXCLUDED.channel_name,
       status = EXCLUDED.status,
       sent = EXCLUDED.sent,
       failures = EXCLUDED.failures,
       last_activity_at = now(),
       ended_at = CASE WHEN $10 THEN now() ELSE NULL END`,
    [
      randomUUID(), userId, snapshot.channelId || null, snapshot.videoId,
      snapshot.title || 'Sem titulo', snapshot.channelName || '', snapshot.status,
      snapshot.sent || 0, snapshot.failures || 0, terminal,
    ],
  );
}

export async function setYouTubeProfile(userId, profile) {
  await query(
    `INSERT INTO youtube_profiles
      (user_id, status, channel_name, channel_handle, last_checked_at, updated_at)
     VALUES ($1, $2, $3, $4, now(), now())
     ON CONFLICT (user_id) DO UPDATE SET
       status = EXCLUDED.status,
       channel_name = EXCLUDED.channel_name,
       channel_handle = EXCLUDED.channel_handle,
       last_checked_at = now(), updated_at = now()`,
    [userId, profile.status, profile.channelName || null, profile.channelHandle || null],
  );
}

export async function replaceMessages(userId, channelId, contents) {
  return transaction(async (client) => {
    if (channelId) {
      const owned = await client.query(`SELECT id FROM channels WHERE id = $1 AND user_id = $2`, [channelId, userId]);
      if (!owned.rowCount) throw new Error('Canal nao encontrado.');
      await client.query(`DELETE FROM messages WHERE user_id = $1 AND channel_id = $2`, [userId, channelId]);
    } else {
      await client.query(`DELETE FROM messages WHERE user_id = $1 AND channel_id IS NULL`, [userId]);
    }
    for (let index = 0; index < contents.length; index += 1) {
      await client.query(
        `INSERT INTO messages (id, user_id, channel_id, position, content)
         VALUES ($1, $2, $3, $4, $5)`,
        [randomUUID(), userId, channelId || null, index, contents[index]],
      );
    }
  });
}

export async function audit({ actorUserId, targetUserId = null, action, details = {}, ipAddress = '' }) {
  await query(
    `INSERT INTO audit_logs (actor_user_id, target_user_id, action, details, ip_address)
     VALUES ($1, $2, $3, $4::jsonb, $5)`,
    [actorUserId, targetUserId, action, JSON.stringify(details), ipAddress],
  );
}
