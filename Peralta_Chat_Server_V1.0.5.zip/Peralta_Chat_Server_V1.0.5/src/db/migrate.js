import { randomUUID } from 'node:crypto';
import { config } from '../config.js';
import { hashPassword } from '../auth/password.js';
import { pool, query, transaction } from './pool.js';

const schema = `
CREATE TABLE IF NOT EXISTS schema_migrations (
  version integer PRIMARY KEY,
  applied_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY,
  username text NOT NULL UNIQUE,
  display_name text NOT NULL,
  password_hash text NOT NULL,
  role text NOT NULL CHECK (role IN ('admin', 'user')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
  must_change_password boolean NOT NULL DEFAULT true,
  expires_at timestamptz,
  max_channels integer NOT NULL DEFAULT 20 CHECK (max_channels BETWEEN 1 AND 200),
  last_login_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sessions (
  id uuid PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  csrf_hash text NOT NULL,
  user_agent text NOT NULL DEFAULT '',
  ip_address text NOT NULL DEFAULT '',
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sessions_user_id_idx ON sessions(user_id);
CREATE INDEX IF NOT EXISTS sessions_expires_at_idx ON sessions(expires_at);

CREATE TABLE IF NOT EXISTS system_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL,
  updated_by uuid REFERENCES users(id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_settings (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  message_interval_ms integer NOT NULL DEFAULT 30000 CHECK (message_interval_ms BETWEEN 1 AND 86400000),
  repeat_messages boolean NOT NULL DEFAULT true,
  shuffle_messages boolean NOT NULL DEFAULT true,
  use_per_channel_messages boolean NOT NULL DEFAULT false,
  paused boolean NOT NULL DEFAULT false,
  monitor_enabled boolean NOT NULL DEFAULT true,
  candidate_limit integer NOT NULL DEFAULT 24 CHECK (candidate_limit BETWEEN 6 AND 60),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS channels (
  id uuid PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  url text NOT NULL,
  normalized_url text NOT NULL,
  label text NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, normalized_url)
);
CREATE INDEX IF NOT EXISTS channels_user_id_idx ON channels(user_id);

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel_id uuid REFERENCES channels(id) ON DELETE CASCADE,
  position integer NOT NULL,
  content text NOT NULL CHECK (char_length(content) BETWEEN 1 AND 200),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE NULLS NOT DISTINCT (user_id, channel_id, position)
);
CREATE INDEX IF NOT EXISTS messages_user_channel_idx ON messages(user_id, channel_id, position);

CREATE TABLE IF NOT EXISTS youtube_profiles (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'disconnected' CHECK (status IN ('connected', 'disconnected', 'checking', 'error')),
  channel_name text,
  channel_handle text,
  last_checked_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS live_sessions (
  id uuid PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel_id uuid REFERENCES channels(id) ON DELETE SET NULL,
  video_id text NOT NULL,
  title text NOT NULL DEFAULT 'Sem titulo',
  channel_name text NOT NULL DEFAULT '',
  status text NOT NULL,
  sent integer NOT NULL DEFAULT 0,
  failures integer NOT NULL DEFAULT 0,
  started_at timestamptz NOT NULL DEFAULT now(),
  last_activity_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz,
  UNIQUE (user_id, video_id)
);
CREATE INDEX IF NOT EXISTS live_sessions_user_activity_idx ON live_sessions(user_id, last_activity_at DESC);

CREATE TABLE IF NOT EXISTS event_logs (
  id bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  level text NOT NULL DEFAULT 'info',
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS event_logs_user_created_idx ON event_logs(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS audit_logs (
  id bigserial PRIMARY KEY,
  actor_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  target_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  action text NOT NULL,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip_address text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_logs_created_idx ON audit_logs(created_at DESC);
`;

const DEFAULT_MESSAGES = ['Salve!', 'Olá!', 'Tudo bem?', 'Live top!', 'Boa live!'];

export async function runMigrations() {
  await pool.query(schema);
  await query(
    `INSERT INTO system_settings (key, value)
     VALUES ('scan_interval_seconds', '180'::jsonb)
     ON CONFLICT (key) DO NOTHING`,
  );
  await query(`INSERT INTO schema_migrations (version) VALUES (1) ON CONFLICT DO NOTHING`);
}

export async function ensureInitialAdmin() {
  const existing = await query(`SELECT id FROM users WHERE role = 'admin' ORDER BY created_at LIMIT 1`);
  if (existing.rowCount > 0) return existing.rows[0].id;
  if (!config.adminPassword) throw new Error('ADMIN_PASSWORD nao foi configurada.');

  const id = randomUUID();
  const passwordHash = await hashPassword(config.adminPassword);
  await query(
    `INSERT INTO users
      (id, username, display_name, password_hash, role, status, must_change_password, max_channels)
     VALUES ($1, $2, 'Administrador', $3, 'admin', 'active', false, 200)`,
    [id, config.adminUsername, passwordHash],
  );
  return id;
}

export async function createUserWithDefaults({ username, displayName, passwordHash, expiresAt, maxChannels }) {
  return transaction(async (client) => {
    const userId = randomUUID();
    await client.query(
      `INSERT INTO users
        (id, username, display_name, password_hash, role, expires_at, max_channels)
       VALUES ($1, $2, $3, $4, 'user', $5, $6)`,
      [userId, username, displayName, passwordHash, expiresAt || null, maxChannels],
    );
    await client.query(`INSERT INTO user_settings (user_id) VALUES ($1)`, [userId]);
    await client.query(`INSERT INTO youtube_profiles (user_id) VALUES ($1)`, [userId]);
    for (let index = 0; index < DEFAULT_MESSAGES.length; index += 1) {
      await client.query(
        `INSERT INTO messages (id, user_id, channel_id, position, content)
         VALUES ($1, $2, NULL, $3, $4)`,
        [randomUUID(), userId, index, DEFAULT_MESSAGES[index]],
      );
    }
    return userId;
  });
}

export async function pruneExpiredData() {
  await query(`DELETE FROM sessions WHERE expires_at <= now()`);
  await query(
    `DELETE FROM event_logs
     WHERE created_at < now() - make_interval(days => $1)`,
    [config.logRetentionDays],
  );
}

export { DEFAULT_MESSAGES };
