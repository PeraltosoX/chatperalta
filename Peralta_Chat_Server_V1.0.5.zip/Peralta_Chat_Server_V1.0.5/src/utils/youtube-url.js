const VIDEO_ID = /(?:v=|youtu\.be\/|\/live\/)([A-Za-z0-9_-]{11})/i;
const ALLOWED_HOSTS = new Set(['youtube.com', 'www.youtube.com', 'm.youtube.com']);

export function normalizeStreamsUrl(input) {
  let value = String(input ?? '').trim();
  if (!value) throw new Error('Informe o link do canal.');
  if (!/^https?:\/\//i.test(value)) value = `https://www.youtube.com/${value.replace(/^\/+/, '')}`;

  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    throw new Error('Link de canal invalido.');
  }
  if (!ALLOWED_HOSTS.has(parsed.hostname.toLowerCase())) {
    throw new Error('Use um link de canal do YouTube.');
  }
  const originalVideoId = parsed.searchParams.get('v');
  const originalParts = parsed.pathname.split('/').filter(Boolean);
  if (originalParts[0]?.toLowerCase() === 'watch' && originalVideoId) {
    throw new Error('Use o link do canal, nao o link de uma live.');
  }
  if (originalParts[0]?.toLowerCase() === 'live' && originalParts[1]?.length === 11) {
    throw new Error('Use o link do canal, nao o link de uma live.');
  }
  parsed.protocol = 'https:';
  parsed.hostname = 'www.youtube.com';
  parsed.search = '';
  parsed.hash = '';

  const parts = parsed.pathname.split('/').filter(Boolean);
  if (!parts.length) throw new Error('O link precisa identificar um canal do YouTube.');
  const removable = new Set(['streams', 'videos', 'featured', 'shorts', 'live']);
  if (removable.has((parts.at(-1) || '').toLowerCase())) parts.pop();
  if (!parts.length) throw new Error('O link precisa identificar um canal do YouTube.');
  parsed.pathname = `/${parts.join('/')}/streams`;
  return parsed.toString().replace(/\/$/, '');
}

export function channelLabel(input) {
  try {
    const value = normalizeStreamsUrl(input);
    const parts = new URL(value).pathname.split('/').filter(Boolean).filter((part) => part !== 'streams');
    const handle = parts.find((part) => part.startsWith('@'));
    if (handle) return handle;
    if (parts[0] === 'channel' && parts[1]) return shorten(parts[1], 18);
    return shorten(parts.at(-1) || 'Canal', 24);
  } catch {
    return shorten(String(input || 'Canal'), 24);
  }
}

export function extractVideoId(input) {
  return String(input ?? '').match(VIDEO_ID)?.[1] || null;
}

function shorten(value, size) {
  return value.length <= size ? value : `${value.slice(0, size)}…`;
}
