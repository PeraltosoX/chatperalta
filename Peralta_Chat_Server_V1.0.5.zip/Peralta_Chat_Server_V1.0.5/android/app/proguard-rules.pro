# O controlador usa somente APIs nativas do Android.

