#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
[[ -f .env ]] || { echo "Arquivo .env nao encontrado."; exit 1; }

mkdir -p backups
chmod 700 backups
peralta_stamp="$(date -u +%Y%m%d_%H%M%S)"

docker compose exec -T postgres sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" --clean --if-exists' \
  | gzip > "backups/postgres_${peralta_stamp}.sql.gz"

docker run --rm \
  -v peralta-chat-server_chrome-profiles:/source:ro \
  -v "$(pwd)/backups:/backup" \
  alpine:3.21 sh -c "cd /source && tar -czf /backup/chrome_profiles_${peralta_stamp}.tar.gz ."

chmod 600 "backups/postgres_${peralta_stamp}.sql.gz" "backups/chrome_profiles_${peralta_stamp}.tar.gz"
echo "Backup criado em $(pwd)/backups com identificador ${peralta_stamp}."

