#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."

[[ -f .env ]] || { echo "O arquivo .env nao existe. Execute scripts/instalar.sh primeiro."; exit 1; }
docker compose config --quiet
docker compose up -d --build --remove-orphans
docker compose ps
echo "Atualizacao concluida sem apagar PostgreSQL nem perfis do Chrome."
