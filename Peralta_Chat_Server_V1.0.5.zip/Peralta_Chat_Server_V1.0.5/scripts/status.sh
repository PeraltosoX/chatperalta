#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
docker compose ps
echo
docker compose logs --tail=120 server caddy

