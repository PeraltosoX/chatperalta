#!/usr/bin/env bash
set -Eeuo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Execute como root: sudo ./scripts/preparar-vps-1gb.sh"
  exit 1
fi

peralta_memory_kib="$(awk '/^MemTotal:/ { print $2 }' /proc/meminfo)"
peralta_swap_kib="$(awk '/^SwapTotal:/ { print $2 }' /proc/meminfo)"

if (( peralta_memory_kib >= 2097152 )); then
  echo "A VPS tem pelo menos 2 GB de RAM. Nenhuma swap foi criada."
  exit 0
fi

if (( peralta_swap_kib >= 1048576 )); then
  echo "A VPS ja tem pelo menos 1 GB de swap ativa. Nenhuma alteracao foi feita."
  exit 0
fi

if [[ -e /swapfile ]]; then
  echo "Ja existe /swapfile, mas ele nao fornece 1 GB de swap ativa."
  echo "Nao vou sobrescrever esse arquivo automaticamente. Verifique-o antes de continuar."
  exit 1
fi

peralta_swap_created=false
cleanup_failed_swap() {
  if [[ "${peralta_swap_created}" == true ]]; then
    swapoff /swapfile 2>/dev/null || true
    rm -f /swapfile
  fi
}
trap cleanup_failed_swap ERR

peralta_available_kib="$(df --output=avail -k / | tail -n 1 | tr -d ' ')"
if (( peralta_available_kib < 2621440 )); then
  echo "Sao necessarios cerca de 2,5 GB livres para criar a swap de seguranca."
  exit 1
fi

echo "Criando 2 GB de swap para dar margem ao Chrome..."
peralta_swap_created=true
if ! fallocate -l 2G /swapfile; then
  dd if=/dev/zero of=/swapfile bs=1M count=2048 status=progress
fi
chmod 600 /swapfile
mkswap /swapfile
swapon /swapfile

printf '%s\n' 'vm.swappiness=20' > /etc/sysctl.d/99-peralta-chat.conf
sysctl -q -p /etc/sysctl.d/99-peralta-chat.conf

if ! grep -Eq '^/swapfile[[:space:]]+none[[:space:]]+swap[[:space:]]' /etc/fstab; then
  printf '%s\n' '/swapfile none swap sw 0 0' >> /etc/fstab
fi

peralta_swap_created=false
trap - ERR

echo "Swap criada e configurada para continuar ativa depois de reiniciar o Ubuntu."
free -h
