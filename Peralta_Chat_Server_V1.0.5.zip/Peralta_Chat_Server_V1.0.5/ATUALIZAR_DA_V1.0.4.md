# Atualizar da V1.0.4 para a V1.0.5 sem perder dados

Esta atualizacao corrige a abertura das abas do Chrome automatico e a falha interna exibida durante **Concluir login**. O arquivo de cookies ja gravado na V1.0.4 e preservado.

Nunca execute `docker compose down -v`: a opcao `-v` apaga os volumes.

## 1. Fazer backup da V1.0.4

```bash
cd /opt/Peralta_Chat_Server_V1.0.4
./scripts/backup.sh
```

## 2. Aplicar a V1.0.5

Depois de enviar e descompactar `Peralta_Chat_Server_V1.0.5.zip` em `/opt`:

```bash
cd /opt/Peralta_Chat_Server_V1.0.5
chmod +x scripts/*.sh
./scripts/migrar-da-v1.0.4.sh
```

O script copia o `.env`, recompila o container e conecta aos mesmos volumes do PostgreSQL e dos perfis.

## 3. Verificar a conta existente

Entre no painel e clique primeiro em **Verificar sessao**. Como o arquivo de cookies da V1.0.4 foi mantido, a conta pode ser reconhecida sem outro login. Somente abra o login manual novamente se o painel continuar indicando sessao desconectada.

Confira tambem:

```bash
curl -sS https://peraltaultrachat.shop/healthz
docker compose logs --since=5m --tail=100 server
```

A saude deve informar `"version":"1.0.5"`.
