import { api, setBusy } from './common.js?v=1.0.5';

const form = document.querySelector('#login-form');
const errorBox = document.querySelector('#login-error');

api('/api/auth/me').then((result) => {
  if (result.user?.role === 'user') location.replace('/app');
}).catch(() => {});

api('/api/version').then((result) => {
  document.querySelectorAll('[data-version]').forEach((element) => { element.textContent = `V${result.version}`; });
}).catch(() => {});

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  errorBox.textContent = '';
  const button = form.querySelector('button[type="submit"]');
  setBusy(button, true, 'Entrando…');
  const data = new FormData(form);
  try {
    const result = await api('/api/auth/login', {
      method: 'POST',
      body: { username: data.get('username'), password: data.get('password'), audience: 'user' },
    });
    location.replace(result.redirect || '/app');
  } catch (error) {
    errorBox.textContent = error.message;
    setBusy(button, false);
  }
});
