#!/usr/bin/env bash
set -Eeuo pipefail

cd "$(dirname "$0")/.."

if ! command -v docker >/dev/null 2>&1 || ! docker compose version >/dev/null 2>&1; then
  echo "Docker Engine com Docker Compose V2 nao foi encontrado."
  echo "Siga primeiro a etapa 'Instalar o Docker' do arquivo INSTALAR_NO_SERVIDOR.md."
  exit 1
fi

if [[ ! -f .env ]]; then
  command -v openssl >/dev/null 2>&1 || { echo "Instale openssl: sudo apt install -y openssl"; exit 1; }
  read -r -p "Dominio [peraltaultrachat.shop]: " peralta_domain
  peralta_domain="${peralta_domain:-peraltaultrachat.shop}"
  peralta_domain="${peralta_domain#https://}"
  peralta_domain="${peralta_domain#http://}"
  peralta_domain="${peralta_domain%%/*}"
  read -r -p "Usuario administrador [peraltaadmin]: " peralta_admin
  peralta_admin="${peralta_admin:-peraltaadmin}"
  while true; do
    read -r -s -p "Senha do administrador (minimo 12; use letras, numeros e ._@%+=:-): " peralta_admin_password
    echo
    if [[ ${#peralta_admin_password} -ge 12 && "$peralta_admin_password" =~ ^[A-Za-z0-9._@%+=:-]+$ ]]; then break; fi
    echo "Use pelo menos 12 caracteres e somente letras, numeros ou ._@%+=:-"
  done
  peralta_db_password="$(openssl rand -hex 24)"
  peralta_session_secret="$(openssl rand -hex 32)"

  umask 077
  cat > .env <<EOF
DOMAIN=${peralta_domain}
TZ=America/Sao_Paulo
ADMIN_USERNAME=${peralta_admin}
ADMIN_PASSWORD=${peralta_admin_password}
POSTGRES_PASSWORD=${peralta_db_password}
POSTGRES_DB=peralta_chat
POSTGRES_USER=peralta_chat
SESSION_SECRET=${peralta_session_secret}
PORT=8080
PROFILE_ROOT=/data/chrome-profiles
LOG_RETENTION_DAYS=30
SESSION_DAYS=30
TRUST_PROXY=true
EOF
  chmod 600 .env
  unset peralta_admin_password peralta_db_password peralta_session_secret
  echo "Arquivo .env criado com segredos aleatorios."
else
  echo "Usando o arquivo .env existente."
fi

docker compose config --quiet
docker compose up -d --build

echo
docker compose ps
echo
peralta_domain="$(sed -n 's/^DOMAIN=//p' .env | head -n 1)"
echo "Peralta Chat Server V1.0.0 iniciado."
echo "Usuarios: https://${peralta_domain}/"
echo "Administrador: https://${peralta_domain}/dbmadmin"
echo "O Docker esta em modo destacado e continuara rodando ao fechar o terminal."
