# Historico de versoes

## Peralta Chat Server V1.0.0 — projeto novo

- Projeto de servidor separado; nao atualiza nem modifica o Peralta Chat V4.83.
- Painel responsivo de usuario pelo navegador.
- Painel administrativo exclusivo em `/dbmadmin`.
- Aplicativo Android controlador, sem area administrativa.
- Contas criadas somente pelo administrador e troca obrigatoria da senha temporaria.
- Processo e perfil persistente do Chrome separados por usuario.
- PostgreSQL interno com separacao de dados por usuario.
- Descoberta de lives pelo HTML publico de `/streams` e da pagina de video, sem YouTube Data API.
- Busca global padrao de 180 segundos, editavel apenas pelo administrador.
- Canais, listas, intervalos, pausa, repeticao e embaralhamento atualizados em tempo real ao salvar.
- Docker Compose em segundo plano com reinicio automatico.
- HTTPS automatico para `peraltaultrachat.shop` pelo Caddy.

