import path from 'node:path';

export const APP_NAME = 'Peralta Chat Server';
export const VERSION = '1.0.0';

function intEnv(name, fallback, minimum, maximum) {
  const parsed = Number.parseInt(process.env[name] ?? '', 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(maximum, Math.max(minimum, parsed));
}

export const config = Object.freeze({
  appName: APP_NAME,
  version: VERSION,
  port: intEnv('PORT', 8080, 1, 65535),
  domain: (process.env.DOMAIN || 'peraltaultrachat.shop').trim().toLowerCase(),
  databaseUrl: process.env.DATABASE_URL || 'postgresql://peralta_chat:peralta_chat@127.0.0.1:5432/peralta_chat',
  profileRoot: path.resolve(process.env.PROFILE_ROOT || '/data/chrome-profiles'),
  sessionDays: intEnv('SESSION_DAYS', 30, 1, 365),
  logRetentionDays: intEnv('LOG_RETENTION_DAYS', 30, 1, 3650),
  trustProxy: String(process.env.TRUST_PROXY || 'true').toLowerCase() === 'true',
  adminUsername: (process.env.ADMIN_USERNAME || 'peraltaadmin').trim().toLowerCase(),
  adminPassword: process.env.ADMIN_PASSWORD || '',
  sessionSecret: process.env.SESSION_SECRET || '',
  chromeExecutablePath: process.env.CHROME_EXECUTABLE_PATH || '/usr/bin/google-chrome',
});

export function validateEnvironment() {
  const errors = [];
  if (process.env.NODE_ENV === 'production') {
    if (config.adminPassword.length < 12 || config.adminPassword.includes('COLOQUE_')) {
      errors.push('ADMIN_PASSWORD precisa ter pelo menos 12 caracteres e nao pode ser o valor de exemplo.');
    }
    if (config.sessionSecret.length < 32 || config.sessionSecret.includes('COLOQUE_')) {
      errors.push('SESSION_SECRET precisa ter pelo menos 32 caracteres e nao pode ser o valor de exemplo.');
    }
  }
  if (!/^[a-z0-9.-]+$/i.test(config.domain)) errors.push('DOMAIN invalido.');
  if (errors.length) throw new Error(`Configuracao invalida:\n- ${errors.join('\n- ')}`);
}
