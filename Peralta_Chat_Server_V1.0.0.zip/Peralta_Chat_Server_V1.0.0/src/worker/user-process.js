import { appendEventLog, loadUserConfiguration, setYouTubeProfile, upsertLiveSnapshot } from '../db/repository.js';
import { pool } from '../db/pool.js';
import { BrowserController } from '../services/browser-controller.js';
import { YouTubeMonitor } from '../services/youtube-monitor.js';

const userId = process.env.PERALTA_USER_ID;
if (!/^[0-9a-f-]{36}$/i.test(userId || '')) throw new Error('PERALTA_USER_ID invalido.');

let configuration = null;
let closing = false;
let logChain = Promise.resolve();

function logger(message, level = 'info') {
  const safe = String(message ?? '').replace(/[\r\n]+/g, ' ').slice(0, 2000);
  logChain = logChain
    .then(() => appendEventLog(userId, safe, level))
    .catch((error) => console.error(`[${userId}] Nao foi possivel gravar log:`, error.message));
  process.send?.({ type: 'event', event: 'log', level, message: safe });
}

function publish(snapshot) {
  void upsertLiveSnapshot(userId, snapshot).catch((error) => logger(`Falha ao registrar estado da live: ${error.message}`, 'error'));
  process.send?.({ type: 'event', event: 'live', snapshot });
}

const browser = new BrowserController(userId, logger);
const monitor = new YouTubeMonitor({ browser, logger, publish });

async function reload() {
  const next = await loadUserConfiguration(userId);
  if (!next || next.user.status !== 'active' || (next.user.expires_at && new Date(next.user.expires_at) <= new Date())) {
    monitor.stop('PARADO');
    return false;
  }
  configuration = next;
  monitor.update(next);
  sendStatus();
  return true;
}

function sendStatus() {
  process.send?.({
    type: 'status',
    status: {
      pid: process.pid,
      ...monitor.snapshot(),
      browserOpen: Boolean(browser.context),
      updatedAt: new Date().toISOString(),
    },
  });
}

async function handleRequest(message) {
  const { requestId, command, payload } = message;
  try {
    let result;
    if (command === 'youtube.start') {
      result = await browser.startLogin();
    } else if (command === 'youtube.snapshot') {
      result = await browser.loginSnapshot();
    } else if (command === 'youtube.interact') {
      result = await browser.interactLogin(payload);
    } else if (command === 'youtube.finish') {
      result = await browser.finishLogin();
      await setYouTubeProfile(userId, result);
      if (result.status === 'connected') monitor.wake('conta conectada');
    } else if (command === 'youtube.cancel') {
      await browser.cancelLogin();
      result = { cancelled: true };
    } else if (command === 'youtube.check') {
      result = await browser.detectAccount();
      await setYouTubeProfile(userId, result);
    } else if (command === 'runtime.status') {
      result = monitor.snapshot();
    } else {
      throw new Error('Comando desconhecido.');
    }
    process.send?.({ type: 'response', requestId, ok: true, result });
  } catch (error) {
    process.send?.({ type: 'response', requestId, ok: false, error: error.message });
  } finally {
    sendStatus();
  }
}

process.on('message', (message) => {
  if (message?.type === 'reload') {
    void reload().catch((error) => logger(`Falha ao recarregar configuracao: ${error.message}`, 'error'));
  } else if (message?.type === 'request') {
    void handleRequest(message);
  }
});

async function shutdown() {
  if (closing) return;
  closing = true;
  monitor.stop('PARADO');
  await browser.close();
  await logChain.catch(() => {});
  await pool.end().catch(() => {});
  process.exit(0);
}

process.on('SIGTERM', () => void shutdown());
process.on('SIGINT', () => void shutdown());
process.on('uncaughtException', (error) => {
  console.error(`[${userId}] Erro nao tratado:`, error);
  void shutdown();
});
process.on('unhandledRejection', (error) => {
  console.error(`[${userId}] Rejeicao nao tratada:`, error);
});

await reload();
setInterval(sendStatus, 10_000).unref();
setInterval(() => void reload().catch((error) => logger(`Falha na sincronizacao periodica: ${error.message}`, 'error')), 60_000).unref();
sendStatus();

