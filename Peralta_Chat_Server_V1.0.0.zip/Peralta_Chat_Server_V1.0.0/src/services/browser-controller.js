import fs from 'node:fs/promises';
import path from 'node:path';
import { chromium } from 'playwright';
import { config } from '../config.js';

const LOW_MEMORY_ARGS = [
  '--disable-extensions',
  '--disable-component-extensions-with-background-pages',
  '--disable-background-mode',
  '--disable-background-networking',
  '--disable-background-timer-throttling',
  '--disable-backgrounding-occluded-windows',
  '--disable-renderer-backgrounding',
  '--disable-sync',
  '--disable-translate',
  '--disable-notifications',
  '--disable-print-preview',
  '--disable-default-apps',
  '--disable-component-update',
  '--disable-domain-reliability',
  '--disable-client-side-phishing-detection',
  '--disable-crash-reporter',
  '--disable-breakpad',
  '--metrics-recording-only',
  '--disable-gpu',
  '--js-flags=--expose-gc',
  '--process-per-site',
  '--renderer-process-limit=2',
  '--disk-cache-size=1048576',
  '--media-cache-size=1',
  '--disable-features=MediaRouter,TranslateUI,GlobalMediaControls,BackForwardCache,OptimizationHints,AutofillServerCommunication',
  '--no-first-run',
  '--no-default-browser-check',
  '--mute-audio',
];

const LOGIN_KEYS = new Set(['Enter', 'Tab', 'Escape', 'Backspace', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight']);

export class BrowserController {
  constructor(userId, logger) {
    this.userId = userId;
    this.logger = logger;
    this.context = null;
    this.contextPromise = null;
    this.loginPage = null;
    this.loginLastActivity = 0;
    this.profilePath = path.join(config.profileRoot, userId);
  }

  async ensureContext() {
    if (this.context) return this.context;
    if (this.contextPromise) return this.contextPromise;
    this.contextPromise = this.#launchWithRecovery();
    try {
      this.context = await this.contextPromise;
      return this.context;
    } finally {
      this.contextPromise = null;
    }
  }

  async #launchWithRecovery() {
    await fs.mkdir(this.profilePath, { recursive: true, mode: 0o700 });
    let lastError;
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      try {
        const context = await chromium.launchPersistentContext(this.profilePath, {
          executablePath: config.chromeExecutablePath || undefined,
          headless: false,
          viewport: { width: 1100, height: 760 },
          locale: 'pt-BR',
          timezoneId: process.env.TZ || 'America/Sao_Paulo',
          args: LOW_MEMORY_ARGS,
          ignoreDefaultArgs: ['--enable-automation'],
        });
        context.on('close', () => { this.context = null; });
        await context.route('**/*', async (route) => {
          try {
            const request = route.request();
            const url = request.url();
            const type = request.resourceType();
            const loginActive = this.loginPage && !this.loginPage.isClosed();
            const heavy = /googlevideo\.com|doubleclick\.net|googlesyndication\.com|googleadservices\.com/i.test(url);
            if (!loginActive && (['media', 'image', 'font'].includes(type) || heavy)) await route.abort();
            else await route.continue();
          } catch {
            try { await route.continue(); } catch { /* request already gone */ }
          }
        });
        for (const page of context.pages()) {
          if (page.url() === 'about:blank') await page.close().catch(() => {});
        }
        this.logger('Chrome individual iniciado com o perfil persistente desta conta.');
        return context;
      } catch (error) {
        lastError = error;
        if (attempt < 3) await delay(attempt === 1 ? 750 : 1500);
      }
    }
    throw new Error(`Nao foi possivel abrir o perfil do Chrome apos tres tentativas: ${lastError?.message || 'erro desconhecido'}`);
  }

  async startLogin() {
    const context = await this.ensureContext();
    if (this.loginPage && !this.loginPage.isClosed()) {
      await this.loginPage.bringToFront();
      this.loginLastActivity = Date.now();
      return this.loginSnapshot();
    }
    this.loginPage = await context.newPage();
    this.loginLastActivity = Date.now();
    await this.loginPage.goto(
      'https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fwww.youtube.com%2F',
      { waitUntil: 'commit', timeout: 20_000 },
    ).catch(() => {});
    await delay(1200);
    return this.loginSnapshot();
  }

  async loginSnapshot() {
    this.#assertLoginPage();
    this.#assertLoginFresh();
    const buffer = await this.loginPage.screenshot({ type: 'jpeg', quality: 72 });
    const title = await this.loginPage.title().catch(() => 'Login do Google');
    return {
      image: `data:image/jpeg;base64,${buffer.toString('base64')}`,
      width: 1100,
      height: 760,
      title,
      urlHost: safeHost(this.loginPage.url()),
    };
  }

  async interactLogin(payload) {
    this.#assertLoginPage();
    this.#assertLoginFresh();
    const action = String(payload?.action || '');
    this.loginLastActivity = Date.now();

    if (action === 'click') {
      const x = clamp(Number(payload.x), 0, 1100);
      const y = clamp(Number(payload.y), 0, 760);
      await this.loginPage.mouse.click(x, y);
    } else if (action === 'type') {
      const text = String(payload.text ?? '');
      if (!text || text.length > 500) throw new Error('Texto de login invalido.');
      // O texto e usado somente nesta chamada e nunca e gravado nem registrado.
      await this.loginPage.keyboard.type(text, { delay: 25 });
    } else if (action === 'key') {
      const key = String(payload.key || '');
      if (!LOGIN_KEYS.has(key)) throw new Error('Tecla nao permitida.');
      await this.loginPage.keyboard.press(key);
    } else if (action === 'wheel') {
      await this.loginPage.mouse.wheel(0, clamp(Number(payload.deltaY), -900, 900));
    } else {
      throw new Error('Acao de login invalida.');
    }
    await delay(action === 'type' ? 150 : 450);
    return this.loginSnapshot();
  }

  async finishLogin() {
    this.#assertLoginPage();
    const profile = await this.detectAccount(this.loginPage);
    if (profile.status === 'connected') {
      await this.loginPage.close().catch(() => {});
      this.loginPage = null;
      this.loginLastActivity = 0;
      this.logger(`Conta do YouTube conectada${profile.channelHandle ? `: ${profile.channelHandle}` : ''}.`);
    }
    return profile;
  }

  async cancelLogin() {
    if (this.loginPage && !this.loginPage.isClosed()) await this.loginPage.close().catch(() => {});
    this.loginPage = null;
    this.loginLastActivity = 0;
  }

  async detectAccount(page = null) {
    const context = await this.ensureContext();
    const ownPage = !page;
    const probePage = page || await context.newPage();
    try {
      const cookies = await context.cookies(['https://www.youtube.com', 'https://accounts.google.com']);
      const loggedByCookie = cookies.some((cookie) =>
        ['SAPISID', '__Secure-1PAPISID', '__Secure-3PAPISID', 'LOGIN_INFO'].includes(cookie.name));
      await probePage.goto('https://www.youtube.com/', { waitUntil: 'commit', timeout: 15_000 }).catch(() => {});
      await delay(900);
      const details = await probePage.evaluate(() => {
        const loggedIn = Boolean(window.ytcfg?.get?.('LOGGED_IN'));
        const avatar = document.querySelector('button#avatar-btn, ytd-topbar-menu-button-renderer #avatar-btn');
        const text = document.body?.innerText || '';
        const handle = text.match(/@[\p{L}\p{N}._-]{2,}/u)?.[0] || null;
        return { loggedIn, avatar: Boolean(avatar), handle };
      }).catch(() => ({ loggedIn: false, avatar: false, handle: null }));
      const connected = loggedByCookie && (details.loggedIn || details.avatar);
      return {
        status: connected ? 'connected' : 'disconnected',
        channelName: null,
        channelHandle: connected ? details.handle : null,
      };
    } finally {
      if (ownPage) await probePage.close().catch(() => {});
    }
  }

  async close() {
    await this.cancelLogin();
    if (this.context) await this.context.close().catch(() => {});
    this.context = null;
  }

  #assertLoginPage() {
    if (!this.loginPage || this.loginPage.isClosed()) throw new Error('A janela de login nao esta aberta.');
  }

  #assertLoginFresh() {
    if (Date.now() - this.loginLastActivity > 20 * 60_000) {
      void this.cancelLogin();
      throw new Error('A janela de login expirou depois de 20 minutos. Abra novamente.');
    }
  }
}

function safeHost(value) {
  try { return new URL(value).hostname; } catch { return ''; }
}

function clamp(value, minimum, maximum) {
  if (!Number.isFinite(value)) return minimum;
  return Math.max(minimum, Math.min(maximum, value));
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}
