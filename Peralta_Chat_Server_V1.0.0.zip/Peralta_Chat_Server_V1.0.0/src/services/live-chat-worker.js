import { MessageCycle } from './message-cycle.js';
import {
  detectTerminalReason,
  detectUnavailableReason,
  findVisibleInput,
  openPopout,
  sendMessage,
  slimChatDom,
} from './youtube-chat-tools.js';
import { BroadcastState } from './youtube-html.js';

export class LiveChatWorker {
  constructor({ candidate, browser, settings, messages, logger, publish, statusProbe }) {
    this.candidate = candidate;
    this.browser = browser;
    this.settings = { ...settings };
    this.messages = [...messages];
    this.logger = logger;
    this.publish = publish;
    this.statusProbe = statusProbe;
    this.sent = 0;
    this.failures = 0;
    this.paused = Boolean(settings.paused);
    this.stopping = false;
    this.page = null;
    this.input = null;
    this.messageVersion = 0;
    this.configurationVersion = 0;
    this.lastFullProbeAt = 0;
    this.lastTerminalProbeAt = 0;
    this.lastAttemptAt = 0;
    this.unavailableCount = 0;
    this.abortController = new AbortController();
    this.done = null;
  }

  start() {
    if (!this.done) this.done = this.#run();
    return this.done;
  }

  update({ settings, messages }) {
    const messagesChanged = JSON.stringify(this.messages) !== JSON.stringify(messages)
      || this.settings.repeat_messages !== settings.repeat_messages
      || this.settings.shuffle_messages !== settings.shuffle_messages;
    this.settings = { ...settings };
    this.paused = Boolean(settings.paused);
    if (messagesChanged) {
      this.messages = [...messages];
      this.messageVersion += 1;
      this.logger(`${this.#prefix()} Lista de mensagens atualizada em tempo real: ${messages.length} mensagem(ns).`);
    }
    this.configurationVersion += 1;
  }

  setPaused(paused) {
    if (this.paused === paused) return;
    this.paused = paused;
    this.settings.paused = paused;
    this.configurationVersion += 1;
    this.#publish(paused ? 'PAUSADO' : 'AGUARDANDO ENVIO');
  }

  stop(reason = 'PARADO') {
    if (this.stopping) return;
    this.stopping = true;
    this.stopReason = reason;
    this.abortController.abort();
    void this.page?.close().catch(() => {});
  }

  async #run() {
    let cycle = new MessageCycle(this.messages, this.settings.repeat_messages, this.settings.shuffle_messages);
    let cycleVersion = this.messageVersion;
    try {
      const context = await this.browser.ensureContext();
      this.#throwIfStopped();
      this.page = await context.newPage();
      this.#publish('CONECTANDO');
      await this.#openChat();

      while (!this.stopping) {
        if (!await this.#ensureActive()) break;
        await this.#waitWhilePaused();
        this.#throwIfStopped();

        this.input ||= await findVisibleInput(this.page, 10_000, true);
        if (!this.input) {
          this.unavailableCount += 1;
          const terminal = await detectTerminalReason(this.page);
          if (terminal) { this.logger(`${this.#prefix()} ${terminal}.`); this.stopReason = 'ENCERRADO'; break; }
          const unavailable = await detectUnavailableReason(this.page);
          this.#publish(unavailable ? unavailable.toUpperCase() : 'AGUARDANDO CHAT');
          if (unavailable && this.unavailableCount === 1) this.logger(`${this.#prefix()} ${unavailable}. O worker continuara verificando.`);
          if (this.unavailableCount >= 2) {
            const state = await this.statusProbe(this.candidate.videoId);
            if ([BroadcastState.ENDED, BroadcastState.NOT_LIVE].includes(state)) {
              this.stopReason = 'ENCERRADO';
              break;
            }
            await this.#reconnect();
            this.unavailableCount = 0;
          }
          await this.#delay(3000);
          continue;
        }
        if (this.unavailableCount) this.logger(`${this.#prefix()} Campo do chat localizado. AutoChat conectado.`);
        this.unavailableCount = 0;

        if (cycleVersion !== this.messageVersion) {
          cycle = new MessageCycle(this.messages, this.settings.repeat_messages, this.settings.shuffle_messages);
          cycleVersion = this.messageVersion;
        }
        const message = cycle.next();
        if (message === null) {
          if (!this.messages.length) {
            this.#publish('AGUARDANDO MENSAGENS');
            await this.#waitForMessageChange(cycleVersion);
            continue;
          }
          this.stopReason = 'LISTA CONCLUIDA';
          this.logger(`${this.#prefix()} Lista concluida; repetir lista esta desligado.`);
          break;
        }

        try {
          await this.#waitWhilePaused();
          this.#throwIfStopped();
          this.input = await sendMessage(this.page, this.input, message, this.#interval());
          this.sent += 1;
          this.#publish('ENVIANDO');
          this.logger(`${this.#prefix()} Mensagem enviada #${this.sent}: ${trim(message, 72)}`);
          await slimChatDom(this.page).catch(() => {});
        } catch (error) {
          if (this.stopping) break;
          this.input = null;
          this.failures += 1;
          this.#publish('FALHA / RECONECTANDO');
          this.logger(`${this.#prefix()} Falha no envio: ${trim(error.message, 180)}`);
          await this.#reconnect();
        }

        this.lastAttemptAt = Date.now();
        await this.#waitDynamicInterval();
      }
    } catch (error) {
      if (!this.stopping) {
        this.failures += 1;
        this.stopReason = 'ERRO';
        this.logger(`${this.#prefix()} Worker encerrou com erro: ${trim(error.message, 220)}`);
      }
    } finally {
      await this.page?.close().catch(() => {});
      this.page = null;
      this.#publish(this.stopReason || (this.stopping ? 'PARADO' : 'ENCERRADO'));
    }
  }

  async #openChat() {
    try {
      await openPopout(this.page, this.candidate.videoId);
    } catch (error) {
      this.failures += 1;
      this.logger(`${this.#prefix()} Falha ao abrir o chat inicialmente: ${trim(error.message, 180)}. O worker tentara novamente.`);
    }
  }

  async #reconnect() {
    this.#throwIfStopped();
    try {
      await openPopout(this.page, this.candidate.videoId);
      this.input = null;
      this.logger(`${this.#prefix()} Chat reconectado sem reiniciar o processo.`);
      return;
    } catch { /* replace only this page */ }
    const context = await this.browser.ensureContext();
    await this.page?.close().catch(() => {});
    this.page = await context.newPage();
    await openPopout(this.page, this.candidate.videoId).catch((error) => {
      this.logger(`${this.#prefix()} Reconexao ainda indisponivel: ${trim(error.message, 180)}.`);
    });
    this.input = null;
  }

  async #ensureActive() {
    if (this.stopReason === 'ENCERRADO') return false;
    const now = Date.now();
    if (now - this.lastTerminalProbeAt >= (this.#interval() < 1000 ? 1000 : 0)) {
      this.lastTerminalProbeAt = now;
      const reason = await detectTerminalReason(this.page);
      if (reason) { this.logger(`${this.#prefix()} ${reason}.`); this.stopReason = 'ENCERRADO'; return false; }
    }
    if (now - this.lastFullProbeAt < 8000) return true;
    this.lastFullProbeAt = now;
    const state = await this.statusProbe(this.candidate.videoId);
    if ([BroadcastState.ENDED, BroadcastState.NOT_LIVE].includes(state)) {
      this.logger(`${this.#prefix()} Transmissao encerrada ou nao esta mais ativa.`);
      this.stopReason = 'ENCERRADO';
      return false;
    }
    return true;
  }

  async #waitWhilePaused() {
    while (this.paused && !this.stopping) {
      this.#publish('PAUSADO');
      await this.#delay(500);
    }
  }

  async #waitDynamicInterval() {
    while (!this.stopping) {
      const remaining = this.lastAttemptAt + this.#interval() - Date.now();
      if (remaining <= 0) return;
      await this.#delay(Math.min(1000, remaining));
      if (Date.now() - this.lastFullProbeAt >= 8000 && !await this.#ensureActive()) return;
    }
  }

  async #waitForMessageChange(version) {
    while (!this.stopping && version === this.messageVersion) await this.#delay(300);
  }

  #interval() {
    return Math.min(86_400_000, Math.max(1, Number(this.settings.message_interval_ms) || 30_000));
  }

  #publish(status) {
    this.publish({
      channelId: this.candidate.channel.id,
      videoId: this.candidate.videoId,
      channelName: this.candidate.channel.label,
      title: this.candidate.title || 'Sem titulo',
      status,
      sent: this.sent,
      failures: this.failures,
    });
  }

  #prefix() { return `[${this.candidate.channel.label}] [${this.candidate.videoId}]`; }

  #throwIfStopped() {
    if (this.stopping) throw new Error('Worker parado');
  }

  async #delay(milliseconds) {
    if (this.stopping) return;
    await new Promise((resolve) => {
      if (this.abortController.signal.aborted) return resolve();
      const finish = () => {
        clearTimeout(timer);
        this.abortController.signal.removeEventListener('abort', onAbort);
        resolve();
      };
      const onAbort = () => finish();
      const timer = setTimeout(finish, milliseconds);
      this.abortController.signal.addEventListener('abort', onAbort, { once: true });
    });
  }
}

function trim(value, length) {
  const text = String(value ?? '').replace(/[\r\n]+/g, ' ');
  return text.length <= length ? text : `${text.slice(0, length - 3)}...`;
}
