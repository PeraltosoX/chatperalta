import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';

const root = new URL('../', import.meta.url);
const read = (relativePath) => fs.readFile(new URL(relativePath, root), 'utf8');

test('correcao da tela administrativa e permanente no CSS', async () => {
  const [css, adminScript] = await Promise.all([
    read('public/styles.css'),
    read('public/js/admin.js'),
  ]);
  assert.match(css, /\[hidden\]\s*\{\s*display:\s*none\s*!important;/i);
  assert.match(adminScript, /loginSection\.hidden\s*=\s*true/);
  assert.match(adminScript, /dashboard\.hidden\s*=\s*false/);
});

test('pacote inclui dependencias e politica do Chrome manual', async () => {
  const [dockerfile, policy] = await Promise.all([
    read('Dockerfile'),
    read('config/chrome-policy.json'),
  ]);
  for (const dependency of ['imagemagick', 'openbox', 'xdotool', 'xvfb']) {
    assert.match(dockerfile, new RegExp(`\\b${dependency}\\b`));
  }
  assert.equal(JSON.parse(policy).PasswordManagerEnabled, false);
});

test('versao 1.0.3 e cache renovado ficam consistentes', async () => {
  const [version, packageJson, config, serviceWorker, environmentExample] = await Promise.all([
    read('VERSION'),
    read('package.json'),
    read('src/config.js'),
    read('public/sw.js'),
    read('.env.example'),
  ]);
  assert.equal(version.trim(), '1.0.3');
  assert.equal(JSON.parse(packageJson).version, '1.0.3');
  assert.match(config, /VERSION\s*=\s*'1\.0\.3'/);
  assert.match(serviceWorker, /peralta-chat-server-v1\.0\.3/);
  assert.match(environmentExample, /Peralta Chat Server V1\.0\.3/);
});

test('V1.0.3 abre Chrome compativel com a VPS e preserva dados na migracao', async () => {
  const [manualLogin, browserController, migration, swap] = await Promise.all([
    read('src/services/manual-login-session.js'),
    read('src/services/browser-controller.js'),
    read('scripts/migrar-da-v1.0.2.sh'),
    read('scripts/preparar-vps-1gb.sh'),
  ]);
  assert.match(manualLogin, /'--no-sandbox'/);
  assert.match(manualLogin, /'--disable-crash-reporter'/);
  assert.match(manualLogin, /--classname', 'google-chrome'/);
  assert.match(manualLogin, /pathExists\(`\/tmp\/\.X11-unix\/X\$\{number\}`\)/);
  assert.match(manualLogin, /return null;\s*\}/);
  assert.match(browserController, /const probe = await context\.newPage\(\)/);
  assert.match(browserController, /async newPage\(\)/);
  assert.doesNotMatch(migration, /down\s+-v/);
  assert.match(migration, /install -m 600/);
  assert.match(swap, /swapon \/swapfile/);
});
