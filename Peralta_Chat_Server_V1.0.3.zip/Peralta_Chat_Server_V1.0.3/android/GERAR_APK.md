# Gerar o aplicativo Android

O aplicativo e apenas o controlador da area normal. Ele abre `https://peraltaultrachat.shop`, nao possui botao administrativo e bloqueia `/dbmadmin` e `/api/dbmadmin` dentro do WebView. O servidor tambem valida a permissao em todas as rotas.

1. Instale o Android Studio em um computador.
2. Clique em **Open** e escolha a pasta `android` deste projeto.
3. Aguarde a sincronizacao do Gradle.
4. Use **Build > Build APK(s)**.
5. O APK sera criado em `app/build/outputs/apk/debug/app-debug.apk`.

Para trocar o dominio no futuro, altere `PERALTA_SERVER_URL` em `gradle.properties` antes de gerar o novo APK.

Versao do aplicativo: **1.0.3**. Android minimo: **8.0 (API 26)**.
