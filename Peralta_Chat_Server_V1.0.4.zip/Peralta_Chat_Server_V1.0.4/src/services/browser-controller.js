import fs from 'node:fs/promises';
import path from 'node:path';
import { chromium } from 'playwright';
import { config } from '../config.js';
import { ManualLoginSession } from './manual-login-session.js';
import { hasYouTubeLoginCookie, isYouTubeSessionConnected } from './youtube-session.js';

const LOW_MEMORY_ARGS = [
  '--disable-extensions',
  '--disable-component-extensions-with-background-pages',
  '--disable-background-mode',
  '--disable-background-networking',
  '--disable-background-timer-throttling',
  '--disable-backgrounding-occluded-windows',
  '--disable-renderer-backgrounding',
  '--disable-sync',
  '--disable-translate',
  '--disable-notifications',
  '--disable-print-preview',
  '--disable-default-apps',
  '--disable-component-update',
  '--disable-domain-reliability',
  '--disable-client-side-phishing-detection',
  '--disable-crash-reporter',
  '--disable-breakpad',
  '--metrics-recording-only',
  '--disable-gpu',
  '--js-flags=--expose-gc',
  '--process-per-site',
  '--renderer-process-limit=2',
  '--disk-cache-size=1048576',
  '--media-cache-size=1',
  '--disable-features=MediaRouter,TranslateUI,GlobalMediaControls,BackForwardCache,OptimizationHints,AutofillServerCommunication',
  '--no-first-run',
  '--no-default-browser-check',
  '--password-store=basic',
  '--mute-audio',
];

export class BrowserController {
  constructor(userId, logger) {
    this.userId = userId;
    this.logger = logger;
    this.context = null;
    this.contextPromise = null;
    this.profilePath = path.join(config.profileRoot, userId);
    this.manualLogin = new ManualLoginSession({
      profilePath: this.profilePath,
      executablePath: config.chromeExecutablePath,
      logger,
    });
  }

  get manualLoginActive() { return this.manualLogin.active; }

  async ensureContext() {
    if (this.manualLogin.active) throw new Error('Conclua ou cancele o login manual antes de iniciar o processo automatico.');
    if (this.context) return this.context;
    if (this.contextPromise) return this.contextPromise;
    this.contextPromise = this.#launchWithRecovery();
    try {
      this.context = await this.contextPromise;
      return this.context;
    } finally {
      this.contextPromise = null;
    }
  }

  async #launchWithRecovery() {
    await fs.mkdir(this.profilePath, { recursive: true, mode: 0o700 });
    let lastError;
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      let context = null;
      try {
        context = await chromium.launchPersistentContext(this.profilePath, {
          executablePath: config.chromeExecutablePath || undefined,
          headless: false,
          viewport: { width: 1100, height: 760 },
          locale: 'pt-BR',
          timezoneId: process.env.TZ || 'America/Sao_Paulo',
          args: LOW_MEMORY_ARGS,
          ignoreDefaultArgs: ['--enable-automation'],
        });
        await context.route('**/*', async (route) => {
          try {
            const request = route.request();
            const url = request.url();
            const type = request.resourceType();
            const heavy = /googlevideo\.com|doubleclick\.net|googlesyndication\.com|googleadservices\.com/i.test(url);
            if (['media', 'image', 'font'].includes(type) || heavy) await route.abort();
            else await route.continue();
          } catch {
            try { await route.continue(); } catch { /* request already gone */ }
          }
        });
        for (const page of context.pages()) {
          if (page.url() === 'about:blank') await page.close().catch(() => {});
        }
        const probe = await context.newPage();
        await probe.close();
        context.on('close', () => {
          if (this.context === context) this.context = null;
        });
        this.logger('Chrome individual iniciado com o perfil persistente desta conta.');
        return context;
      } catch (error) {
        lastError = error;
        await context?.close().catch(() => {});
        if (attempt < 3) await delay(attempt === 1 ? 750 : 1500);
      }
    }
    throw new Error(`Nao foi possivel abrir o perfil do Chrome apos tres tentativas: ${lastError?.message || 'erro desconhecido'}`);
  }

  async startLogin() {
    if (this.manualLogin.active) return this.manualLogin.snapshot();
    await this.#closeAutomationContext();
    return this.manualLogin.start();
  }

  async loginSnapshot() { return this.manualLogin.snapshot(); }

  async interactLogin(payload) { return this.manualLogin.interact(payload); }

  async finishLogin() {
    if (!this.manualLogin.active) throw new Error('A tela de login manual nao esta aberta.');
    await this.manualLogin.stop('concluido');
    const profile = await this.detectAccount();
    if (profile.status === 'connected') this.logger(`Conta do YouTube conectada${profile.channelHandle ? `: ${profile.channelHandle}` : ''}.`);
    return profile;
  }

  async cancelLogin() { await this.manualLogin.stop('cancelado'); }

  async newPage() {
    let lastError;
    for (let attempt = 1; attempt <= 2; attempt += 1) {
      const context = await this.ensureContext();
      try {
        return await context.newPage();
      } catch (error) {
        lastError = error;
        if (this.context === context) this.context = null;
        await context.close().catch(() => {});
        if (attempt < 2) this.logger('Chrome ficou sem responder ao abrir uma aba. O perfil sera reaberto automaticamente.');
      }
    }
    throw new Error(`Nao foi possivel abrir uma aba do Chrome: ${lastError?.message || 'erro desconhecido'}`);
  }

  async detectAccount() {
    const probePage = await this.newPage();
    const context = probePage.context();
    try {
      // Igual a V4.83: um cookie valido OU um sinal confirmado na pagina basta.
      // Exigir os dois gerava falso "desconectado" em VPS mais lentas.
      const cookies = await context.cookies(['https://www.youtube.com/']);
      const loggedByCookie = hasYouTubeLoginCookie(cookies);
      await probePage.goto('https://www.youtube.com/', {
        waitUntil: 'commit', timeout: 20_000,
      }).catch(() => {});
      if (!loggedByCookie) {
        await probePage.waitForFunction(() => Boolean(
          window.ytcfg?.get?.('LOGGED_IN')
          || document.querySelector('button#avatar-btn, ytd-topbar-menu-button-renderer #avatar-btn'),
        ), null, { timeout: 6_000 }).catch(() => {});
      }
      const details = await probePage.evaluate(() => {
        const loggedByPage = Boolean(window.ytcfg?.get?.('LOGGED_IN'));
        const avatar = document.querySelector('button#avatar-btn, ytd-topbar-menu-button-renderer #avatar-btn');
        const handle = document.querySelector(
          'ytd-active-account-header-renderer #channel-handle, ytd-active-account-header-renderer yt-formatted-string#channel-handle',
        )?.textContent?.trim() || null;
        return { loggedByPage, avatarVisible: Boolean(avatar), handle };
      }).catch(() => ({ loggedByPage: false, avatarVisible: false, handle: null }));
      const connected = isYouTubeSessionConnected({ loggedByCookie, ...details });
      return {
        status: connected ? 'connected' : 'disconnected',
        channelName: null,
        channelHandle: connected ? details.handle : null,
      };
    } finally {
      await probePage.close().catch(() => {});
    }
  }

  async close() {
    await this.cancelLogin();
    await this.#closeAutomationContext();
  }

  async #closeAutomationContext() {
    const pending = this.contextPromise;
    if (pending) await pending.catch(() => {});
    if (this.context) await this.context.close().catch(() => {});
    this.context = null;
  }
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}
