# Atualizar da V1.0.1 para a V1.0.4 sem perder dados

Esta atualizacao preserva o PostgreSQL, as contas, as configuracoes e os perfis do Chrome que ja estao no servidor. O projeto usa o mesmo nome fixo do Docker Compose e, por isso, a pasta nova conecta aos volumes existentes.

Nunca execute `docker compose down -v`: a opcao `-v` apaga os volumes.

## 1. Antes de trocar a versao

Na pasta antiga, crie um backup:

```bash
cd /opt/Peralta_Chat_Server_V1.0.1
./scripts/backup.sh
```

Copie a pasta `backups` para o seu computador quando puder. Ela contem dados sigilosos das contas do YouTube.

## 2. Preparar uma VPS com apenas 1 GB de RAM

A VPS diagnosticada tem aproximadamente 1 GB de RAM, 1 vCPU e nenhuma swap. Execute uma vez, ja dentro da pasta V1.0.4:

```bash
cd /opt/Peralta_Chat_Server_V1.0.4
chmod +x scripts/*.sh
./scripts/preparar-vps-1gb.sh
```

O script so cria `/swapfile` quando a maquina tem menos de 2 GB de RAM e ainda nao possui pelo menos 1 GB de swap. Essa margem evita que o Linux encerre o Chrome durante o login. Swap nao transforma uma VPS pequena em uma maquina para varias contas simultaneas; para isso, aumente RAM e CPU.

## 3. Aplicar a V1.0.4

```bash
cd /opt/Peralta_Chat_Server_V1.0.4
./scripts/migrar-da-v1.0.1.sh
```

O script copia o `.env` antigo sem mostrar as senhas, recompila o container e mantem os volumes. Confira:

```bash
curl -sS https://peraltaultrachat.shop/healthz
docker compose ps
docker compose logs --tail=100 server
```

A saude deve informar `"version":"1.0.4"`. Depois, abra o painel e use **Abrir login do YouTube**.

